import { useMemo, useState } from "react"
import { Icon } from "./Icon"

export type NotificationHistoryRecord = {
  id: number
  name: string
  message: string
  time: string
  recipient?: "관리자" | "사용자"
  category?: string
}

export type MessagingSettings = {
  enabled: boolean
  quietHoursEnabled: boolean
  quietStart: string
  quietEnd: string
  smsFallbackEnabled: boolean
}

export type RoutineAction = {
  id: number
  recipient: "고객" | "관리자 본인"
  message: string
}

export type MessagingRoutine = {
  id: number
  title: string
  enabled: boolean
  conditions: string[]
  actions: RoutineAction[]
}

const notificationHistory: NotificationHistoryRecord[] = [
  {
    id: 1,
    name: "홍길동",
    message: "내일 오전 9시에 방문 견적이 예정되어 있습니다.",
    time: "방금",
  },
  {
    id: 2,
    name: "김명품",
    message: "요청하신 이사 견적서가 등록되었습니다. 확인해 주세요.",
    time: "10분 전",
  },
  {
    id: 3,
    name: "박철수",
    message: "계약금 입금이 확인되어 이사 예약이 확정되었습니다.",
    time: "35분 전",
  },
  {
    id: 4,
    name: "최지우",
    message: "이사 예정일이 3일 남았습니다. 준비 사항을 확인해 주세요.",
    time: "1시간 전",
  },
  {
    id: 5,
    name: "정현우",
    message: "예약 상태가 승인 대기에서 견적 협의로 변경되었습니다.",
    time: "2시간 전",
  },
  {
    id: 6,
    name: "강민주",
    message: "포장 박스 배송이 오늘 오후에 시작될 예정입니다.",
    time: "오전 9:20",
  },
  {
    id: 7,
    name: "이서준",
    message: "오늘은 이사 예정일입니다. 담당 기사 정보를 확인해 주세요.",
    time: "오전 8:00",
  },
  {
    id: 8,
    name: "윤아름",
    message: "이사 완료 처리가 되었습니다. 서비스 이용은 어떠셨나요?",
    time: "어제",
  },
  {
    id: 9,
    name: "송지호",
    message: "방문 견적 일정이 10월 2일 오후 2시로 변경되었습니다.",
    time: "어제",
  },
  {
    id: 10,
    name: "한유진",
    message: "견적 요청이 정상적으로 접수되었습니다.",
    time: "2일 전",
  },
]

export function NotificationManagementHome({
  onOpenHistory,
  onOpenMessaging,
}: {
  onOpenHistory: () => void
  onOpenMessaging: () => void
}) {
  return (
    <div className="h-full overflow-y-auto bg-[#f5f6f8] px-4 pb-6 pt-5">
      <div className="mb-5">
        <p className="text-[10px] font-bold tracking-[0.12em] text-[#879189]">
          MESSAGE SERVICE
        </p>
        <h1 className="mt-1 text-xl font-extrabold tracking-[-0.04em] text-[#346538]">
          알림 관리
        </h1>
      </div>

      <section className="rounded-[22px] border border-white bg-white p-5 shadow-[0_8px_24px_rgba(36,58,39,.08)]">
        <div className="flex items-center gap-2">
          <span className="grid h-8 w-8 place-items-center rounded-xl bg-[#edf3ed] text-[#346538]">
            <Icon name="bell" size={18} />
          </span>
          <h2 className="text-sm font-extrabold text-[#3a403b]">
            자동 메시징 발송 현황
          </h2>
        </div>
        <div className="py-7 text-center">
          <strong className="text-[42px] font-extrabold tracking-[-0.06em] text-[#346538]">
            45
            <span className="ml-1 text-lg tracking-normal">건</span>
          </strong>
          <p className="mt-2 text-xs font-semibold text-[#768078]">
            오늘 발송된 자동 알림 메시지 수
          </p>
        </div>
        <div className="flex items-center justify-center gap-2 rounded-xl bg-[#f2f6f2] py-2.5 text-[10px] font-bold text-[#59705c]">
          <span className="h-2 w-2 rounded-full bg-[#4f8b55]" />
          자동 메시징 시스템 정상 운영 중
        </div>
      </section>

      <div className="mt-5 space-y-3">
        <button
          className="flex w-full items-center gap-4 rounded-[18px] border border-white bg-white p-4 text-left shadow-[0_5px_18px_rgba(36,58,39,.06)] transition active:scale-[.99]"
          onClick={onOpenHistory}
          type="button"
        >
          <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-[#edf3ed] text-[#346538]">
            <Icon name="document" size={22} />
          </span>
          <span className="min-w-0 flex-1">
            <strong className="block text-sm text-[#2e3630]">알림 내역</strong>
            <span className="mt-1 block text-xs leading-5 text-[#858d87]">
              관리자·사용자 상단 팝업 알림 기록 확인
            </span>
          </span>
          <Icon className="text-[#9aa19b]" name="arrowRight" size={18} />
        </button>

        <button
          className="flex w-full items-center gap-4 rounded-[18px] border border-white bg-white p-4 text-left shadow-[0_5px_18px_rgba(36,58,39,.06)]"
          onClick={onOpenMessaging}
          type="button"
        >
          <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-[#edf3ed] text-[#346538]">
            <Icon name="settings" size={22} />
          </span>
          <span className="min-w-0 flex-1">
            <strong className="block text-sm text-[#2e3630]">
              자동 메시징 관리
            </strong>
            <span className="mt-1 block text-xs leading-5 text-[#858d87]">
              자동 알림 운영 상태와 발송 환경 관리
            </span>
          </span>
          <Icon className="text-[#9aa19b]" name="arrowRight" size={18} />
        </button>
      </div>
    </div>
  )
}

function MessagingToggle({
  checked,
  label,
  onChange,
}: {
  checked: boolean
  label: string
  onChange: (checked: boolean) => void
}) {
  return (
    <button
      aria-label={label}
      aria-pressed={checked}
      className={`relative h-7 w-12 shrink-0 rounded-full transition ${
        checked ? "bg-[#346538]" : "bg-[#d8ddd9]"
      }`}
      onClick={() => onChange(!checked)}
      type="button"
    >
      <span
        className={`absolute left-1 top-1 h-5 w-5 rounded-full bg-white shadow-sm transition-transform ${
          checked ? "translate-x-5" : "translate-x-0"
        }`}
      />
    </button>
  )
}

function parseTime(time: string) {
  const [hourText, minute] = time.split(":")
  const hour24 = Number(hourText)
  return {
    period: hour24 >= 12 ? "오후" : "오전",
    hour: String(hour24 % 12 || 12).padStart(2, "0"),
    minute,
  }
}

function makeTime(period: string, hour: string, minute: string) {
  const hour12 = Number(hour)
  const hour24 =
    period === "오후" ? (hour12 % 12) + 12 : hour12 === 12 ? 0 : hour12
  return `${String(hour24).padStart(2, "0")}:${minute}`
}

function displayTime(time: string) {
  const parsed = parseTime(time)
  return `${parsed.period} ${parsed.hour}:${parsed.minute}`
}

export function MessagingOperationsSettings({
  onChange,
  onClose,
  settings,
}: {
  onChange: (settings: MessagingSettings) => void
  onClose: () => void
  settings: MessagingSettings
}) {
  const [pickerOpen, setPickerOpen] = useState(false)
  const [pickerTarget, setPickerTarget] = useState<"start" | "end">("start")
  const initial = parseTime(settings.quietStart)
  const [period, setPeriod] = useState(initial.period)
  const [hour, setHour] = useState(initial.hour)
  const [minute, setMinute] = useState(initial.minute)
  const update = (partial: Partial<MessagingSettings>) =>
    onChange({ ...settings, ...partial })

  const openPicker = (target: "start" | "end") => {
    const selected = parseTime(
      target === "start" ? settings.quietStart : settings.quietEnd,
    )
    setPickerTarget(target)
    setPeriod(selected.period)
    setHour(selected.hour)
    setMinute(selected.minute)
    setPickerOpen(true)
  }

  const saveTime = () => {
    update({
      [pickerTarget === "start" ? "quietStart" : "quietEnd"]: makeTime(
        period,
        hour,
        minute,
      ),
    })
    setPickerOpen(false)
  }

  return (
    <div className="relative flex h-full min-h-0 flex-col overflow-hidden bg-[#f5f6f8]">
      <header className="relative flex h-14 shrink-0 items-center justify-center border-b border-[#e5e9e5] bg-white">
        <h1 className="text-base font-extrabold text-[#29322b]">
          메시징 운영 설정
        </h1>
        <button
          aria-label="메시징 운영 설정 닫기"
          className="absolute right-3 grid h-10 w-10 place-items-center rounded-full text-[#525c54] hover:bg-[#f2f4f2]"
          onClick={onClose}
          type="button"
        >
          <Icon name="x" size={20} />
        </button>
      </header>

      <div className="flex-1 space-y-3 overflow-y-auto p-4">
        <section className="rounded-[18px] bg-white p-4 shadow-[0_4px_16px_rgba(36,58,39,.05)]">
          <div className="flex items-start gap-3">
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-[#edf3ed] text-[#346538]">
              <Icon name="settings" size={21} />
            </span>
            <div className="min-w-0 flex-1">
              <h2 className="text-sm font-extrabold text-[#303832]">
                전체 자동 메시징 가동
              </h2>
              <p className="mt-2 text-[11px] leading-5 text-[#858d87]">
                끄기(Off) 상태일 경우, 설정된 모든 자동 알림(루틴)이 일시
                정지되며 고객에게 메시지가 발송되지 않습니다.
              </p>
            </div>
            <MessagingToggle
              checked={settings.enabled}
              label="전체 자동 메시징 가동"
              onChange={(enabled) => update({ enabled })}
            />
          </div>
          {!settings.enabled && (
            <div className="mt-4 flex items-center gap-2 rounded-xl bg-[#fff0ee] px-3 py-2.5 text-[10px] font-bold text-[#a84a42]">
              <Icon name="alert" size={14} />
              현재 모든 자동 메시지가 일시 정지되었습니다.
            </div>
          )}
        </section>

        <section
          className={`rounded-[18px] bg-white p-4 shadow-[0_4px_16px_rgba(36,58,39,.05)] ${
            settings.enabled ? "" : "opacity-60"
          }`}
        >
          <div className="flex items-start gap-3">
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-[#f0effa] text-[#6864a1]">
              <Icon name="clock" size={21} />
            </span>
            <div className="min-w-0 flex-1">
              <h2 className="text-sm font-extrabold text-[#303832]">
                에티켓 시간 설정
              </h2>
              <p className="mt-0.5 text-[10px] font-semibold text-[#7b817d]">
                야간 발송 보류
              </p>
            </div>
            <MessagingToggle
              checked={settings.quietHoursEnabled}
              label="에티켓 시간 사용"
              onChange={(quietHoursEnabled) => update({ quietHoursEnabled })}
            />
          </div>
          <p className="mt-3 text-[11px] leading-5 text-[#858d87]">
            해당 시간에 발생한 알림은 즉시 발송되지 않고 보류되었다가,
            에티켓 시간이 종료되면 일괄 발송됩니다.
          </p>
          <div className="mt-4 grid grid-cols-[1fr_auto_1fr] items-center gap-2">
            <button
              className="rounded-xl bg-[#f4f4f8] px-2 py-3 text-xs font-extrabold text-[#5e6085] disabled:text-[#a7aea8]"
              disabled={!settings.enabled || !settings.quietHoursEnabled}
              onClick={() => openPicker("start")}
              type="button"
            >
              {displayTime(settings.quietStart)}
            </button>
            <span className="text-xs font-bold text-[#999f9a]">~</span>
            <button
              className="rounded-xl bg-[#f4f4f8] px-2 py-3 text-xs font-extrabold text-[#5e6085] disabled:text-[#a7aea8]"
              disabled={!settings.enabled || !settings.quietHoursEnabled}
              onClick={() => openPicker("end")}
              type="button"
            >
              {displayTime(settings.quietEnd)}
            </button>
          </div>
        </section>

        <section
          className={`rounded-[18px] bg-white p-4 shadow-[0_4px_16px_rgba(36,58,39,.05)] ${
            settings.enabled ? "" : "opacity-60"
          }`}
        >
          <div className="flex items-start gap-3">
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-[#edf3ed] text-[#346538]">
              <Icon name="chat" size={21} />
            </span>
            <div className="min-w-0 flex-1">
              <h2 className="text-sm font-extrabold leading-5 text-[#303832]">
                알림톡 실패 시 문자(SMS) 대체 발송
              </h2>
            </div>
            <MessagingToggle
              checked={settings.smsFallbackEnabled}
              label="문자 대체 발송"
              onChange={(smsFallbackEnabled) => update({ smsFallbackEnabled })}
            />
          </div>
          <p className="mt-3 text-[11px] leading-5 text-[#858d87]">
            고객이 채널을 차단했거나 네트워크 오류로 알림톡 발송에 실패할
            경우, 시스템이 이를 감지하여 일반 문자로 우회 발송합니다.
          </p>
          <p className="mt-2 rounded-xl bg-[#fff7e8] px-3 py-2.5 text-[10px] font-semibold text-[#926b2d]">
            문자 대체 발송 시 별도의 발송 비용이 발생할 수 있습니다.
          </p>
        </section>
      </div>

      {pickerOpen && (
        <div className="absolute inset-0 z-40 flex items-end bg-[#1f2d21]/45 backdrop-blur-[2px]">
          <div className="w-full rounded-t-[24px] bg-white px-5 pb-6 pt-4 shadow-[0_-18px_50px_rgba(25,42,28,.22)]">
            <div className="flex items-center justify-between">
              <button
                className="px-2 py-2 text-sm font-semibold text-[#828a84]"
                onClick={() => setPickerOpen(false)}
                type="button"
              >
                취소
              </button>
              <h2 className="text-sm font-extrabold text-[#303832]">
                {pickerTarget === "start"
                  ? "에티켓 시작 시간"
                  : "에티켓 종료 시간"}
              </h2>
              <button
                className="px-2 py-2 text-sm font-extrabold text-[#346538]"
                onClick={saveTime}
                type="button"
              >
                완료
              </button>
            </div>
            <div className="relative mt-4 grid grid-cols-3 gap-2 overflow-hidden rounded-2xl bg-[#f5f6f5] p-3">
              <div className="pointer-events-none absolute inset-x-3 top-1/2 h-11 -translate-y-1/2 rounded-xl border-y border-[#dfe4df] bg-white/70" />
              <select
                aria-label="오전 오후"
                className="relative z-10 h-32 bg-transparent text-center text-base font-bold outline-none"
                onChange={(event) => setPeriod(event.target.value)}
                size={3}
                value={period}
              >
                {["오전", "오후"].map((value) => (
                  <option key={value}>{value}</option>
                ))}
              </select>
              <select
                aria-label="시"
                className="relative z-10 h-32 bg-transparent text-center text-base font-bold outline-none"
                onChange={(event) => setHour(event.target.value)}
                size={3}
                value={hour}
              >
                {Array.from({ length: 12 }, (_, index) =>
                  String(index + 1).padStart(2, "0"),
                ).map((value) => (
                  <option key={value} value={value}>
                    {value}시
                  </option>
                ))}
              </select>
              <select
                aria-label="분"
                className="relative z-10 h-32 bg-transparent text-center text-base font-bold outline-none"
                onChange={(event) => setMinute(event.target.value)}
                size={3}
                value={minute}
              >
                {["00", "10", "20", "30", "40", "50"].map((value) => (
                  <option key={value} value={value}>
                    {value}분
                  </option>
                ))}
              </select>
            </div>
            <p className="mt-3 text-center text-[10px] text-[#8d958f]">
              각 항목을 위아래로 스크롤해 시간을 맞춰 주세요.
            </p>
          </div>
        </div>
      )}
    </div>
  )
}

const conditionGroups = [
  {
    category: "견적 관리",
    items: ["견적 협의", "견적 확정", "이사 완료", "행 삭제 시"],
  },
  {
    category: "예약 관리",
    items: [
      "반려",
      "승인 대기",
      "예약 확정",
      "견적 협의",
      "견적 확정",
      "이사 완료",
      "예약 했을 시",
      "예약을 취소했을 시",
      "행 삭제 시",
    ],
  },
  {
    category: "리뷰 관리",
    items: ["리뷰 등록 할 시", "관리자가 답변 할 시"],
  },
  {
    category: "회원 관리",
    items: ["신규 회원이 가입되었을 시"],
  },
  {
    category: "일정 관리",
    items: [
      "업체 휴무일을 등록했을 시",
      "이사 예약이 불가능 할 시",
      "특정 날짜 선택했을 시",
      "특정 요일 선택했을 시",
      "업체 휴무일 일 때",
      "이사 예약이 불가능 할 때",
    ],
  },
  {
    category: "견적서 등록",
    items: ["견적서를 등록했을 시"],
  },
]

function emptyRoutine(): MessagingRoutine {
  return {
    id: Date.now(),
    title: "",
    enabled: true,
    conditions: [],
    actions: [],
  }
}

export function NotificationHistory({
  adminNotifications,
  onClose,
}: {
  adminNotifications: NotificationHistoryRecord[]
  onClose: () => void
}) {
  const [query, setQuery] = useState("")
  const allHistory = useMemo(
    () => [...adminNotifications, ...notificationHistory],
    [adminNotifications],
  )
  const filteredHistory = useMemo(() => {
    const normalized = query.trim().toLocaleLowerCase()
    return allHistory.filter(
      (record) =>
        !normalized ||
        `${record.name} ${record.message} ${record.category || ""} ${record.recipient || "사용자"}`
          .toLocaleLowerCase()
          .includes(normalized),
    )
  }, [allHistory, query])
  const adminCount = allHistory.filter((record) => record.recipient === "관리자").length
  const userCount = allHistory.length - adminCount

  return (
    <div className="flex h-full min-h-0 flex-col overflow-hidden bg-[#f5f6f8]">
      <header className="relative flex h-14 shrink-0 items-center justify-center border-b border-[#e5e9e5] bg-white">
        <h1 className="text-base font-extrabold text-[#29322b]">알림 내역</h1>
        <button
          aria-label="알림 내역 닫기"
          className="absolute right-3 grid h-10 w-10 place-items-center rounded-full text-[#525c54] hover:bg-[#f2f4f2]"
          onClick={onClose}
          type="button"
        >
          <Icon name="x" size={20} />
        </button>
      </header>

      <div className="shrink-0 p-4 pb-2">
        <label className="flex items-center gap-2 rounded-full bg-[#ecefee] px-4 py-3">
          <Icon className="shrink-0 text-[#858d87]" name="search" size={17} />
          <input
            className="min-w-0 flex-1 bg-transparent text-sm text-[#303832] outline-none placeholder:text-[#9ca29e]"
            onChange={(event) => setQuery(event.target.value)}
            placeholder="회원명 또는 알림 내용을 검색하세요"
            type="search"
            value={query}
          />
          {query && (
            <span className="text-[10px] font-bold text-[#718074]">
              {filteredHistory.length}건
            </span>
          )}
        </label>
        <div className="mt-3 grid grid-cols-2 gap-2">
          <div className="rounded-xl bg-white px-3 py-2.5">
            <span className="block text-[9px] font-bold text-[#858d87]">관리자 수신</span>
            <strong className="mt-0.5 block text-sm text-[#346538]">{adminCount}건</strong>
          </div>
          <div className="rounded-xl bg-white px-3 py-2.5">
            <span className="block text-[9px] font-bold text-[#858d87]">사용자 수신</span>
            <strong className="mt-0.5 block text-sm text-[#346538]">{userCount}건</strong>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 pb-5 pt-2">
        <div className="mb-2 flex items-center justify-between px-1">
          <p className="text-xs font-bold text-[#68716a]">전체 팝업 알림 기록</p>
          <span className="text-[10px] font-semibold text-[#969d98]">
            최신 발송순
          </span>
        </div>
        <div className="space-y-2">
          {filteredHistory.map((record) => (
            <article
              className="flex w-full items-center gap-3 rounded-2xl border border-white bg-white p-3.5 text-left shadow-[0_3px_12px_rgba(36,58,39,.05)]"
              key={record.id}
            >
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-[#edf3ed] text-sm font-extrabold text-[#346538]">
                {record.name[0]}
              </span>
              <span className="min-w-0 flex-1">
                <span className="flex items-center gap-1">
                  <strong className="truncate text-sm text-[#303832]">
                    {record.name}
                  </strong>
                </span>
                <span className="mt-1 flex items-center gap-1.5">
                  <span className={`rounded-full px-1.5 py-0.5 text-[8px] font-bold ${record.recipient === "관리자" ? "bg-[#fff0ee] text-[#b64b42]" : "bg-[#edf3ed] text-[#346538]"}`}>
                    {record.recipient || "사용자"} 수신
                  </span>
                  {record.category && <span className="truncate text-[9px] font-semibold text-[#858d87]">{record.category}</span>}
                </span>
                <span className="mt-1 block truncate text-xs text-[#747c76]">
                  {record.message}
                </span>
              </span>
              <span className="shrink-0 self-start pt-1 text-[9px] text-[#9aa09b]">
                {record.time}
              </span>
            </article>
          ))}
          {!filteredHistory.length && (
            <div className="py-20 text-center">
              <span className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-white text-[#9aa19b]">
                <Icon name="search" size={21} />
              </span>
              <p className="mt-3 text-xs font-semibold text-[#747c76]">
                검색 결과가 없습니다.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
