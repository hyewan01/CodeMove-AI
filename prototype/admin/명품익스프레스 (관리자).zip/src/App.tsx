import {
  useEffect,
  useRef,
  useState,
  type ChangeEvent,
  type Dispatch,
  type PointerEvent,
  type ReactNode,
  type SetStateAction,
  type TouchEvent,
} from "react"
import { getDocument, GlobalWorkerOptions } from "pdfjs-dist"
import pdfWorkerUrl from "pdfjs-dist/build/pdf.worker.min.mjs?url"
import estimateTemplateUrl from "./imports/estimate-form.pdf?url"
import EstimateBoard from "./EstimateBoard"
import {
  MessagingOperationsSettings,
  NotificationHistory,
  NotificationManagementHome,
  type MessagingRoutine,
  type MessagingSettings,
  type NotificationHistoryRecord,
} from "./NotificationManagement"
import {
  ChatAnswerSettings,
  ChatDetail,
  ChatEntrySettings,
  ChatList,
  ChatManagementHome,
  ChatOperationsSettings,
  type AnswerTopic,
  type ChatSettings,
  type QuickMenuItem,
} from "./ChatManagement"

GlobalWorkerOptions.workerSrc = pdfWorkerUrl

type IconName =
  | "arrowRight"
  | "bell"
  | "calendar"
  | "camera"
  | "chat"
  | "check"
  | "chevron"
  | "coin"
  | "document"
  | "edit"
  | "home"
  | "logout"
  | "menu"
  | "people"
  | "pin"
  | "refresh"
  | "search"
  | "star"
  | "truck"
  | "trash"
  | "user"
  | "x"

type EstimateRecord = {
  id: number
  status: string
  name: string
  date: string
  approvedDate?: string
  tone: "red" | "green" | "blue"
  phone?: string
  companyName?: string
  documentUrl?: string
  videoUrl?: string
  videoFileName?: string
  videoUploadedAt?: string
  documentData?: EstimateDocumentData
}

type EstimateLineItem = {
  id: number
  name: string
  quantity: string
}

type EstimateDocumentData = {
  companyName: string
  customer: string
  phone: string
  estimateDate: string
  moveDate: string
  transportDate: string
  moveType: string
  origin: string
  destination: string
  volume: string
  note: string
  movingCost: string
  extraCost: string
  total: string
  deposit: string
  balance: string
  itemGroups: [string, string, string, string]
  optionCosts: string[]
  optionSelections: string[]
  workMethod: string
  transportMethod: {
    ladder: "" | "전" | "후"
    elevator: "" | "전" | "후"
    stairs: "" | "전" | "후"
  }
  departureLadder: string
  destinationLadder: string
  ladderSubtotal: string
  itemRowCount: number
  items: EstimateLineItem[]
}

type ReservationStatus =
  | "승인 대기"
  | "반려"
  | "예약 확정"
  | "견적 협의"
  | "견적 확정"
  | "이사 완료"

type ReservationRecord = {
  id: number
  status: ReservationStatus
  name: string
  userId: string
  appliedDate: string
  phone: string
  service: string
  origin: string
  destination: string
  movingDate: string
  movingTime: string
  consultationDate: string
  consultationTime: string
  ladder: string
  elevator: string
  volume: string
  items: string
  memo: string
  paymentStatus?: "결제 대기" | "결제 완료"
}

type ManualSchedule = {
  id: number
  date: string
  title: string
  category: string
  time: string
  place: string
  memberId?: string
  reservationId?: number
  userCreated?: boolean
}

type ManagedDateStatus = "unavailable" | "closed"

const koreanInitials = "ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ"

function getKoreanInitials(value: string) {
  return [...value]
    .map((character) => {
      const code = character.charCodeAt(0) - 0xac00
      return code >= 0 && code <= 11171
        ? koreanInitials[Math.floor(code / 588)]
        : character
    })
    .join("")
}

function formatShortDateInput(value: string, isDeleting = false) {
  const digits = value.replace(/\D/g, "").slice(0, 6)
  if (digits.length >= 5) {
    return `${digits.slice(0, 2)}.${digits.slice(2, 4)}.${digits.slice(4)}`
  }
  if (digits.length >= 3) {
    return `${digits.slice(0, 2)}.${digits.slice(2)}${
      digits.length === 4 && !isDeleting ? "." : ""
    }`
  }
  if (digits.length === 2 && !isDeleting) return `${digits}.`
  return digits
}

function getTodayShortDate() {
  const today = new Date()
  return `${String(today.getFullYear()).slice(-2)}.${String(today.getMonth() + 1).padStart(2, "0")}.${String(today.getDate()).padStart(2, "0")}`
}

const reservationCustomers = [
  ["홍길동", "luxury", "010-1234-5678"],
  ["김명품", "luxury2", "010-2244-8811"],
  ["박철수", "park789", "010-7788-2200"],
  ["최지우", "choi00", "010-3377-9021"],
  ["이서준", "seojun82", "010-5892-1144"],
  ["정하윤", "hayoon5", "010-9834-1420"],
  ["강민준", "minjun77", "010-4471-3302"],
  ["윤서아", "seoa11", "010-8842-3199"],
  ["송지호", "jiho90", "010-1166-4201"],
  ["한유진", "yujin26", "010-6673-9920"],
  ["오도현", "dohyun3", "010-2207-6134"],
  ["문지안", "jian8", "010-7318-4490"],
  ["임지수", "jisoo19", "010-9901-7722"],
  ["김도윤", "doyun24", "010-3142-6678"],
  ["이지민", "jimin31", "010-5521-9034"],
  ["박서연", "seoyeon6", "010-7713-2088"],
  ["최현우", "hyunwoo88", "010-4055-7291"],
  ["정수빈", "subin12", "010-6320-1847"],
  ["강준호", "junho75", "010-9081-3362"],
  ["윤채원", "chaewon4", "010-2466-8103"],
  ["송민재", "minjae21", "010-8642-5179"],
  ["한예린", "yerin09", "010-1937-6405"],
  ["오승민", "seungmin5", "010-7254-3916"],
] as const

const reservationStatuses: ReservationStatus[] = [
  "반려",
  "승인 대기",
  "이사 완료",
  "예약 확정",
  "견적 협의",
  "견적 확정",
]

const movingAddresses = [
  "서울 강남구 테헤란로 521",
  "서울 중구 세종대로 110",
  "서울 송파구 올림픽로 300",
  "서울 용산구 한강대로 405",
  "서울 마포구 월드컵로 212",
  "서울 서초구 남부순환로 2584",
  "경기 성남시 분당구 판교역로 166",
  "경기 수원시 팔달구 효원로 241",
  "경기 고양시 덕양구 고양시청로 10",
  "인천 남동구 정각로 29",
  "대전 서구 둔산로 100",
  "광주 서구 내방로 111",
  "부산 연제구 중앙대로 1001",
]

const initialReservations: ReservationRecord[] = Array.from(
  { length: 30 },
  (_, index) => {
    const customer = reservationCustomers[index % reservationCustomers.length]
    const status = reservationStatuses[index % reservationStatuses.length]
    const weeklyDays = [27, 26, 26, 25, 24, 27, 23, 22, 22, 21]
    const month = index < 20 ? "09" : "08"
    const day =
      index < 10
        ? weeklyDays[index]
        : index < 20
          ? 20 - (index - 10)
          : 28 - (index - 20)
    const appliedDate = `26.${month}.${String(day).padStart(2, "0")}`
    return {
      id: index + 1,
      status,
      name: customer[0],
      userId: customer[1],
      appliedDate,
      phone: customer[2],
      service: index % 4 === 0 ? "기업이사" : index % 3 === 0 ? "원룸이사" : "가정이사",
      origin: movingAddresses[index % movingAddresses.length],
      destination:
        movingAddresses[(index + 5 + (index % 3)) % movingAddresses.length],
      movingDate:
        index < 10
          ? `26.09.${String(weeklyDays[index]).padStart(2, "0")}`
          : `26.10.${String((index % 20) + 1).padStart(2, "0")}`,
      movingTime: `${String(7 + (index % 9)).padStart(2, "0")}:00`,
      consultationDate: `26.09.${String((index % 20) + 1).padStart(2, "0")}`,
      consultationTime: index % 2 ? "오후 2시~4시" : "오전 10시~12시",
      ladder: index % 3 === 0 ? "필요" : "불필요",
      elevator: index % 2 === 0 ? "있음" : "없음",
      volume: `${(2.5 + (index % 4)).toFixed(1)}톤`,
      items: "냉장고 1대, 세탁기 1대, TV 1대, 침대 1개, 책상 2개, 의자 4개",
      memo: index % 2 ? "파손 주의 물품이 있어 꼼꼼한 포장을 요청했습니다." : "주차 공간이 협소하므로 방문 전 연락이 필요합니다.",
    }
  },
)

function Icon({
  name,
  size = 20,
  className = "",
}: {
  name: IconName
  size?: number
  className?: string
}) {
  const paths: Record<IconName, ReactNode> = {
    arrowRight: <path d="m9 18 6-6-6-6" />,
    bell: (
      <>
        <path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9" />
        <path d="M10 21h4" />
      </>
    ),
    calendar: (
      <>
        <rect x="3" y="5" width="18" height="16" rx="2" />
        <path d="M16 3v4M8 3v4M3 10h18" />
      </>
    ),
    camera: (
      <>
        <path d="M4 7h3l1.5-2h7L17 7h3v12H4z" />
        <circle cx="12" cy="13" r="3.5" />
      </>
    ),
    chat: (
      <path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z" />
    ),
    check: <path d="m5 12 4 4L19 6" />,
    chevron: <path d="m7 10 5 5 5-5" />,
    coin: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M8.5 9h7M8 12h8M10 9l1.2 7M14 9l-1.2 7" />
      </>
    ),
    document: (
      <>
        <path d="M6 2h9l4 4v16H6z" />
        <path d="M14 2v5h5M9 13h6M9 17h6" />
      </>
    ),
    edit: (
      <>
        <path d="M4 20h4L19 9l-4-4L4 16z" />
        <path d="m13.5 6.5 4 4" />
      </>
    ),
    home: (
      <>
        <path d="m3 11 9-8 9 8" />
        <path d="M5 10v11h14V10M9 21v-7h6v7" />
      </>
    ),
    logout: (
      <>
        <path d="M10 5H5v14h5M14 8l4 4-4 4M18 12H9" />
      </>
    ),
    menu: <path d="M4 7h16M4 12h16M4 17h16" />,
    people: (
      <>
        <circle cx="9" cy="8" r="4" />
        <path d="M2 21v-2a5 5 0 0 1 5-5h4a5 5 0 0 1 5 5v2M17 4a4 4 0 0 1 0 8M19 15a5 5 0 0 1 3 4v2" />
      </>
    ),
    pin: (
      <>
        <path d="M20 10c0 5-8 12-8 12S4 15 4 10a8 8 0 1 1 16 0" />
        <circle cx="12" cy="10" r="2.5" />
      </>
    ),
    refresh: (
      <>
        <path d="M20 7v5h-5" />
        <path d="M4 17v-5h5" />
        <path d="M6.1 8a7 7 0 0 1 11.6-2.1L20 8M4 16l2.3 2.1A7 7 0 0 0 17.9 16" />
      </>
    ),
    search: (
      <>
        <circle cx="11" cy="11" r="7" />
        <path d="m20 20-4-4" />
      </>
    ),
    star: (
      <path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2L3 9.6l6.2-.9z" />
    ),
    truck: (
      <>
        <path d="M3 6h11v11H3zM14 10h4l3 3v4h-7z" />
        <circle cx="7" cy="18" r="2" />
        <circle cx="18" cy="18" r="2" />
      </>
    ),
    trash: (
      <>
        <path d="M4 7h16M9 7V4h6v3M7 7l1 14h8l1-14" />
        <path d="M10 11v6M14 11v6" />
      </>
    ),
    user: (
      <>
        <circle cx="12" cy="8" r="4" />
        <path d="M4 21a8 8 0 0 1 16 0" />
      </>
    ),
    x: <path d="m6 6 12 12M18 6 6 18" />,
  }

  return (
    <svg
      aria-hidden="true"
      className={className}
      fill="none"
      height={size}
      viewBox="0 0 24 24"
      width={size}
    >
      <g
        stroke="currentColor"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="1.8"
      >
        {paths[name]}
      </g>
    </svg>
  )
}

const stats = [
  {
    label: "전체 예약 신청",
    value: "128",
    unit: "건",
    icon: "calendar" as IconName,
  },
  {
    label: "리뷰 등록 현황",
    value: "12",
    unit: "건",
    icon: "star" as IconName,
  },
  { label: "견적 검토", value: "0", unit: "건", icon: "document" as IconName },
  {
    label: "예약 완료",
    value: "57",
    unit: "건",
    icon: "truck" as IconName,
  },
]

const reservations = [
  {
    name: "이서준",
    route: "서울 강남구 → 경기 성남시",
    date: "05. 28",
    status: "견적 승인",
  },
  {
    name: "김지우",
    route: "서울 마포구 → 서울 송파구",
    date: "05. 30",
    status: "상담 중",
  },
  {
    name: "박하윤",
    route: "경기 수원시 → 서울 용산구",
    date: "06. 02",
    status: "신청 완료",
  },
]

type NotificationItem = {
  id: number
  category: string
  message: string
  createdAt: number
  icon: IconName
  important?: boolean
  target:
    | "chat"
    | "scheduleCalendar"
    | "reservationManagement"
    | "estimateManagement"
    | "memberManagement"
    | "chatEntrySettings"
  chatId?: string
}

type RoutineToast = {
  title: string
  message: string
  target: NotificationItem["target"]
  swipeX: number
  dismissing: boolean
}

const initialNotificationItems: NotificationItem[] = [
  {
    id: 1,
    category: "채팅 대기",
    message: "강민주 고객님이 관리자 상담을 요청했습니다. 응답이 필요합니다.",
    createdAt: Date.now() - 10 * 60 * 1000,
    icon: "chat",
    important: true,
    target: "chat",
    chatId: "kang22",
  },
  {
    id: 2,
    category: "오늘의 일정",
    message: "오늘(9/28)은 이서준 고객님의 '이사 확정' 일정이 있습니다.",
    createdAt: Date.now() - 2 * 60 * 60 * 1000,
    icon: "truck",
    target: "scheduleCalendar",
  },
  {
    id: 3,
    category: "이사 예약",
    message: "최지우 고객님이 신규 가정이사 예약을 신청했습니다.",
    createdAt: Date.now() - 3 * 60 * 60 * 1000,
    icon: "calendar",
    target: "reservationManagement",
  },
  {
    id: 4,
    category: "견적서 등록",
    message: "홍길동 고객님의 신규 견적서가 접수되었습니다.",
    createdAt: Date.now() - 26 * 60 * 60 * 1000,
    icon: "document",
    target: "estimateManagement",
  },
  {
    id: 5,
    category: "상태 변경",
    message:
      "김명품 고객님의 예약 상태가 '승인 대기'에서 '견적 협의'로 변경되었습니다.",
    createdAt: Date.now() - 30 * 60 * 60 * 1000,
    icon: "refresh",
    target: "reservationManagement",
  },
  {
    id: 6,
    category: "내용 수정",
    message: "박철수 고객님의 이사 희망 일정이 관리자에 의해 수정되었습니다.",
    createdAt: Date.now() - 8 * 24 * 60 * 60 * 1000,
    icon: "edit",
    target: "reservationManagement",
  },
  {
    id: 7,
    category: "신규 가입",
    message: "윤아름 고객님이 시스템에 신규 회원으로 등록되었습니다.",
    createdAt: Date.now() - 12 * 24 * 60 * 60 * 1000,
    icon: "user",
    target: "memberManagement",
  },
  {
    id: 8,
    category: "데이터 삭제",
    message: "퀵메뉴 설정에서 '결제 문의' 항목이 성공적으로 삭제되었습니다.",
    createdAt: Date.now() - 15 * 24 * 60 * 60 * 1000,
    icon: "trash",
    target: "chatEntrySettings",
  },
]

function getCalendarDayDifference(timestamp: number, now: number) {
  const current = new Date(now)
  const created = new Date(timestamp)
  const currentDay = new Date(
    current.getFullYear(),
    current.getMonth(),
    current.getDate(),
  ).getTime()
  const createdDay = new Date(
    created.getFullYear(),
    created.getMonth(),
    created.getDate(),
  ).getTime()
  return Math.max(0, Math.round((currentDay - createdDay) / 86_400_000))
}

function getNotificationGroup(timestamp: number, now: number) {
  const days = getCalendarDayDifference(timestamp, now)
  if (days < 7) return "최근 7일" as const
  if (days < 30) return "최근 30일" as const
  return null
}

function getRelativeNotificationTime(timestamp: number, now: number) {
  const minutes = Math.max(0, Math.floor((now - timestamp) / 60_000))
  const days = getCalendarDayDifference(timestamp, now)
  if (days === 1) return "어제"
  if (days > 1) return `${days}일 전`
  if (minutes < 1) return "방금"
  if (minutes < 60) return `${minutes}분 전`
  return `${Math.floor(minutes / 60)}시간 전`
}

function getNotificationMessage(item: NotificationItem, now: number) {
  if (item.id !== 2) return item.message
  const today = new Date(now)
  return `오늘(${today.getMonth() + 1}/${today.getDate()})은 이서준 고객님의 '이사 확정' 일정이 있습니다.`
}

function Drawer({
  open,
  onClose,
  onLogout,
  onOpenEstimateManagement,
  onOpenEstimate,
  onOpenReviewManagement,
  onOpenMemberManagement,
  onOpenReservationManagement,
  onOpenScheduleManagement,
  onOpenChatManagement,
  onOpenNotificationManagement,
}: {
  open: boolean
  onClose: () => void
  onLogout: () => void
  onOpenEstimateManagement: () => void
  onOpenEstimate: () => void
  onOpenReviewManagement: () => void
  onOpenMemberManagement: () => void
  onOpenReservationManagement: () => void
  onOpenScheduleManagement: () => void
  onOpenChatManagement: () => void
  onOpenNotificationManagement: () => void
}) {
  return (
    <div
      aria-hidden={!open}
      className={`absolute inset-x-0 bottom-[82px] top-[68px] z-20 transition-visibility ${
        open ? "visible" : "invisible"
      }`}
    >
      <aside
        className={`absolute inset-0 flex h-full w-full flex-col bg-[#f5f6f8] transition-transform duration-300 ease-out ${
          open ? "translate-y-0" : "translate-y-full"
        }`}
      >
        <div className="flex shrink-0 items-center justify-between px-5 pb-2 pt-6">
          <div>
            <p className="text-[10px] font-bold tracking-[0.12em] text-[#809083]">
              SERVICE
            </p>
            <h2 className="mt-0.5 text-[18px] font-extrabold text-[#253328]">
              전체 메뉴
            </h2>
          </div>
          <button
            aria-label="메뉴 닫기"
            className="grid h-10 w-10 place-items-center rounded-full bg-[#f2f5f2] text-[#346538]"
            onClick={onClose}
            type="button"
          >
            <Icon name="x" size={21} />
            </button>
        </div>
        <nav className="flex-1 overflow-y-auto px-4 pb-6 pt-3">
          <div className="overflow-hidden rounded-[20px] bg-white shadow-[0_5px_18px_rgba(36,58,39,.06)]">
            <div className="flex items-center justify-between border-b border-[#edf0ed] px-5 py-5">
              <span className="text-[16px] font-extrabold text-[#253328]">
                전체 서비스
              </span>
              <Icon className="text-[#346538]" name="chevron" size={18} />
            </div>
            {[
              ["견적 관리", "document"],
              ["예약 관리", "calendar"],
              ["채팅 관리", "chat"],
              ["알림 관리", "bell"],
              ["리뷰 관리", "star"],
              ["회원 관리", "people"],
              ["일정 관리", "calendar"],
              ["견적서 등록", "document"],
            ].map(([label, icon]) => (
              <button
                className="flex w-full items-center gap-3 border-b border-[#f0f2f0] px-5 py-4 text-left text-[14px] font-semibold text-[#434b45] last:border-none hover:bg-[#f7f9f7]"
                key={label}
                onClick={
                  label === "견적서 등록"
                    ? onOpenEstimate
                    : label === "견적 관리"
                      ? onOpenEstimateManagement
                      : label === "예약 관리"
                        ? onOpenReservationManagement
                      : label === "일정 관리"
                          ? onOpenScheduleManagement
                      : label === "채팅 관리"
                        ? onOpenChatManagement
                      : label === "알림 관리"
                        ? onOpenNotificationManagement
                      : label === "리뷰 관리"
                        ? onOpenReviewManagement
                        : label === "회원 관리"
                          ? onOpenMemberManagement
                      : undefined
                }
                type="button"
              >
                <span className="grid h-9 w-9 place-items-center rounded-xl bg-[#edf3ed] text-[#346538]">
                  <Icon name={icon as IconName} size={18} />
                </span>
                {label}
              </button>
            ))}
          </div>
          <button
            className="mx-auto mt-4 flex h-10 items-center justify-center gap-2 rounded-xl px-5 text-[12px] font-bold text-[#747c76] transition hover:bg-[#e9ede9] hover:text-[#346538]"
            onClick={onLogout}
            type="button"
          >
            <Icon name="logout" size={17} />
            로그아웃
          </button>
        </nav>
      </aside>
    </div>
  )
}

function StarRating({ rating, size = 14 }: { rating: number; size?: number }) {
  return (
    <div aria-label={`별점 ${rating}점`} className="flex gap-0.5">
      {Array.from({ length: 5 }, (_, index) => (
        <span
          className={index < rating ? "text-[#f2b84b]" : "text-[#dfe3df]"}
          key={index}
          style={{ fontSize: size, lineHeight: 1 }}
        >
          ★
        </span>
      ))}
    </div>
  )
}

const reservationTone: Record<ReservationStatus, string> = {
  "승인 대기": "bg-[#f0f1f0] text-[#6f7771]",
  반려: "bg-[#fbefed] text-[#b9574f]",
  "예약 확정": "bg-[#edf4ed] text-[#346538]",
  "견적 협의": "bg-[#fff4e8] text-[#ad6d32]",
  "견적 확정": "bg-[#eeeefa] text-[#6560a4]",
  "이사 완료": "bg-[#edf3f8] text-[#4b759b]",
}

function getReservationDisplayStatus(status: ReservationStatus) {
  return status === "반려" ? "예약 취소" : "예약 완료"
}

function ScheduleCalendar({
  estimates,
  records,
  onOpenReservation,
  managedDateStatuses = {},
}: {
  estimates: EstimateRecord[]
  records: ReservationRecord[]
  onOpenReservation: (record: ReservationRecord) => void
  managedDateStatuses?: Record<string, ManagedDateStatus>
}) {
  const [year, setYear] = useState(2026)
  const [month, setMonth] = useState(9)
  const [selectedDay, setSelectedDay] = useState(27)
  const [monthPickerOpen, setMonthPickerOpen] = useState(false)
  const [gridMode, setGridMode] = useState(false)
  const [tempYear, setTempYear] = useState(2026)
  const [tempMonth, setTempMonth] = useState(9)
  const [expanded, setExpanded] = useState(false)
  const [selectedSchedule, setSelectedSchedule] = useState<ReservationRecord | null>(null)
  const [selectedManual, setSelectedManual] = useState<ManualSchedule | null>(null)
  const [deletingManual, setDeletingManual] = useState<ManualSchedule | null>(null)
  const [fullDetailOpen, setFullDetailOpen] = useState(false)
  const [manualModal, setManualModal] = useState(false)
  const [categoryPickerOpen, setCategoryPickerOpen] = useState(false)
  const [customCategoryMode, setCustomCategoryMode] = useState(false)
  const [manualForm, setManualForm] = useState({
    title: "",
    category: "견적 상담",
    date: "2026-09-27",
    time: "",
    place: "",
  })
  const [memberQuery, setMemberQuery] = useState("")
  const [selectedMemberId, setSelectedMemberId] = useState("")
  const [reservationQuery, setReservationQuery] = useState("")
  const [selectedReservationId, setSelectedReservationId] = useState<number | null>(
    null,
  )
  const [manualDays, setManualDays] = useState<ManualSchedule[]>([])
  const touchStart = useRef(0)
  const firstDay = new Date(year, month - 1, 1).getDay()
  const daysInMonth = new Date(year, month, 0).getDate()
  const cells = Array.from({ length: 42 }, (_, index) => {
    const day = index - firstDay + 1
    return day >= 1 && day <= daysInMonth ? day : null
  })
  const dateKey = (day: number) =>
    `${String(year).slice(-2)}.${String(month).padStart(2, "0")}.${String(day).padStart(2, "0")}`
  const activeRecords = records.filter((record) =>
    ["승인 대기", "예약 확정", "이사 완료"].includes(record.status),
  )
  const selectedDate = dateKey(selectedDay)
  const daySchedules = activeRecords
    .filter((record) => record.movingDate === selectedDate)
    .sort((a, b) => a.movingTime.localeCompare(b.movingTime))
  const noMoveDays = [7, 8, 17, 18, 27, 28]
  const holidays = month === 9 ? [24, 25, 26] : []
  const changeMonth = (offset: number) => {
    const next = new Date(year, month - 1 + offset, 1)
    setYear(next.getFullYear())
    setMonth(next.getMonth() + 1)
    setSelectedDay(1)
  }
  const memberResults = reservationCustomers.filter(
    (member) =>
      !memberQuery ||
      `${member[0]}${member[2]}`.toLowerCase().includes(memberQuery.toLowerCase()),
  )
  const reservationResults = records
    .filter(
      (record) =>
        !selectedMemberId || record.userId === selectedMemberId,
    )
    .filter(
      (record) =>
        !reservationQuery ||
        `${record.name}${record.phone}${record.origin}${record.destination}`
          .toLowerCase()
          .includes(reservationQuery.toLowerCase()),
    )
  const resetManualForm = () => {
    setManualForm({
      title: "",
      category: "견적 상담",
      date: `${year}-${String(month).padStart(2, "0")}-${String(selectedDay).padStart(2, "0")}`,
      time: "",
      place: "",
    })
    setMemberQuery("")
    setSelectedMemberId("")
    setReservationQuery("")
    setSelectedReservationId(null)
    setCategoryPickerOpen(false)
    setCustomCategoryMode(false)
  }
  const linkedManualReservation = selectedManual?.reservationId
    ? records.find((record) => record.id === selectedManual.reservationId)
    : undefined
  const linkedManualMember = selectedManual?.memberId
    ? reservationCustomers.find((member) => member[1] === selectedManual.memberId)
    : undefined
  const selectedEstimate = selectedSchedule && estimates.length
    ? estimates[(selectedSchedule.id - 1) % estimates.length]
    : undefined

  return (
    <div
      className="px-4 pb-28 pt-6"
      onTouchEnd={(event) => {
        const delta = touchStart.current - event.changedTouches[0].clientY
        if (Math.abs(delta) > 45) setExpanded(delta > 0)
      }}
      onTouchStart={(event) => {
        touchStart.current = event.touches[0].clientY
      }}
    >
      <h2 className="px-1 text-[24px] font-extrabold tracking-[-0.04em] text-[#346538]">
        일정 캘린더
      </h2>
      <section className={`mt-5 rounded-[20px] bg-white p-4 shadow-[0_5px_18px_rgba(36,58,39,.06)] transition-all ${expanded ? "max-h-[250px] overflow-hidden opacity-90" : ""}`}>
        <div className="flex items-center justify-center gap-4">
          <button aria-label="이전 달" className="grid h-8 w-8 place-items-center rotate-180 text-[#586159]" onClick={() => changeMonth(-1)} type="button"><Icon name="arrowRight" size={17} /></button>
          <button className="flex items-center gap-1 text-[15px] font-extrabold text-[#29312b]" onClick={() => setMonthPickerOpen(true)} type="button">
            {year}년 {month}월 <Icon name="chevron" size={14} />
          </button>
          <button aria-label="다음 달" className="grid h-8 w-8 place-items-center text-[#586159]" onClick={() => changeMonth(1)} type="button"><Icon name="arrowRight" size={17} /></button>
        </div>
        <div className="mt-4 grid grid-cols-7 text-center text-[9px] font-bold">
          {["일", "월", "화", "수", "목", "금", "토"].map((day, index) => (
            <span className={index === 0 ? "text-[#c85f57]" : index === 6 ? "text-[#557fa3]" : "text-[#858d87]"} key={day}>{day}</span>
          ))}
        </div>
        <div className="mt-2 grid grid-cols-7">
          {cells.map((day, index) => {
            if (!day) return <span className="h-[58px]" key={`empty-${index}`} />
            const key = dateKey(day)
            const event = activeRecords.find((record) => record.movingDate === key)
            const manual = manualDays.find((item) => item.date === key)
            const managedStatus = managedDateStatuses[key]
            const isHoliday = holidays.includes(day)
            return (
              <button
                className={`relative flex h-[58px] flex-col items-start border-t border-[#f0f2f0] p-1 text-left ${selectedDay === day ? "bg-[#edf3ed]" : ""}`}
                key={day}
                onClick={() => setSelectedDay(day)}
                type="button"
              >
                <span className="relative flex h-5 w-4 shrink-0 items-end justify-center">
                  {noMoveDays.includes(day) && (
                    <span className="absolute left-1/2 top-0 h-1.5 w-1.5 -translate-x-1/2 rounded-full bg-[#4f80ac]" />
                  )}
                  {isHoliday && (
                    <span className="absolute left-1/2 top-0 h-1.5 w-1.5 -translate-x-1/2 rounded-full bg-[#c85f57]" />
                  )}
                  <span className={`text-[10px] font-bold ${isHoliday || index % 7 === 0 ? "text-[#c85f57]" : "text-[#555e57]"}`}>
                    {day}
                  </span>
                </span>
                {event && (
                  <span className={`mt-1 block truncate rounded px-1 py-0.5 text-[7px] font-bold text-white ${event.status === "승인 대기" ? "bg-[#4f80ac]" : event.status === "예약 확정" ? "bg-[#4f8b55]" : "bg-[#59635b]"}`}>{event.name}</span>
                )}
                {manual && <span className={`mt-1 block truncate rounded px-1 py-0.5 text-[7px] font-bold text-white ${manual.category === "업체 휴무일" ? "bg-[#343a35]" : manual.category === "견적 상담" ? "bg-[#7a6db0]" : "bg-[#7a837c]"}`}>{manual.title}</span>}
                {managedStatus && (
                  <span className={`mt-1 block truncate rounded px-1 py-0.5 text-[7px] font-bold text-white ${managedStatus === "closed" ? "bg-[#343a35]" : "bg-[#F57C00]"}`}>
                    {managedStatus === "closed" ? "정기 휴무" : "예약 불가"}
                  </span>
                )}
              </button>
            )
          })}
        </div>
        <div className="mt-3 flex flex-wrap gap-3 border-t border-[#edf0ed] pt-3 text-[8px] text-[#727a74]">
          <span><b className="mr-1 inline-block h-2 w-2 bg-[#343a35]" />업체 휴무일</span>
          <span><b className="mr-1 inline-block h-2 w-2 bg-[#F57C00]" />예약 불가</span>
          <span><b className="mr-1 inline-block h-2 w-2 bg-[#4f80ac]" />승인 대기</span>
          <span><b className="mr-1 inline-block h-2 w-2 bg-[#4f8b55]" />예약 확정</span>
          <span><b className="mr-1 inline-block h-2 w-2 bg-[#59635b]" />이사 완료</span>
          <span><b className="mr-1 inline-block h-2 w-2 bg-[#7a6db0]" />견적 상담</span>
          <span><b className="mr-1 inline-block h-2 w-2 rounded-full bg-[#4f80ac]" />손 없는 날</span>
          <span><b className="mr-1 inline-block h-2 w-2 rounded-full bg-[#c85f57]" />공휴일</span>
        </div>
      </section>

      <section className={`mt-4 rounded-[20px] bg-white p-5 shadow-[0_5px_18px_rgba(36,58,39,.06)] transition-all ${expanded ? "min-h-[470px]" : ""}`}>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-[10px] font-bold text-[#89918b]">{year}년 {month}월</p>
            <div className="mt-1 flex items-baseline gap-2">
              <h3 className="text-[17px] font-extrabold">{month}월 {selectedDay}일</h3>
              {noMoveDays.includes(selectedDay) && (
                <span className="text-[9px] font-bold text-[#4f80ac]">손 없는 날</span>
              )}
              {holidays.includes(selectedDay) && (
                <span className="text-[9px] font-bold text-[#c85f57]">공휴일</span>
              )}
            </div>
          </div>
          <button className="text-[9px] font-bold text-[#7b837d]" onClick={() => setExpanded((value) => !value)} type="button">{expanded ? "달력 펼치기" : "일정 펼치기"}</button>
        </div>
        <div className="mt-5 space-y-3">
          {daySchedules.map((record) => (
            <button className="flex w-full gap-3 text-left" key={record.id} onClick={() => setSelectedSchedule(record)} type="button">
              <span className="w-11 pt-3 text-[10px] font-bold text-[#687069]">{record.movingTime}</span>
              <span className={`flex-1 rounded-xl border-l-4 bg-[#f5f8f5] p-3 ${record.status === "승인 대기" ? "border-[#4f80ac]" : record.status === "예약 확정" ? "border-[#4f8b55]" : "border-[#59635b]"}`}><b className="block text-[11px]">{record.name}</b><small className="mt-1 block text-[9px] text-[#727a74]">{record.status} · {record.service}</small></span>
            </button>
          ))}
          {manualDays.filter((item) => item.date === selectedDate).map((item) => (
            <div className="relative" key={item.id}>
              <button className="flex w-full gap-3 text-left" onClick={() => setSelectedManual(item)} type="button"><span className="w-11 pt-3 text-[10px] font-bold">{item.time}</span><span className={`flex-1 rounded-xl border-l-4 bg-[#f3f4f3] p-3 pr-10 text-[11px] font-bold ${item.category === "업체 휴무일" ? "border-[#343a35]" : item.category === "견적 상담" ? "border-[#7a6db0]" : "border-[#7a837c]"}`}>{item.title}<small className="mt-1 block font-normal text-[#7a827c]">{item.category}{item.place ? ` · ${item.place}` : ""}</small></span></button>
              {item.userCreated && (
                <button
                  aria-label={`${item.title} 일정 삭제`}
                  className="absolute right-2 top-2 grid h-8 w-8 place-items-center rounded-lg text-[#c7635a] hover:bg-[#fbefed]"
                  onClick={() => setDeletingManual(item)}
                  type="button"
                >
                  <Icon name="trash" size={15} />
                </button>
              )}
            </div>
          ))}
          {managedDateStatuses[selectedDate] && (
            <div className="flex gap-3">
              <span className="w-11 pt-3 text-[10px] font-bold">종일</span>
              <span className={`flex-1 rounded-xl border-l-4 bg-[#f3f4f3] p-3 text-[11px] font-bold ${managedDateStatuses[selectedDate] === "closed" ? "border-[#343a35]" : "border-[#F57C00]"}`}>
                {managedDateStatuses[selectedDate] === "closed" ? "업체 휴무일" : "이사 예약 불가능"}
              </span>
            </div>
          )}
          {!daySchedules.length && !manualDays.some((item) => item.date === selectedDate) && !managedDateStatuses[selectedDate] && <p className="py-8 text-center text-[10px] text-[#929994]">등록된 일정이 없습니다.</p>}
        </div>
        <button className="mx-auto mt-5 block rounded-full border border-[#cfd6d0] px-5 py-2.5 text-[10px] font-bold text-[#346538]" onClick={() => { resetManualForm(); setManualModal(true) }} type="button">+ 일정 등록</button>
      </section>

      {monthPickerOpen && (
        <div className="absolute inset-x-0 bottom-[82px] top-[68px] z-50 grid place-items-center bg-[#1f2d21]/45 p-5 backdrop-blur-[2px]">
          <div className="w-full rounded-[20px] bg-white p-5">
            <button className="mx-auto flex items-center gap-1 text-[16px] font-extrabold" onClick={() => setGridMode((value) => !value)} type="button">{tempYear}년 {tempMonth}월 <Icon className="rotate-180" name="chevron" size={15} /></button>
            {gridMode ? (
              <div className="mt-5 grid grid-cols-3 gap-2">{Array.from({ length: 12 }, (_, index) => index + 1).map((value) => <button className={`h-11 rounded-xl text-[11px] font-bold ${tempMonth === value ? "bg-[#346538] text-white" : "bg-[#f3f5f3]"}`} key={value} onClick={() => setTempMonth(value)} type="button">{value}월</button>)}</div>
            ) : (
              <div className="mt-5 grid grid-cols-3 gap-2">
                <label className="text-center">
                  <span className="mb-1.5 block text-[9px] font-bold text-[#858d87]">년</span>
                  <select className="h-12 w-full rounded-xl bg-[#f5f6f5] px-2 text-center text-[12px] font-bold" onChange={(event) => setTempYear(Number(event.target.value))} value={tempYear}>{[2024, 2025, 2026, 2027, 2028].map((value) => <option key={value}>{value}</option>)}</select>
                </label>
                <label className="text-center">
                  <span className="mb-1.5 block text-[9px] font-bold text-[#858d87]">월</span>
                  <select className="h-12 w-full rounded-xl bg-[#f5f6f5] px-2 text-center text-[12px] font-bold" onChange={(event) => setTempMonth(Number(event.target.value))} value={tempMonth}>{Array.from({ length: 12 }, (_, index) => index + 1).map((value) => <option key={value}>{value}</option>)}</select>
                </label>
                <label className="text-center">
                  <span className="mb-1.5 block text-[9px] font-bold text-[#858d87]">일</span>
                  <select className="h-12 w-full rounded-xl bg-[#f5f6f5] px-2 text-center text-[12px] font-bold" onChange={(event) => setSelectedDay(Number(event.target.value))} value={selectedDay}>{Array.from({ length: 31 }, (_, index) => index + 1).map((value) => <option key={value}>{value}</option>)}</select>
                </label>
              </div>
            )}
            <div className="mt-5 grid grid-cols-2 gap-2"><button className="h-11 rounded-xl border border-[#d9ded9] text-[11px] font-bold" onClick={() => setMonthPickerOpen(false)} type="button">취소</button><button className="h-11 rounded-xl bg-[#346538] text-[11px] font-bold text-white" onClick={() => { setYear(tempYear); setMonth(tempMonth); setMonthPickerOpen(false) }} type="button">완료</button></div>
          </div>
        </div>
      )}

      {selectedManual && (
        <div className="absolute inset-x-0 bottom-[82px] top-[68px] z-50 grid place-items-center bg-[#1f2d21]/45 p-5 backdrop-blur-[2px]">
          <div className="w-full rounded-[20px] bg-white p-5 shadow-2xl">
            <div className="flex items-center justify-between">
              <h3 className="text-[17px] font-extrabold">일정 상세</h3>
              <button
                aria-label="일정 상세 닫기"
                onClick={() => setSelectedManual(null)}
                type="button"
              >
                <Icon name="x" size={18} />
              </button>
            </div>
            <div className="mt-5 space-y-3 rounded-xl bg-[#f7f8f7] p-4 text-[10px]">
              <p><b>제목</b><span className="float-right">{selectedManual.title}</span></p>
              <p><b>분류</b><span className="float-right">{selectedManual.category}</span></p>
              <p><b>요일·날짜</b><span className="float-right">{selectedManual.date}</span></p>
              <p><b>시간</b><span className="float-right">{selectedManual.time}</span></p>
              <p><b>장소</b><span className="float-right">{selectedManual.place || "미등록"}</span></p>
            </div>
            {linkedManualMember && (
              <div className="mt-3 rounded-xl border border-[#e1e5e1] p-4">
                <p className="text-[10px] font-extrabold text-[#346538]">연결 회원</p>
                <p className="mt-2 text-[10px] font-bold">
                  {linkedManualMember[0]}
                </p>
                <p className="mt-1 text-[9px] text-[#7c847e]">
                  {linkedManualMember[2]}
                </p>
              </div>
            )}
            {linkedManualReservation && (
              <div className="mt-3 rounded-xl border border-[#e1e5e1] p-4">
                <div className="flex items-center justify-between">
                  <p className="text-[10px] font-extrabold text-[#346538]">연결 예약</p>
                  <span className={`rounded-full px-2 py-1 text-[8px] font-bold ${reservationTone[linkedManualReservation.status]}`}>
                    {linkedManualReservation.status}
                  </span>
                </div>
                <p className="mt-2 truncate text-[9px] text-[#626a64]">
                  {linkedManualReservation.origin} → {linkedManualReservation.destination}
                </p>
              </div>
            )}
            {linkedManualReservation && (
              <button
                className="mt-5 h-11 w-full rounded-xl bg-[#346538] text-[11px] font-bold text-white"
                onClick={() => {
                  setSelectedSchedule(linkedManualReservation)
                  setSelectedManual(null)
                  setFullDetailOpen(true)
                }}
                type="button"
              >
                상세 보기
              </button>
            )}
          </div>
        </div>
      )}

      {selectedSchedule && !fullDetailOpen && (
        <div className="absolute inset-x-0 bottom-[82px] top-[68px] z-50 grid place-items-center bg-[#1f2d21]/45 p-5 backdrop-blur-[2px]">
          <div className="w-full rounded-[20px] bg-white p-5">
            <div className="flex items-center justify-between"><h3 className="text-[17px] font-extrabold">예약 상세 정보</h3><button aria-label="닫기" onClick={() => setSelectedSchedule(null)} type="button"><Icon name="x" size={18} /></button></div>
            <div className="mt-4 flex items-center justify-between"><span className={`rounded-full px-2 py-1 text-[9px] font-bold ${getReservationDisplayStatus(selectedSchedule.status) === "예약 취소" ? "bg-[#fbefed] text-[#b9574f]" : "bg-[#edf4ed] text-[#346538]"}`}>{getReservationDisplayStatus(selectedSchedule.status)}</span><span className="text-[9px] text-[#858d87]">신청일 {selectedSchedule.appliedDate}</span></div>
            <div className="mt-4 space-y-3">
              <section className="rounded-xl bg-[#f7f8f7] p-4"><h4 className="text-[11px] font-extrabold text-[#346538]">연동 정보</h4><div className="mt-3 grid grid-cols-[88px_1fr] gap-y-2 text-[10px]"><span className="font-bold text-[#737b75]">회원 정보</span><span>{selectedSchedule.name}</span><span className="font-bold text-[#737b75]">견적 번호</span><span>EST-{String(selectedEstimate?.id || 1).padStart(4, "0")}</span><span className="font-bold text-[#737b75]">예약 번호</span><span>RSV-{String(selectedSchedule.id).padStart(4, "0")}</span></div></section>
              <section className="rounded-xl bg-[#f7f8f7] p-4"><h4 className="text-[11px] font-extrabold text-[#346538]">예약 상세 내역</h4><div className="mt-3 grid grid-cols-[88px_1fr] gap-y-2 text-[10px]"><span className="font-bold text-[#737b75]">이사 유형</span><span>{selectedSchedule.service}</span><span className="font-bold text-[#737b75]">이사일</span><span>{selectedSchedule.movingDate || "-"}</span><span className="font-bold text-[#737b75]">이사 시간</span><span>{selectedSchedule.movingTime || "-"}</span><span className="font-bold text-[#737b75]">출발지</span><span>{selectedSchedule.origin}</span><span className="font-bold text-[#737b75]">도착지</span><span>{selectedSchedule.destination}</span></div></section>
            </div>
            <button className="mt-5 h-11 w-full rounded-xl bg-[#346538] text-[11px] font-bold text-white" onClick={() => setFullDetailOpen(true)} type="button">상세 보기</button>
          </div>
        </div>
      )}

      {fullDetailOpen && selectedSchedule && selectedEstimate && (
        <div className="absolute inset-x-0 bottom-[82px] top-[68px] z-[60] overflow-y-auto bg-[#e8ebe8] p-4">
          <div className="mb-3 flex items-center justify-between"><h3 className="text-[16px] font-extrabold">견적 상세</h3><button aria-label="견적 상세 닫기" className="grid h-9 w-9 place-items-center rounded-full bg-white" onClick={() => { setFullDetailOpen(false); setSelectedSchedule(null) }} type="button"><Icon name="x" size={17} /></button></div>
          <EstimateDocumentViewer editable={false} record={selectedEstimate} />
        </div>
      )}

      {deletingManual && (
        <div className="absolute inset-x-0 bottom-[82px] top-[68px] z-[70] grid place-items-center bg-[#1f2d21]/45 p-6 backdrop-blur-[2px]">
          <div className="w-full rounded-[20px] bg-white p-6 text-center shadow-2xl">
            <h3 className="text-[17px] font-extrabold text-[#29312b]">
              정말 삭제하시겠습니까?
            </h3>
            <p className="mt-2 text-[10px] text-[#8b928d]">
              삭제된 데이터는 복구할 수 없습니다.
            </p>
            <div className="mt-6 grid grid-cols-2 gap-2">
              <button
                className="h-11 rounded-xl border border-[#d9ded9] text-[11px] font-bold text-[#69716b]"
                onClick={() => setDeletingManual(null)}
                type="button"
              >
                취소
              </button>
              <button
                className="h-11 rounded-xl bg-[#c75f56] text-[11px] font-bold text-white"
                onClick={() => {
                  setManualDays((items) =>
                    items.filter((item) => item.id !== deletingManual.id),
                  )
                  if (selectedManual?.id === deletingManual.id) {
                    setSelectedManual(null)
                  }
                  setDeletingManual(null)
                }}
                type="button"
              >
                삭제
              </button>
            </div>
          </div>
        </div>
      )}

      {manualModal && (
        <div className="absolute inset-x-0 bottom-[82px] top-[68px] z-50 grid place-items-center overflow-y-auto bg-[#1f2d21]/45 p-5 backdrop-blur-[2px]">
          <div className="my-auto w-full rounded-[20px] bg-white p-5 shadow-2xl">
            <div className="flex items-center justify-between">
              <h3 className="text-[17px] font-extrabold">일정 등록</h3>
              <button aria-label="일정 등록 닫기" onClick={() => setManualModal(false)} type="button"><Icon name="x" size={18} /></button>
            </div>
            <div className="mt-4 max-h-[480px] space-y-3 overflow-y-auto pr-1">
              <label className="block"><span className="mb-1 block text-[9px] font-bold">제목 <b className="text-[#c75f56]">*</b></span><input className="h-10 w-full rounded-lg border border-[#dfe4df] px-3 text-[11px] outline-none focus:border-[#346538]" onChange={(event) => setManualForm((form) => ({ ...form, title: event.target.value }))} placeholder="일정 제목을 입력하세요" value={manualForm.title} /></label>
              <div className="block">
                <span className="mb-1 block text-[9px] font-bold">분류 <b className="text-[#c75f56]">*</b></span>
                <button aria-expanded={categoryPickerOpen} className="flex h-10 w-full items-center justify-between rounded-lg border border-[#dfe4df] bg-white px-3 text-left text-[11px]" onClick={() => setCategoryPickerOpen((open) => !open)} type="button">
                  <span className={manualForm.category ? "font-semibold text-[#424a44]" : "text-[#939a95]"}>{manualForm.category || "분류를 선택하세요"}</span>
                  <Icon className={categoryPickerOpen ? "rotate-180" : ""} name="chevron" size={14} />
                </button>
                {categoryPickerOpen && (
                  <div className="mt-1.5 overflow-hidden rounded-lg border border-[#dfe4df] bg-white shadow-[0_8px_20px_rgba(36,58,39,.12)]">
                    {["견적 상담", "기타", "직접 입력"].map((category) => (
                      <button
                        className="flex h-10 w-full items-center border-b border-[#edf0ed] px-3 text-left text-[11px] font-semibold text-[#59625b] last:border-none hover:bg-[#f5f7f5]"
                        key={category}
                        onClick={() => {
                          const custom = category === "직접 입력"
                          setCustomCategoryMode(custom)
                          setManualForm((form) => ({ ...form, category: custom ? "" : category }))
                          setCategoryPickerOpen(false)
                        }}
                        type="button"
                      >
                        {category}
                      </button>
                    ))}
                  </div>
                )}
                {customCategoryMode && (
                  <input
                    autoFocus
                    className="mt-2 h-10 w-full rounded-lg border border-[#dfe4df] px-3 text-[11px] outline-none focus:border-[#346538]"
                    onChange={(event) => setManualForm((form) => ({ ...form, category: event.target.value }))}
                    placeholder="분류명을 직접 입력하세요"
                    value={manualForm.category}
                  />
                )}
              </div>
              <div className="grid grid-cols-2 gap-2">
                <label className="block"><span className="mb-1 block text-[9px] font-bold">요일·날짜 <b className="text-[#c75f56]">*</b></span><input className="h-10 w-full rounded-lg border border-[#dfe4df] px-2 text-[10px]" onChange={(event) => setManualForm((form) => ({ ...form, date: event.target.value }))} type="date" value={manualForm.date} /></label>
                <label className="block"><span className="mb-1 block text-[9px] font-bold">시간 <b className="text-[#c75f56]">*</b></span><input className="h-10 w-full rounded-lg border border-[#dfe4df] px-2 text-[10px]" onChange={(event) => setManualForm((form) => ({ ...form, time: event.target.value }))} type="time" value={manualForm.time} /></label>
              </div>
              <label className="block"><span className="mb-1 block text-[9px] font-bold">장소</span><input className="h-10 w-full rounded-lg border border-[#dfe4df] px-3 text-[11px]" onChange={(event) => setManualForm((form) => ({ ...form, place: event.target.value }))} placeholder="일정 장소를 입력하세요" value={manualForm.place} /></label>

              <div className="rounded-xl bg-[#f7f8f7] p-3">
                <p className="text-[10px] font-extrabold text-[#346538]">회원 연결</p>
                <input className="mt-2 h-9 w-full rounded-lg border border-[#dfe4df] bg-white px-3 text-[10px]" onChange={(event) => { setMemberQuery(event.target.value); setSelectedMemberId("") }} placeholder="회원 이름이나 휴대전화를 입력하세요" value={memberQuery} />
                {memberQuery && !selectedMemberId && (
                  <div className="mt-2 max-h-28 overflow-y-auto rounded-lg border border-[#e1e5e1] bg-white">
                    {memberResults.slice(0, 5).map((member) => (
                      <button className="flex w-full justify-between border-b border-[#edf0ed] px-3 py-2 text-left text-[9px] last:border-none" key={member[1]} onClick={() => { setSelectedMemberId(member[1]); setMemberQuery(`${member[0]} · ${member[2]}`); setReservationQuery("") }} type="button"><b>{member[0]}</b><span className="text-[#858d87]">{member[2]}</span></button>
                    ))}
                  </div>
                )}
              </div>

              <div className="rounded-xl bg-[#f7f8f7] p-3">
                <p className="text-[10px] font-extrabold text-[#346538]">예약 내역 연결</p>
                <input className="mt-2 h-9 w-full rounded-lg border border-[#dfe4df] bg-white px-3 text-[10px]" onChange={(event) => setReservationQuery(event.target.value)} placeholder="이름, 휴대전화 또는 주소를 입력하세요" value={reservationQuery} />
                {(selectedMemberId || reservationQuery) && (
                  <div className="mt-2 max-h-36 overflow-y-auto rounded-lg border border-[#e1e5e1] bg-white">
                    {reservationResults.slice(0, 6).map((record) => (
                      <button className={`w-full border-b border-[#edf0ed] px-3 py-2 text-left text-[9px] last:border-none ${selectedReservationId === record.id ? "bg-[#edf3ed]" : ""}`} key={record.id} onClick={() => { setSelectedReservationId(record.id); setReservationQuery(`${record.name} · ${record.origin}`); if (!selectedMemberId) { setSelectedMemberId(record.userId); setMemberQuery(`${record.name} · ${record.phone}`) } }} type="button"><b className="block">{record.name} · {record.phone}</b><span className="mt-1 block truncate text-[#7d857f]">{record.origin} → {record.destination}</span></button>
                    ))}
                    {!reservationResults.length && <p className="p-3 text-center text-[9px] text-[#939a95]">일치하는 예약이 없습니다.</p>}
                  </div>
                )}
              </div>
            </div>
            <div className="mt-5 grid grid-cols-2 gap-2">
              <button className="h-11 rounded-xl border border-[#d9ded9] text-[11px] font-bold" onClick={() => { resetManualForm(); setManualModal(false) }} type="button">취소</button>
              <button
                className="h-11 rounded-xl bg-[#346538] text-[11px] font-bold text-white disabled:cursor-not-allowed disabled:opacity-40"
                disabled={!manualForm.title.trim() || !manualForm.category || !manualForm.date || !manualForm.time}
                onClick={() => {
                  const [dateYear, dateMonth, dateDay] = manualForm.date.split("-")
                  setManualDays((items) => [
                    ...items,
                    {
                      id: Date.now(),
                      date: `${dateYear.slice(-2)}.${dateMonth}.${dateDay}`,
                      title: manualForm.title,
                      category: manualForm.category,
                      time: manualForm.time,
                      place: manualForm.place,
                      memberId: selectedMemberId || undefined,
                      reservationId: selectedReservationId || undefined,
                      userCreated: true,
                    },
                  ])
                  setYear(Number(dateYear))
                  setMonth(Number(dateMonth))
                  setSelectedDay(Number(dateDay))
                  resetManualForm()
                  setManualModal(false)
                }}
                type="button"
              >
                등록
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function ScheduleManagement({
  records,
  statuses,
  onSave,
  onFire,
}: {
  records: ReservationRecord[]
  statuses: Record<string, ManagedDateStatus>
  onSave: (statuses: Record<string, ManagedDateStatus>) => void
  onFire?: (conditionKey: string) => void
}) {
  const [year, setYear] = useState(2026)
  const [month, setMonth] = useState(9)
  const [editing, setEditing] = useState(false)
  const [draft, setDraft] = useState<Record<string, ManagedDateStatus>>(statuses)
  const [selectedDate, setSelectedDate] = useState("")
  const [selectedStatus, setSelectedStatus] = useState<ManagedDateStatus>("unavailable")
  const [dateModal, setDateModal] = useState(false)
  const [confirmModal, setConfirmModal] = useState(false)
  const [monthModal, setMonthModal] = useState(false)
  const [gridMode, setGridMode] = useState(false)
  const [openDatePicker, setOpenDatePicker] = useState<"year" | "month" | null>(null)
  const [tempYear, setTempYear] = useState(2026)
  const [tempMonth, setTempMonth] = useState(9)
  const firstDay = new Date(year, month - 1, 1).getDay()
  const daysInMonth = new Date(year, month, 0).getDate()
  const cells = Array.from({ length: 42 }, (_, index) => {
    const day = index - firstDay + 1
    return day >= 1 && day <= daysInMonth ? day : null
  })
  const currentStatuses = editing ? draft : statuses
  const dateKey = (day: number) =>
    `${String(year).slice(-2)}.${String(month).padStart(2, "0")}.${String(day).padStart(2, "0")}`
  const changeMonth = (offset: number) => {
    const next = new Date(year, month - 1 + offset, 1)
    setYear(next.getFullYear())
    setMonth(next.getMonth() + 1)
  }
  const beginEdit = () => {
    setDraft({ ...statuses })
    setEditing(true)
  }
  const cancelEdit = () => {
    setDraft({ ...statuses })
    setEditing(false)
    setConfirmModal(false)
  }
  const cancelDateStatus = () => {
    setDraft((current) => {
      const next = { ...current }
      delete next[selectedDate]
      return next
    })
    setDateModal(false)
  }

  return (
    <div className="px-4 pb-28 pt-6">
      <h2 className="px-1 text-[24px] font-extrabold tracking-[-0.04em] text-[#346538]">
        일정 관리
      </h2>
      <section className="mt-5 rounded-[20px] bg-white p-4 shadow-[0_5px_18px_rgba(36,58,39,.06)]">
        <div className="relative flex items-center justify-center gap-4">
          <button aria-label="이전 달" className="grid h-8 w-8 place-items-center rotate-180" onClick={() => changeMonth(-1)} type="button"><Icon name="arrowRight" size={17} /></button>
          <button className="flex items-center gap-1 text-[15px] font-extrabold" onClick={() => setMonthModal(true)} type="button">{year}년 {month}월 <Icon name="chevron" size={14} /></button>
          <button aria-label="다음 달" className="grid h-8 w-8 place-items-center" onClick={() => changeMonth(1)} type="button"><Icon name="arrowRight" size={17} /></button>
          {editing ? (
            <button className="absolute right-0 text-[10px] font-extrabold text-[#346538]" onClick={() => setConfirmModal(true)} type="button">수정 완료</button>
          ) : (
            <button aria-label="일정 수정" className="absolute right-0 grid h-8 w-8 place-items-center text-[#346538]" onClick={beginEdit} type="button"><Icon name="edit" size={17} /></button>
          )}
        </div>
        <div className="mt-4 grid grid-cols-7 text-center text-[9px] font-bold">
          {["일", "월", "화", "수", "목", "금", "토"].map((day, index) => <span className={index === 0 ? "text-[#c85f57]" : index === 6 ? "text-[#557fa3]" : "text-[#858d87]"} key={day}>{day}</span>)}
        </div>
        <div className="mt-2 grid grid-cols-7">
          {cells.map((day, index) => {
            if (!day) return <span className="h-[62px]" key={`empty-${index}`} />
            const key = dateKey(day)
            const state = currentStatuses[key]
            const event = records.find((record) => record.movingDate === key && ["승인 대기", "예약 확정", "이사 완료"].includes(record.status))
            return (
              <button
                className={`flex h-[62px] flex-col items-start border-t border-[#f0f2f0] p-1 text-left ${editing ? "hover:bg-[#f4f7f4]" : ""}`}
                key={day}
                onClick={() => {
                  if (!editing) return
                  setSelectedDate(key)
                  setSelectedStatus(state || "unavailable")
                  setDateModal(true)
                }}
                type="button"
              >
                <span className={`h-5 text-[10px] font-bold ${index % 7 === 0 ? "text-[#c85f57]" : "text-[#555e57]"}`}>{day}</span>
                {state && <span className={`block w-full truncate rounded px-1 py-0.5 text-[7px] font-bold text-white ${state === "closed" ? "bg-[#343a35]" : "bg-[#F57C00]"}`}>{state === "closed" ? "정기 휴무" : "예약 불가"}</span>}
                {!state && event && <span className="block w-full truncate rounded bg-[#7e8a80] px-1 py-0.5 text-[7px] font-bold text-white">{event.name}</span>}
              </button>
            )
          })}
        </div>
        <div className="mt-4 flex gap-4 border-t border-[#edf0ed] pt-3 text-[8px] text-[#727a74]">
          <span><b className="mr-1 inline-block h-2 w-2 bg-[#343a35]" />업체 휴무일</span>
          <span><b className="mr-1 inline-block h-2 w-2 bg-[#F57C00]" />이사 예약 불가능</span>
        </div>
      </section>

      {editing && (
        <div className="absolute bottom-[92px] left-1/2 z-30 flex -translate-x-1/2 items-center gap-2 whitespace-nowrap rounded-full bg-[#263129]/85 px-4 py-2.5 text-[10px] font-bold text-white shadow-lg">
          <Icon name="edit" size={14} />
          현재 수정 중입니다
        </div>
      )}

      {dateModal && (
        <div className="absolute inset-x-0 bottom-[82px] top-[68px] z-50 grid place-items-center bg-[#1f2d21]/45 p-5 backdrop-blur-[2px]">
          <div className="w-full rounded-[20px] bg-white p-5 shadow-2xl">
            <div className="flex items-center justify-between"><h3 className="text-[17px] font-extrabold">날짜 상태 설정</h3><button aria-label="닫기" onClick={() => setDateModal(false)} type="button"><Icon name="x" size={18} /></button></div>
            <p className="mt-2 text-[10px] text-[#858d87]">{selectedDate}</p>
            <div className="mt-5 space-y-3">
              {[["unavailable", "이사 예약 불가능"], ["closed", "업체 휴무일"]].map(([value, label]) => (
                <label className={`flex cursor-pointer items-center gap-3 rounded-xl border p-4 text-[12px] font-bold ${selectedStatus === value ? "border-[#346538] bg-[#edf3ed]" : "border-[#dfe4df]"}`} key={value}>
                  <input checked={selectedStatus === value} onChange={() => setSelectedStatus(value as ManagedDateStatus)} type="radio" />
                  {label}
                </label>
              ))}
            </div>
            <div className={`mt-5 grid gap-2 ${draft[selectedDate] ? "grid-cols-2" : "grid-cols-1"}`}>
              {draft[selectedDate] && (
                <button className="h-11 rounded-xl border border-[#d9ded9] text-[11px] font-bold text-[#59625b]" onClick={cancelDateStatus} type="button">등록 취소</button>
              )}
              <button className="h-11 rounded-xl bg-[#346538] text-[11px] font-bold text-white" onClick={() => { setDraft((current) => ({ ...current, [selectedDate]: selectedStatus })); onFire?.(selectedStatus === "closed" ? "일정 관리 · 업체 휴무일을 등록했을 시" : "일정 관리 · 이사 예약이 불가능 할 시"); setDateModal(false) }} type="button">등록</button>
            </div>
          </div>
        </div>
      )}

      {confirmModal && (
        <div className="absolute inset-x-0 bottom-[82px] top-[68px] z-50 grid place-items-center bg-[#1f2d21]/45 p-6 backdrop-blur-[2px]">
          <div className="relative w-full rounded-[20px] bg-white p-6 text-center shadow-2xl">
            <button aria-label="확인 창 닫기" className="absolute right-5 top-5 grid h-7 w-7 place-items-center text-[#59625b]" onClick={() => setConfirmModal(false)} type="button"><Icon name="x" size={18} /></button>
            <h3 className="text-[17px] font-extrabold">정말 수정 하시겠습니까?</h3>
            <p className="mt-2 text-[10px] text-[#8b928d]">수정된 데이터는 복구할 수 없습니다.</p>
            <div className="mt-6 grid grid-cols-2 gap-2">
              <button className="h-11 rounded-xl border border-[#d9ded9] text-[11px] font-bold" onClick={cancelEdit} type="button">취소</button>
              <button className="h-11 rounded-xl bg-[#346538] text-[11px] font-bold text-white" onClick={() => { onSave(draft); setEditing(false); setConfirmModal(false) }} type="button">저장</button>
            </div>
          </div>
        </div>
      )}

      {monthModal && (
        <div className="absolute inset-x-0 bottom-[82px] top-[68px] z-50 grid place-items-center bg-[#1f2d21]/45 p-5">
          <div className="w-full rounded-[20px] bg-white p-5">
            <button className="mx-auto flex items-center gap-1 text-[16px] font-extrabold" onClick={() => { setGridMode((value) => !value); setOpenDatePicker(null) }} type="button">{tempYear}년 {tempMonth}월 <Icon className="rotate-180" name="chevron" size={15} /></button>
            {gridMode ? (
              <div className="mt-5 grid grid-cols-3 gap-2">
                {Array.from({ length: 12 }, (_, index) => index + 1).map((value) => <button className={`h-11 rounded-xl text-[11px] font-bold ${tempMonth === value ? "bg-[#346538] text-white" : "bg-[#f3f5f3]"}`} key={value} onClick={() => setTempMonth(value)} type="button">{value}월</button>)}
              </div>
            ) : (
              <div className="relative mt-5 grid grid-cols-2 gap-2">
                <div className="relative">
                  <button aria-expanded={openDatePicker === "year"} className="flex h-12 w-full items-center justify-center gap-1 rounded-xl bg-[#f5f6f5] text-[12px] font-bold" onClick={() => setOpenDatePicker((current) => current === "year" ? null : "year")} type="button">{tempYear}년 <Icon name="chevron" size={13} /></button>
                  {openDatePicker === "year" && (
                    <div className="absolute left-0 right-0 top-14 z-20 max-h-44 overflow-y-auto rounded-xl border border-[#dfe4df] bg-white p-1.5 shadow-[0_10px_28px_rgba(36,58,39,.16)]">
                      {Array.from({ length: 21 }, (_, index) => 2015 + index).map((value) => <button className={`h-9 w-full rounded-lg text-[11px] font-bold ${tempYear === value ? "bg-[#edf3ed] text-[#346538]" : "text-[#59625b]"}`} key={value} onClick={() => { setTempYear(value); setOpenDatePicker(null) }} type="button">{value}년</button>)}
                    </div>
                  )}
                </div>
                <div className="relative">
                  <button aria-expanded={openDatePicker === "month"} className="flex h-12 w-full items-center justify-center gap-1 rounded-xl bg-[#f5f6f5] text-[12px] font-bold" onClick={() => setOpenDatePicker((current) => current === "month" ? null : "month")} type="button">{tempMonth}월 <Icon name="chevron" size={13} /></button>
                  {openDatePicker === "month" && (
                    <div className="absolute left-0 right-0 top-14 z-20 max-h-44 overflow-y-auto rounded-xl border border-[#dfe4df] bg-white p-1.5 shadow-[0_10px_28px_rgba(36,58,39,.16)]">
                      {Array.from({ length: 12 }, (_, index) => index + 1).map((value) => <button className={`h-9 w-full rounded-lg text-[11px] font-bold ${tempMonth === value ? "bg-[#edf3ed] text-[#346538]" : "text-[#59625b]"}`} key={value} onClick={() => { setTempMonth(value); setOpenDatePicker(null) }} type="button">{value}월</button>)}
                    </div>
                  )}
                </div>
              </div>
            )}
            <div className="mt-5 grid grid-cols-2 gap-2"><button className="h-11 rounded-xl border border-[#d9ded9] text-[11px] font-bold" onClick={() => { setMonthModal(false); setOpenDatePicker(null) }} type="button">취소</button><button className="h-11 rounded-xl bg-[#346538] text-[11px] font-bold text-white" onClick={() => { setYear(tempYear); setMonth(tempMonth); setMonthModal(false); setOpenDatePicker(null) }} type="button">완료</button></div>
          </div>
        </div>
      )}
    </div>
  )
}

function ReservationManagement({
  estimates,
  records,
  onChangeRecords,
  selectedReservationId,
  onSelectedReservationOpened,
  onFire,
}: {
  estimates: EstimateRecord[]
  records: ReservationRecord[]
  onChangeRecords: (records: ReservationRecord[]) => void
  selectedReservationId?: number | null
  onSelectedReservationOpened?: () => void
  onFire?: (conditionKey: string) => void
}) {
  const [filter, setFilter] = useState("전체")
  const [query, setQuery] = useState("")
  const [searchOpen, setSearchOpen] = useState(false)
  const [page, setPage] = useState(1)
  const [selected, setSelected] = useState<ReservationRecord | null>(null)
  useEffect(() => {
    if (!selectedReservationId) return
    const record = records.find((item) => item.id === selectedReservationId)
    if (record) setSelected(record)
    onSelectedReservationOpened?.()
  }, [selectedReservationId, records, onSelectedReservationOpened])
  const statuses = ["예약 완료", "예약 취소"] as const
  const getDisplayStatus = (status: ReservationStatus) =>
    status === "반려" ? "예약 취소" : "예약 완료"
  const getPaymentStatus = (record: ReservationRecord) =>
    record.status === "반려" ? "결제 취소" : record.paymentStatus || "결제 대기"
  const getLinkedEstimate = (record: ReservationRecord) => {
    const linkedEstimateId = ((record.id - 1) % 11) + 1
    return estimates.find((estimate) => estimate.id === linkedEstimateId)
      || (estimates.length ? estimates[(record.id - 1) % estimates.length] : undefined)
  }
  const getDepositAmount = (record: ReservationRecord) => {
    const deposit = getLinkedEstimate(record)
      ? getEstimateDocument(getLinkedEstimate(record)!).deposit
      : "0"
    const amount = Number(deposit.replace(/[^\d]/g, ""))
    return `${Number.isFinite(amount) ? amount.toLocaleString("ko-KR") : "0"}원`
  }
  const counts = {
    "예약 완료": records.filter((record) => getDisplayStatus(record.status) === "예약 완료").length,
    "예약 취소": records.filter((record) => getDisplayStatus(record.status) === "예약 취소").length,
  }
  const filtered = records
    .filter((record) => filter === "전체" || getDisplayStatus(record.status) === filter)
    .filter(
      (record) =>
        !query ||
        `${record.name}${record.phone}${record.appliedDate}`
          .toLowerCase()
          .includes(query.toLowerCase()),
    )
    .sort((a, b) => b.appliedDate.localeCompare(a.appliedDate))
  const pageCount = Math.max(1, Math.ceil(filtered.length / 4))
  const visible = filtered.slice((page - 1) * 4, page * 4)
  const reset = () => {
    setFilter("전체")
    setQuery("")
    setPage(1)
  }

  return (
    <div className="space-y-5 px-4 pb-28 pt-6">
      <h2 className="px-1 text-[24px] font-extrabold tracking-[-0.04em] text-[#346538]">
        예약 관리
      </h2>

      <section className="overflow-visible rounded-[20px] bg-white shadow-[0_5px_18px_rgba(36,58,39,.06)]">
        <div className="p-4">
          <h3 className="text-[16px] font-extrabold text-[#29312b]">예약 목록</h3>
          <div className="relative mt-3 flex items-center justify-between">
            <select
              className="h-9 rounded-lg border border-[#dfe4df] bg-white px-2 text-[10px] font-semibold"
              onChange={(event) => { setFilter(event.target.value); setPage(1) }}
              value={filter}
            >
              <option>전체</option>
              {statuses.map((status) => <option key={status}>{status}</option>)}
            </select>
            <button
              aria-expanded={searchOpen}
              aria-label="예약 검색"
              className={`grid h-9 w-9 place-items-center rounded-lg border ${searchOpen ? "border-[#346538] bg-[#edf3ed] text-[#346538]" : "border-[#dfe4df] text-[#59625b]"}`}
              onClick={() => setSearchOpen((open) => !open)}
              type="button"
            >
              <Icon name="search" size={16} />
            </button>
            {searchOpen && (
              <div className="absolute bottom-11 right-0 z-10 flex items-center gap-2 rounded-xl border border-[#e1e5e1] bg-white p-3 shadow-[0_10px_28px_rgba(36,58,39,.15)]">
                <input
                  autoFocus
                  className="h-9 w-48 rounded-lg border border-[#dfe4df] px-3 text-[10px] outline-none focus:border-[#346538]"
                  onChange={(event) => { setQuery(event.target.value); setPage(1) }}
                  placeholder="이름, 휴대전화 또는 날짜를 입력하세요"
                  value={query}
                />
                <button className="flex h-9 items-center gap-1 rounded-lg bg-[#edf3ed] px-2 text-[9px] font-bold text-[#346538]" onClick={reset} type="button">
                  <Icon name="refresh" size={13} /> 초기화
                </button>
              </div>
            )}
          </div>
        </div>
        <div className="grid grid-cols-[28px_64px_1fr_68px_52px] bg-[#f7f8f7] px-2 py-2.5 text-center text-[8px] font-bold text-[#89908b]">
          <span>번호</span><span>분류</span><span>이름</span><span>결제</span><span>신청일</span>
        </div>
        <div className="px-2">
          {visible.map((record, index) => (
            <div
              className="grid cursor-pointer grid-cols-[28px_64px_1fr_68px_52px] items-center border-b border-[#edf0ed] py-3 text-[9px] last:border-none hover:bg-[#fafbfa]"
              key={record.id}
              onClick={() => setSelected(record)}
            >
              <span className="text-center text-[#8b928d]">{(page - 1) * 4 + index + 1}</span>
              <span className={`justify-self-center rounded-full px-2 py-1 text-[8px] font-bold ${getDisplayStatus(record.status) === "예약 취소" ? "bg-[#fbefed] text-[#b9574f]" : "bg-[#edf4ed] text-[#346538]"}`}>{getDisplayStatus(record.status)}</span>
              <span className="truncate px-1 font-semibold">{record.name}</span>
              <span className={`justify-self-center rounded-full px-1.5 py-1 text-[7px] font-bold ${getPaymentStatus(record) === "결제 완료" ? "bg-[#edf3ed] text-[#346538]" : getPaymentStatus(record) === "결제 취소" ? "bg-[#f1f2f1] text-[#737b75]" : "bg-[#fff4e8] text-[#9b7127]"}`}>{getPaymentStatus(record)}</span>
              <span className="text-center text-[8px] text-[#7e867f]">{record.appliedDate}</span>
            </div>
          ))}
        </div>
        {pageCount > 1 && (
          <div className="flex flex-wrap justify-center gap-1 border-t border-[#edf0ed] p-4">
            {Array.from({ length: pageCount }, (_, index) => index + 1).map((number) => (
              <button className={`grid h-8 w-8 place-items-center rounded-lg text-[10px] font-bold ${page === number ? "bg-[#346538] text-white" : "bg-[#f3f5f3] text-[#717972]"}`} key={number} onClick={() => setPage(number)} type="button">{number}</button>
            ))}
          </div>
        )}
      </section>

      <section className="rounded-[20px] bg-white p-5 shadow-[0_5px_18px_rgba(36,58,39,.06)]">
        <h3 className="text-[16px] font-extrabold text-[#29312b]">분류별 현황</h3>
        <div className="mt-5 space-y-4">
          {statuses.map((status, index) => {
            const count = counts[status]
            const percentage = records.length ? Math.round((count / records.length) * 100) : 0
            return (
              <div key={status}>
                <div className="mb-1.5 flex justify-between text-[10px]">
                  <span className="font-bold text-[#606862]">{status}</span>
                  <span className="font-semibold">{count}건 ({percentage}%)</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-[#edf0ed]">
                  <div className={`h-full rounded-full ${index === 0 ? "bg-[#4f8b55]" : "bg-[#d26b62]"}`} style={{ width: `${percentage}%` }} />
                </div>
              </div>
            )
          })}
        </div>
      </section>

      {selected && (
        <div className="absolute inset-x-0 bottom-[82px] top-[68px] z-50 grid place-items-center overflow-y-auto bg-[#1f2d21]/45 p-5 backdrop-blur-[2px]">
          <div className="my-auto w-full rounded-[20px] bg-white p-5 shadow-2xl">
            <div className="flex items-center justify-between"><h3 className="text-[17px] font-extrabold">예약 상세 정보</h3><button aria-label="닫기" onClick={() => setSelected(null)} type="button"><Icon name="x" size={18} /></button></div>
            <div className="mt-4 flex items-center justify-between"><span className={`rounded-full px-2 py-1 text-[9px] font-bold ${getDisplayStatus(selected.status) === "예약 취소" ? "bg-[#fbefed] text-[#b9574f]" : "bg-[#edf4ed] text-[#346538]"}`}>{getDisplayStatus(selected.status)}</span><span className="text-[9px] text-[#858d87]">신청일 {selected.appliedDate}</span></div>
            <div className="mt-4 space-y-3">
              <section className="rounded-xl bg-[#f7f8f7] p-4"><h4 className="text-[11px] font-extrabold text-[#346538]">연동 정보</h4><div className="mt-3 grid grid-cols-[88px_1fr] gap-y-2 text-[10px]"><span className="font-bold text-[#737b75]">회원 정보</span><span>{selected.name} · {selected.phone}</span><span className="font-bold text-[#737b75]">견적 번호</span><span>EST-{String(((selected.id - 1) % 11) + 1).padStart(4, "0")}</span><span className="font-bold text-[#737b75]">예약 번호</span><span>RSV-{String(selected.id).padStart(4, "0")}</span></div></section>
              <section className="rounded-xl bg-[#f7f8f7] p-4"><h4 className="text-[11px] font-extrabold text-[#346538]">예약 상세 내역</h4><div className="mt-3 grid grid-cols-[88px_1fr] gap-y-2 text-[10px]"><span className="font-bold text-[#737b75]">이사 유형</span><span>{selected.service}</span><span className="font-bold text-[#737b75]">이사일</span><span>{selected.movingDate || "-"}</span><span className="font-bold text-[#737b75]">이사 시간</span><span>{selected.movingTime || "-"}</span><span className="font-bold text-[#737b75]">출발지</span><span className="leading-4">{selected.origin}</span><span className="font-bold text-[#737b75]">도착지</span><span className="leading-4">{selected.destination}</span></div></section>
              <section className="rounded-xl border border-[#dfe6df] bg-white p-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-[11px] font-extrabold text-[#346538]">계약금 결제</h4>
                  <span className={`rounded-full px-2 py-1 text-[8px] font-bold ${getPaymentStatus(selected) === "결제 완료" ? "bg-[#edf3ed] text-[#346538]" : getPaymentStatus(selected) === "결제 취소" ? "bg-[#f1f2f1] text-[#737b75]" : "bg-[#fff4e8] text-[#9b7127]"}`}>
                    {getPaymentStatus(selected)}
                  </span>
                </div>
                <div className="mt-3 flex items-center justify-between text-[10px]">
                  <span className="font-bold text-[#737b75]">계약금 10%</span>
                  <strong className="text-[13px] text-[#29312b]">{getDepositAmount(selected)}</strong>
                </div>
                <p className="mt-2 rounded-lg bg-[#f7f8f7] px-3 py-2 text-[10px] font-bold text-[#59625b]">
                  {getPaymentStatus(selected) === "결제 완료"
                    ? `결제 완료(${getDepositAmount(selected)})`
                    : getPaymentStatus(selected) === "결제 취소"
                      ? "결제 취소"
                      : `결제 대기(${getDepositAmount(selected)})`}
                </p>
                {getPaymentStatus(selected) === "결제 대기" && (
                  <button
                    className="mt-3 h-10 w-full rounded-xl bg-[#346538] text-[10px] font-extrabold text-white"
                    onClick={() => {
                      const updated = { ...selected, paymentStatus: "결제 완료" as const }
                      onChangeRecords(records.map((record) => record.id === updated.id ? updated : record))
                      setSelected(updated)
                    }}
                    type="button"
                  >
                    결제 완료
                  </button>
                )}
              </section>
            </div>
          </div>
        </div>
      )}

    </div>
  )
}

type Member = {
  id: number
  name: string
  userId: string
  type: "고객" | "관리자"
  isNew: boolean
  phone: string
  joined: string
  address: string
  loginMethod?: "휴대전화" | "카카오톡" | "네이버" | "애플"
}

function MemberManagement({
  onNewMemberCountChange,
  onFire,
}: {
  onNewMemberCountChange: (count: number) => void
  onFire?: (conditionKey: string) => void
}) {
  const initialMembers: Member[] = [
    { id: 1, name: "홍길동", userId: "luxury", type: "고객", isNew: false, phone: "010-1234-5678", joined: "2023.02.14", address: "서울 강남구" },
    { id: 2, name: "김명품", userId: "luxury2", type: "관리자", isNew: false, phone: "010-2244-8811", joined: "", address: "" },
    { id: 3, name: "박철수", userId: "park789", type: "고객", isNew: false, phone: "010-7788-2200", joined: "2023.06.02", address: "경기 성남시" },
    { id: 4, name: "최지우", userId: "choi00", type: "고객", isNew: false, phone: "010-3377-9021", joined: "2024.01.17", address: "서울 송파구" },
    { id: 5, name: "이서준", userId: "seojun82", type: "고객", isNew: false, phone: "010-5892-1144", joined: "2023.09.10", address: "인천 연수구" },
    { id: 6, name: "정하윤", userId: "hayoon5", type: "고객", isNew: false, phone: "010-9834-1420", joined: "2024.02.22", address: "서울 마포구" },
    { id: 7, name: "강민준", userId: "minjun77", type: "고객", isNew: false, phone: "010-4471-3302", joined: "2024.04.03", address: "경기 수원시" },
    { id: 8, name: "윤서아", userId: "seoa11", type: "고객", isNew: false, phone: "010-8842-3199", joined: "2024.08.19", address: "서울 용산구" },
    { id: 9, name: "송지호", userId: "jiho90", type: "고객", isNew: true, phone: "010-1166-4201", joined: "2026.09.21", address: "대전 서구" },
    { id: 10, name: "한유진", userId: "yujin26", type: "고객", isNew: true, phone: "010-6673-9920", joined: "2026.09.22", address: "광주 북구" },
    { id: 11, name: "오도현", userId: "dohyun3", type: "고객", isNew: true, phone: "010-2207-6134", joined: "2026.09.24", address: "부산 해운대구" },
    { id: 12, name: "문지안", userId: "jian8", type: "고객", isNew: true, phone: "010-7318-4490", joined: "2026.09.26", address: "강원 춘천시" },
    { id: 13, name: "임지수", userId: "jisoo19", type: "고객", isNew: false, phone: "010-9901-7722", joined: "2022.05.01", address: "서울 서초구" },
    { id: 14, name: "김도윤", userId: "doyun24", type: "고객", isNew: false, phone: "010-3142-6678", joined: "2024.09.12", address: "경기 성남시" },
    { id: 15, name: "이지민", userId: "jimin31", type: "고객", isNew: false, phone: "010-5521-9034", joined: "2024.11.03", address: "서울 강동구" },
    { id: 16, name: "박서연", userId: "seoyeon6", type: "고객", isNew: false, phone: "010-7713-2088", joined: "2025.01.18", address: "인천 남동구" },
    { id: 17, name: "최현우", userId: "hyunwoo88", type: "고객", isNew: false, phone: "010-4055-7291", joined: "2025.03.24", address: "경기 고양시" },
    { id: 18, name: "정수빈", userId: "subin12", type: "고객", isNew: false, phone: "010-6320-1847", joined: "2025.06.11", address: "서울 광진구" },
    { id: 19, name: "강준호", userId: "junho75", type: "고객", isNew: true, phone: "010-9081-3362", joined: "2026.09.20", address: "대전 서구" },
    { id: 20, name: "윤채원", userId: "chaewon4", type: "고객", isNew: true, phone: "010-2466-8103", joined: "2026.09.21", address: "서울 성동구" },
    { id: 21, name: "송민재", userId: "minjae21", type: "고객", isNew: true, phone: "010-8642-5179", joined: "2026.09.23", address: "부산 연제구" },
    { id: 22, name: "한예린", userId: "yerin09", type: "고객", isNew: true, phone: "010-1937-6405", joined: "2026.09.25", address: "광주 서구" },
    { id: 23, name: "오승민", userId: "seungmin5", type: "고객", isNew: true, phone: "010-7254-3916", joined: "2026.09.27", address: "경기 수원시" },
  ]

  const [members, setMembers] = useState(initialMembers)
  const [filter, setFilter] = useState("전체")
  const [searchOpen, setSearchOpen] = useState(false)
  const [query, setQuery] = useState("")
  const [page, setPage] = useState(1)
  const [modal, setModal] = useState<"register" | "detail" | "edit" | "delete" | null>(null)
  const [selected, setSelected] = useState<Member | null>(null)
  const [registerTypePickerOpen, setRegisterTypePickerOpen] = useState(false)
  const [registerForm, setRegisterForm] = useState({
    name: "", phone: "", joined: "", type: "고객" as Member["type"],
  })

  useEffect(() => {
    onNewMemberCountChange(
      members.filter((member) => member.type === "고객" && member.isNew).length,
    )
  }, [members, onNewMemberCountChange])

  const filtered = members.filter(
    (member) =>
      (filter === "전체" || member.type === filter) &&
      (!query ||
        member.name.toLowerCase().includes(query.toLowerCase()) ||
        member.phone.includes(query)),
  )
  const pageCount = Math.max(1, Math.ceil(filtered.length / 4))
  const visible = filtered.slice((page - 1) * 4, page * 4)
  const reset = () => {
    setFilter("전체")
    setQuery("")
    setPage(1)
  }
  const openMemberModal = (
    type: "detail" | "edit" | "delete",
    member: Member,
  ) => {
    setSelected({ ...member })
    setModal(type)
  }

  return (
    <div className="space-y-5 px-4 pb-28 pt-6">
      <h2 className="px-1 text-[24px] font-extrabold tracking-[-0.04em] text-[#346538]">
        회원 관리
      </h2>
      <section className="overflow-visible rounded-[20px] bg-white shadow-[0_5px_18px_rgba(36,58,39,.06)]">
        <div className="p-4">
          <h3 className="text-[16px] font-extrabold text-[#29312b]">회원 관리 목록</h3>
          <div className="relative mt-3 flex items-center gap-2">
            <select
              className="h-9 rounded-lg border border-[#dfe4df] bg-white px-2 text-[10px] font-semibold"
              onChange={(event) => { setFilter(event.target.value); setPage(1) }}
              value={filter}
            >
              <option>전체</option><option>고객</option><option>관리자</option>
            </select>
            <div className="ml-auto flex items-center gap-1">
              <button className="h-9 rounded-lg bg-[#346538] px-3 text-[10px] font-bold text-white" onClick={() => { setRegisterTypePickerOpen(false); setModal("register") }} type="button">+ 등록</button>
              <button aria-expanded={searchOpen} aria-label="회원 검색" className={`grid h-9 w-9 place-items-center rounded-lg border ${searchOpen ? "border-[#346538] bg-[#edf3ed] text-[#346538]" : "border-[#dfe4df] text-[#59625b]"}`} onClick={() => setSearchOpen((open) => !open)} type="button">
                <Icon name="search" size={16} />
              </button>
            </div>
            {searchOpen && (
              <div className="absolute bottom-11 right-0 z-10 flex items-center gap-2 rounded-xl border border-[#e1e5e1] bg-white p-3 shadow-[0_10px_28px_rgba(36,58,39,.15)]">
                <input
                  autoFocus
                  className="h-9 w-44 rounded-lg border border-[#dfe4df] px-3 text-[10px] outline-none focus:border-[#346538]"
                  onChange={(event) => { setQuery(event.target.value); setPage(1) }}
                  placeholder="이름을 입력하세요"
                  value={query}
                />
                <button aria-label="검색 및 필터 초기화" className="flex h-9 shrink-0 items-center gap-1 rounded-lg bg-[#edf3ed] px-2.5 text-[9px] font-bold text-[#346538]" onClick={reset} type="button">
                  <Icon name="refresh" size={14} /> 초기화
                </button>
              </div>
            )}
          </div>
        </div>
        <div className="grid grid-cols-[32px_64px_1fr_55px] bg-[#f7f8f7] px-3 py-2.5 text-center text-[9px] font-bold text-[#89908b]">
          <span>번호</span><span>분류</span><span>이름</span><span>수정/삭제</span>
        </div>
        <div className="px-3">
          {visible.map((member, index) => (
            <div className="grid cursor-pointer grid-cols-[32px_64px_1fr_55px] items-center border-b border-[#edf0ed] py-3.5 text-[10px] last:border-none hover:bg-[#fafbfa]" key={member.id} onClick={() => openMemberModal("detail", member)}>
              <span className="text-center text-[#8b928d]">{(page - 1) * 4 + index + 1}</span>
              <span className={`justify-self-center rounded-full px-2 py-1 text-[9px] font-bold ${member.type === "관리자" ? "bg-[#fff1e8] text-[#ba6a35]" : "bg-[#edf3f8] text-[#4d7599]"}`}>{member.type}</span>
              <span className="truncate px-1 font-semibold text-[#424a44]">{member.name}</span>
              <div className="flex justify-end">
                <button aria-label={`${member.name} 권한 수정`} className="grid h-7 w-7 place-items-center text-[#4f80ac]" onClick={(event) => { event.stopPropagation(); openMemberModal("edit", member) }} type="button"><Icon name="edit" size={14} /></button>
                <button aria-label={`${member.name} 삭제`} className="grid h-7 w-7 place-items-center text-[#c7635a]" onClick={(event) => { event.stopPropagation(); openMemberModal("delete", member) }} type="button"><Icon name="trash" size={14} /></button>
              </div>
            </div>
          ))}
        </div>
        {pageCount > 1 && (
          <div className="flex justify-center gap-1 border-t border-[#edf0ed] p-4">
            {Array.from({ length: pageCount }, (_, index) => index + 1).map((number) => (
              <button className={`grid h-8 w-8 place-items-center rounded-lg text-[10px] font-bold ${page === number ? "bg-[#346538] text-white" : "bg-[#f3f5f3] text-[#717972]"}`} key={number} onClick={() => setPage(number)} type="button">{number}</button>
            ))}
          </div>
        )}
      </section>

      {modal && (
        <div className="absolute inset-x-0 bottom-[82px] top-[68px] z-50 grid place-items-center overflow-y-auto bg-[#1f2d21]/45 p-5 backdrop-blur-[2px]">
          <div className="my-auto w-full rounded-[20px] bg-white p-5 shadow-2xl">
            {modal === "register" && (
              <>
                <div className="flex items-center justify-between"><h3 className="text-[17px] font-extrabold">회원 등록</h3><button aria-label="닫기" onClick={() => { setRegisterTypePickerOpen(false); setModal(null) }} type="button"><Icon name="x" size={18} /></button></div>
                <div className="mt-4 space-y-3">
                  {[
                    ["name", "이름", "text"], ["phone", "연락처", "tel"], ["joined", "가입일", "text"],
                  ].map(([key, label, type]) => (
                    <label className="block" key={key}><span className="mb-1 block text-[9px] font-bold text-[#6b736d]">{label}</span><input className="h-10 w-full rounded-lg border border-[#dfe4df] px-3 text-[11px] outline-none focus:border-[#346538]" onChange={(event) => setRegisterForm((current) => ({ ...current, [key]: event.target.value }))} placeholder={key === "joined" ? "YYYY.MM.DD" : ""} type={type} value={registerForm[key as keyof typeof registerForm]} /></label>
                  ))}
                  <div className="block">
                    <span className="mb-1 block text-[9px] font-bold text-[#6b736d]">분류</span>
                    <button aria-expanded={registerTypePickerOpen} className="flex h-10 w-full items-center justify-between rounded-lg border border-[#dfe4df] bg-white px-3 text-left text-[11px] font-semibold outline-none focus:border-[#346538]" onClick={() => setRegisterTypePickerOpen((open) => !open)} type="button">
                      {registerForm.type}
                      <Icon className={`text-[#737b75] ${registerTypePickerOpen ? "rotate-180" : ""}`} name="chevron" size={14} />
                    </button>
                    {registerTypePickerOpen && (
                      <div className="mt-1.5 overflow-hidden rounded-lg border border-[#dfe4df] bg-white shadow-[0_8px_20px_rgba(36,58,39,.12)]">
                        {(["고객", "관리자"] as const).map((type) => (
                          <button className={`flex h-10 w-full items-center border-b border-[#edf0ed] px-3 text-left text-[11px] font-semibold last:border-none ${registerForm.type === type ? "bg-[#edf3ed] text-[#346538]" : "text-[#59625b]"}`} key={type} onClick={() => { setRegisterForm((current) => ({ ...current, type })); setRegisterTypePickerOpen(false) }} type="button">{type}</button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
                <div className="mt-5 grid grid-cols-2 gap-2"><button className="h-11 rounded-xl border border-[#d9ded9] text-[11px] font-bold" onClick={() => { setRegisterTypePickerOpen(false); setModal(null) }} type="button">취소</button><button className="h-11 rounded-xl bg-[#346538] text-[11px] font-bold text-white disabled:opacity-40" disabled={!registerForm.name.trim() || !registerForm.phone.trim() || !registerForm.joined.trim()} onClick={() => { setMembers((current) => [...current, { ...registerForm, id: Date.now(), userId: `member${Date.now()}`, isNew: registerForm.type === "고객", address: "" }]); onFire?.("회원 관리 · 신규 회원이 가입되었을 시"); setRegisterTypePickerOpen(false); setModal(null); setRegisterForm({ name: "", phone: "", joined: "", type: "고객" }) }} type="button">등록</button></div>
              </>
            )}
            {modal === "detail" && selected && (
              <>
                <div className="flex items-center justify-between"><h3 className="text-[17px] font-extrabold">회원 상세 정보</h3><button aria-label="닫기" onClick={() => setModal(null)} type="button"><Icon name="x" size={18} /></button></div>
                <div className="mt-5 text-center"><span className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-[#edf3ed] text-[18px] font-extrabold text-[#346538]">{selected.name[0]}</span><p className="mt-2 text-[15px] font-extrabold">{selected.name}</p></div>
                <div className="mt-5 divide-y divide-[#edf0ed] rounded-xl bg-[#f8f9f8] px-4">
                  {[
                    ["이름", selected.name], ["연락처", selected.phone], ["가입일", selected.joined || "-"], ["분류", selected.type],
                  ].map(([label, value]) => <div className="flex justify-between py-2.5 text-[10px]" key={label}><span className="font-bold text-[#737b75]">{label}</span><span className="text-[#444c46]">{value}</span></div>)}
                </div>
                <button className="mt-5 h-11 w-full rounded-xl bg-[#346538] text-[11px] font-bold text-white" onClick={() => setModal(null)} type="button">닫기</button>
              </>
            )}
            {modal === "edit" && selected && (
              <>
                <div className="flex items-center justify-between"><h3 className="text-[17px] font-extrabold">회원 권한 변경</h3><button aria-label="닫기" onClick={() => setModal(null)} type="button"><Icon name="x" size={18} /></button></div>
                <div className="mt-4 rounded-xl bg-[#f5f7f5] p-4 text-[11px]"><strong>{selected.name}</strong><p className="mt-1 text-[#7b837d]">{selected.phone}</p></div>
                <p className="mt-5 text-[10px] font-bold">분류 (권한)</p>
                <div className="mt-3 flex gap-5">{["고객", "관리자"].map((type) => <label className="flex items-center gap-2 text-[11px] font-semibold" key={type}><input checked={selected.type === type} name="memberType" onChange={() => setSelected({ ...selected, type: type as Member["type"] })} type="radio" />{type}</label>)}</div>
                <div className="mt-6 grid grid-cols-2 gap-2"><button className="h-11 rounded-xl border border-[#d9ded9] text-[11px] font-bold" onClick={() => setModal(null)} type="button">취소</button><button className="h-11 rounded-xl bg-[#346538] text-[11px] font-bold text-white" onClick={() => { setMembers((current) => current.map((member) => member.id === selected.id ? selected : member)); setModal(null) }} type="button">저장</button></div>
              </>
            )}
            {modal === "delete" && selected && (
              <>
                <h3 className="text-center text-[17px] font-extrabold">정말 삭제하시겠습니까?</h3><p className="mt-2 text-center text-[10px] text-[#8b928d]">삭제된 데이터는 복구할 수 없습니다.</p>
                <div className="mt-6 grid grid-cols-2 gap-2"><button className="h-11 rounded-xl border border-[#d9ded9] text-[11px] font-bold" onClick={() => setModal(null)} type="button">취소</button><button className="h-11 rounded-xl bg-[#c75f56] text-[11px] font-bold text-white" onClick={() => { setMembers((current) => current.filter((member) => member.id !== selected.id)); setModal(null) }} type="button">삭제</button></div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

function ReviewManagement({ onFire }: { onFire?: (conditionKey: string) => void }) {
  const [ratingFilter, setRatingFilter] = useState("전체")
  const [editingReply, setEditingReply] = useState<number | null>(null)
  const [replyingTo, setReplyingTo] = useState<number | null>(2)
  const [replyDraft, setReplyDraft] = useState("")
  const [savedReply, setSavedReply] = useState(
    "소중한 후기 감사합니다. 앞으로도 안전하고 꼼꼼한 이사 서비스로 보답하겠습니다.",
  )
  const reviews = [
    {
      id: 1,
      name: "김명품",
      userId: "luxury24",
      date: "2026-06-02",
      type: "가정이사",
      usageCount: 3,
      rating: 5,
      text: "포장부터 정리까지 정말 꼼꼼하게 해주셨어요. 직원분들도 친절해서 안심하고 이사했습니다.",
      photo:
        "https://images.unsplash.com/photo-1730154838368-c37b1fdebcf6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixlib=rb-4.1.0&q=80&w=500",
      answered: true,
    },
    {
      id: 2,
      name: "이서준",
      userId: "seojun82",
      date: "2026-05-29",
      type: "기업이사",
      usageCount: 2,
      rating: 5,
      text: "사무실 집기 이동이 많았는데 예정 시간 안에 잘 마무리해 주셨습니다.",
      answered: false,
    },
    {
      id: 3,
      name: "박하윤",
      userId: "hayoon7",
      date: "2026-05-21",
      type: "보관이사",
      usageCount: 4,
      rating: 5,
      text: "보관 상태도 좋았고 다시 배송받을 때 파손된 물건 없이 잘 도착했어요.",
      answered: false,
    },
    {
      id: 4,
      name: "최유진",
      userId: "yujin05",
      date: "2026-05-18",
      type: "가정이사",
      usageCount: 1,
      rating: 4,
      text: "전체적으로 괜찮았지만 도착 시간이 조금 늦어 아쉬웠습니다.",
      answered: true,
    },
    {
      id: 5,
      name: "정도현",
      userId: "dohyun33",
      date: "2026-05-14",
      type: "원룸이사",
      usageCount: 2,
      rating: 5,
      text: "짐이 많지 않았는데도 세심하게 포장해 주셔서 만족했습니다.",
      answered: false,
    },
    {
      id: 6,
      name: "한지민",
      userId: "jimin22",
      date: "2026-05-10",
      type: "가정이사",
      usageCount: 5,
      rating: 5,
      text: "상담부터 이사 완료까지 안내가 정확하고 친절했어요.",
      answered: true,
    },
    {
      id: 7,
      name: "윤서아",
      userId: "seoa17",
      date: "2026-05-07",
      type: "보관이사",
      usageCount: 1,
      rating: 4,
      text: "보관 일정 변경 과정에서 안내가 조금 늦었습니다.",
      answered: false,
    },
    {
      id: 8,
      name: "강민준",
      userId: "minjun8",
      date: "2026-05-03",
      type: "기업이사",
      usageCount: 3,
      rating: 5,
      text: "업무 공백 없이 빠르게 이전을 마칠 수 있어 좋았습니다.",
      answered: true,
    },
    {
      id: 9,
      name: "송하윤",
      userId: "hayoon91",
      date: "2026-04-29",
      type: "원룸이사",
      usageCount: 2,
      rating: 4,
      text: "합리적인 가격에 서비스도 깔끔해서 다시 이용하고 싶어요.",
      answered: false,
    },
    {
      id: 10,
      name: "임지호",
      userId: "jiho77",
      date: "2026-04-24",
      type: "가정이사",
      usageCount: 4,
      rating: 3,
      text: "일부 가구에 흠집이 생겨서 사후 처리를 요청했습니다.",
      answered: false,
    },
    {
      id: 11,
      name: "오지안",
      userId: "jian02",
      date: "2026-04-20",
      type: "사무실이사",
      usageCount: 2,
      rating: 5,
      text: "복잡한 장비도 안전하게 옮겨 주셔서 정말 감사합니다.",
      answered: true,
    },
    {
      id: 12,
      name: "문예준",
      userId: "yejun11",
      date: "2026-04-16",
      type: "가정이사",
      usageCount: 1,
      rating: 4,
      text: "포장은 꼼꼼했지만 정리 시간이 예상보다 오래 걸렸습니다.",
      answered: false,
    },
  ]
  const visibleReviews =
    ratingFilter === "전체"
      ? reviews
      : reviews.filter((review) => review.rating === Number(ratingFilter))
  const average = (
    reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length
  ).toFixed(1)
  const distribution = [5, 4, 3, 2, 1].map((rating) => {
    const count = reviews.filter((review) => review.rating === rating).length
    return {
      rating,
      count,
      percentage: Math.round((count / reviews.length) * 100),
    }
  })

  return (
    <div className="space-y-5 px-4 pb-28 pt-6">
      <h2 className="px-1 text-[24px] font-extrabold tracking-[-0.04em] text-[#346538]">
        리뷰 관리
      </h2>

      <section className="flex items-center gap-5 rounded-[20px] bg-white p-5 shadow-[0_5px_18px_rgba(36,58,39,.06)]">
        <div className="w-[100px] shrink-0 border-r border-[#edf0ed] pr-5 text-center">
          <strong className="text-[38px] font-extrabold tracking-[-0.05em] text-[#29312b]">
            {average}
          </strong>
          <div className="mt-2 flex justify-center">
            <StarRating rating={Math.round(Number(average))} size={13} />
          </div>
          <p className="mt-2 text-[9px] text-[#969d98]">평균 별점</p>
        </div>
        <div className="flex-1 space-y-2">
          {distribution.map((item) => (
            <div className="flex items-center gap-2" key={item.rating}>
              <span className="w-5 text-[9px] font-bold text-[#777f79]">
                {item.rating}점
              </span>
              <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-[#eef0ee]">
                <div
                  className="h-full rounded-full bg-[#f2b84b]"
                  style={{ width: `${item.percentage}%` }}
                />
              </div>
              <span className="w-3 text-right text-[9px] font-semibold text-[#8c938e]">
                {item.count}
              </span>
            </div>
          ))}
        </div>
      </section>

      <div className="flex items-center justify-between px-1">
        <p className="text-[14px] font-extrabold text-[#303832]">
          전체 리뷰 <span className="text-[#346538]">{reviews.length}개</span>
        </p>
        <label className="relative">
          <span className="sr-only">별점 분류</span>
          <select
            className="h-9 appearance-none rounded-lg border border-[#dfe4df] bg-white pl-3 pr-8 text-[11px] font-semibold text-[#535b55] outline-none focus:border-[#346538]"
            onChange={(event) => setRatingFilter(event.target.value)}
            value={ratingFilter}
          >
            <option>전체</option>
            {[5, 4, 3, 2, 1].map((rating) => (
              <option key={rating} value={rating}>
                {rating}점
              </option>
            ))}
          </select>
          <Icon
            className="pointer-events-none absolute right-2 top-2.5 text-[#778079]"
            name="chevron"
            size={14}
          />
        </label>
      </div>

      <div className="space-y-4">
        {visibleReviews.map((review) => (
          <article
            className="rounded-[20px] bg-white p-5 shadow-[0_5px_18px_rgba(36,58,39,.06)]"
            key={review.id}
          >
            <div className="flex items-start gap-3">
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-[#edf3ed] text-[13px] font-extrabold text-[#346538]">
                {review.name[0]}
              </span>
              <div className="min-w-0 flex-1">
                <p className="truncate text-[12px] font-bold text-[#303832]">
                  {review.name}
                </p>
                <p className="mt-1 text-[9px] text-[#9ca29d]">{review.date}</p>
              </div>
              <span className="flex shrink-0 items-center gap-2 text-[9px] font-semibold text-[#8b928d]">
                <b className="rounded-full bg-[#edf3ed] px-2 py-1 text-[#346538]">{review.type}</b>
                <span>이용 {review.usageCount}회차</span>
              </span>
            </div>

            <div className="mt-4">
              <StarRating rating={review.rating} />
              <p className="mt-3 text-[12px] leading-5 text-[#505852]">{review.text}</p>
            </div>

            {review.photo && (
              <div className="mt-3 overflow-x-auto">
                <img
                  alt="고객이 첨부한 이삿짐 박스 사진"
                  className="h-20 w-28 rounded-xl object-cover"
                  src={review.photo}
                />
              </div>
            )}

            {review.answered ? (
              <div className="mt-4 rounded-[14px] bg-[#f7f8f7] p-4">
                <div className="flex items-center justify-between">
                  <p className="text-[11px] font-extrabold text-[#465048]">
                    관리자 답변
                  </p>
                  <button
                    aria-label={editingReply === review.id ? "답변 수정 완료" : "답변 수정"}
                    className={`grid h-8 w-8 place-items-center rounded-lg ${
                      editingReply === review.id
                        ? "bg-[#346538] text-white"
                        : "text-[#65806a] hover:bg-[#e9eeea]"
                    }`}
                    onClick={() =>
                      setEditingReply((current) =>
                        current === review.id ? null : review.id,
                      )
                    }
                    type="button"
                  >
                    <Icon name={editingReply === review.id ? "check" : "edit"} size={16} />
                  </button>
                </div>
                {editingReply === review.id ? (
                  <textarea
                    className="mt-2 min-h-20 w-full resize-none rounded-lg border border-[#dbe1dc] bg-white p-3 text-[11px] leading-5 text-[#505852] outline-none focus:border-[#346538]"
                    onChange={(event) => setSavedReply(event.target.value)}
                    value={savedReply}
                  />
                ) : (
                  <p className="mt-2 text-[11px] leading-5 text-[#69716b]">{savedReply}</p>
                )}
              </div>
            ) : replyingTo === review.id ? (
              <div className="mt-4 rounded-[14px] bg-[#f7f8f7] p-3">
                <textarea
                  autoFocus
                  className="min-h-20 w-full resize-none rounded-lg border border-[#dbe1dc] bg-white p-3 text-[11px] leading-5 text-[#505852] outline-none placeholder:text-[#a8aea9] focus:border-[#346538]"
                  onChange={(event) => setReplyDraft(event.target.value)}
                  placeholder="답변 내용을 입력하세요..."
                  value={replyDraft}
                />
                <div className="mt-2 flex justify-end gap-2">
                  <button
                    className="rounded-lg border border-[#d9ded9] bg-white px-3 py-2 text-[10px] font-bold text-[#737b75]"
                    onClick={() => {
                      setReplyingTo(null)
                      setReplyDraft("")
                    }}
                    type="button"
                  >
                    취소
                  </button>
                  <button
                    className="rounded-lg bg-[#346538] px-3 py-2 text-[10px] font-bold text-white"
                    onClick={() => { setReplyingTo(null); onFire?.("리뷰 관리 · 관리자가 답변 할 시") }}
                    type="button"
                  >
                    답변 등록
                  </button>
                </div>
              </div>
            ) : (
              <button
                className="mt-4 flex items-center gap-1.5 text-[11px] font-bold text-[#346538]"
                onClick={() => setReplyingTo(review.id)}
                type="button"
              >
                <Icon name="chat" size={15} />
                답변 달기
              </button>
            )}
          </article>
        ))}
      </div>
    </div>
  )
}

function getEstimateDocument(record: EstimateRecord): EstimateDocumentData {
  const defaults: EstimateDocumentData = {
    companyName: record.companyName || "명품익스프레스",
    customer: record.name,
    phone: record.phone || "010-1234-5678",
    estimateDate: record.date,
    moveDate: record.date,
    transportDate: record.date,
    moveType: "포장이사",
    origin: "서울 강남구 테헤란로 123",
    destination: "경기 성남시 분당구 판교로 45",
    volume: "3.5톤",
    note: "파손 주의 물품은 별도 포장하며, 현장 상황에 따라 추가 비용이 발생할 수 있습니다.",
    movingCost: "1,050,000",
    extraCost: "270,000",
    total: "1,320,000",
    deposit: "132,000",
    balance: "1,188,000",
    itemGroups: ["전자기기", "가구", "", ""],
    optionCosts: ["", "", "", "", "", "", "", ""],
    optionSelections: ["", "", "", "", "", "", "", ""],
    workMethod: "포장",
    transportMethod: { ladder: "전", elevator: "후", stairs: "" },
    departureLadder: "150,000",
    destinationLadder: "120,000",
    ladderSubtotal: "270,000",
    itemRowCount: 8,
    items: [
      { id: 1, name: "냉장고", quantity: "1대" },
      { id: 2, name: "세탁기", quantity: "1대" },
      { id: 3, name: "침대", quantity: "1개" },
      { id: 4, name: "책상", quantity: "2개" },
      { id: 5, name: "의자", quantity: "4개" },
      { id: 6, name: "박스", quantity: "25개" },
    ],
  }
  return record.documentData
    ? {
        ...defaults,
        ...record.documentData,
        itemGroups: record.documentData.itemGroups || defaults.itemGroups,
        optionCosts: record.documentData.optionCosts || defaults.optionCosts,
        optionSelections: record.documentData.optionSelections || defaults.optionSelections,
        transportMethod: record.documentData.transportMethod || defaults.transportMethod,
        itemRowCount: record.documentData.itemRowCount || defaults.itemRowCount,
      }
    : defaults
}

function EstimateTemplateSheet({
  data,
  editable,
  onChange,
}: {
  data: EstimateDocumentData
  editable: boolean
  onChange?: (data: EstimateDocumentData) => void
}) {
  const update = (key: keyof Omit<EstimateDocumentData, "items" | "itemGroups" | "optionCosts" | "optionSelections" | "transportMethod" | "itemRowCount">, value: string) =>
    onChange?.({ ...data, [key]: value })
  const updateGroup = (index: number, value: string) => {
    const itemGroups = [...data.itemGroups] as EstimateDocumentData["itemGroups"]
    itemGroups[index] = value
    onChange?.({ ...data, itemGroups })
  }
  const updateItemAt = (index: number, key: "name" | "quantity", value: string) => {
    const items = [...data.items]
    while (items.length <= index) items.push({ id: Date.now() + items.length, name: "", quantity: "" })
    items[index] = { ...items[index], [key]: value }
    onChange?.({ ...data, items })
  }
  const updateOptionCost = (index: number, value: string) => {
    const optionCosts = [...data.optionCosts]
    optionCosts[index] = value
    onChange?.({ ...data, optionCosts })
  }
  const updateOptionSelection = (index: number, value: string) => {
    const optionSelections = [...data.optionSelections]
    optionSelections[index] = optionSelections[index] === value ? "" : value
    onChange?.({ ...data, optionSelections })
  }
  const changeItemRowCount = (offset: number) => {
    const itemRowCount = Math.min(14, Math.max(1, data.itemRowCount + offset))
    const items = offset < 0
      ? data.items.slice(0, itemRowCount * 4)
      : data.items
    onChange?.({ ...data, itemRowCount, items })
  }
  const updateTransport = (
    method: keyof EstimateDocumentData["transportMethod"],
    value: "전" | "후",
  ) => onChange?.({
    ...data,
    transportMethod: {
      ...data.transportMethod,
      [method]: data.transportMethod[method] === value ? "" : value,
    },
  })
  const valueClass = editable
    ? "h-full min-w-0 w-full overflow-hidden whitespace-nowrap bg-white px-[.55cqw] text-[1.25cqw] font-semibold outline-none focus:bg-white"
    : "flex h-full min-w-0 flex-1 items-center overflow-hidden whitespace-nowrap bg-white px-[.55cqw] text-[1.25cqw] font-semibold"
  const dataField = (
    key: "companyName" | "customer" | "phone" | "estimateDate" | "moveDate" | "transportDate" | "origin" | "destination",
    className = "",
  ) => editable
    ? <input className={`${valueClass} ${className}`} onChange={(event) => update(key, event.target.value)} value={data[key]} />
    : <span className={`${valueClass} ${className}`}>{data[key]}</span>
  const simpleField = (key: "volume" | "note") => editable
    ? <input className={valueClass} onChange={(event) => update(key, event.target.value)} value={data[key]} />
    : <span className={valueClass}>{data[key]}</span>
  const moneyField = (key: "movingCost" | "extraCost" | "total" | "deposit" | "balance" | "departureLadder" | "destinationLadder" | "ladderSubtotal") => editable
    ? <input className={`${valueClass} text-right`} onChange={(event) => update(key, event.target.value)} value={data[key]} />
    : <span className={`${valueClass} justify-end`}>₩ {data[key]}</span>
  const optionRows: Array<[string, [string, string]]> = [
    ["피아노", ["일반", "그랜드"]], ["돌침대", ["분해", "조립"]],
    ["조립장", ["분해", "조립"]], ["벽걸이TV", ["탈착", "설치"]],
    ["홈씨어터", ["분리", "설치"]], ["수작업", ["계단", "승강기"]],
    ["안마의자", ["분리", "설치"]], ["에어컨", ["탈착", "설치"]],
  ]

  return (
    <article className="estimate-document-sheet aspect-[1488/2103] w-full overflow-hidden bg-white p-[4cqw] text-black">
      <header className="grid grid-cols-[1.25fr_.9fr_1.7fr] gap-[2cqw]">
        <div>
          <h4 className="text-[3.7cqw] font-black tracking-[-.08em]">명품 익스프레스</h4>
          <p className="mt-[.8cqw] text-[1.05cqw] leading-[1.7]">포장이사 전문업체 관허 2015-7호<br />(피해보상)보증보험 가입</p>
        </div>
        <div className="text-center">
          <h5 className="text-[3cqw] font-black">견적서 / 계약서</h5>
          <p className="mt-[.6cqw] text-[1.3cqw] font-bold">(ESTIMATE REPORT)</p>
        </div>
        <div className="border-l border-t border-black text-[1.2cqw]">
          {[["등록 번호", "398-51-00044"], ["사무실전화", "062) 252-0303"], ["대표자전화", "010-9445-8224"]].map(([label, value]) => <div className="grid min-h-[3cqw] grid-cols-[13cqw_1fr] border-b border-r border-black" key={label}><b className="grid place-items-center border-r border-black">{label}</b><span className="flex items-center px-[1cqw] font-bold">{value}</span></div>)}
        </div>
      </header>

      <section className="mt-[3cqw] border-l border-t border-black bg-white">
        <div className="grid grid-cols-[15cqw_22cqw_7cqw_23cqw_1fr] grid-rows-[2.6cqw_2.6cqw]">
          <b className="row-span-2 grid place-items-center border-b border-r border-black text-[1.35cqw] tracking-[.25em]">업체명</b>
          <label className="row-span-2 border-b border-r border-black">{dataField("companyName", "justify-center text-center font-black")}</label>
          <b className="row-span-2 grid place-items-center border-b border-r border-black text-[1.2cqw]">담당자</b>
          <label className="relative flex min-w-0 overflow-hidden border-b border-r border-black">{dataField("customer", "justify-center pr-[3.5cqw] text-right")}<span className="pointer-events-none absolute right-[1cqw] top-[.65cqw] text-[1.1cqw] font-bold">(님)</span></label>
          <label className="row-span-2 flex min-w-0 items-center gap-[1cqw] overflow-hidden border-b border-r border-black px-[1cqw] text-[1.2cqw] font-black"><span className="shrink-0">견적일:</span>{dataField("estimateDate")}</label>
          <label className="relative flex min-w-0 overflow-hidden border-b border-r border-black pl-[5cqw]"><b className="pointer-events-none absolute left-[1cqw] top-[.6cqw] text-[1.1cqw]">TEL :</b>{dataField("phone")}</label>
        </div>
        <div className="grid min-h-[4.6cqw] grid-cols-[15cqw_1fr_27cqw]">
          <b className="grid place-items-center border-b border-r border-black text-[1.35cqw] tracking-[.25em]">출발지</b>
          <label className="border-b border-r border-black">{dataField("origin")}</label>
          <label className="flex min-w-0 items-center gap-[1cqw] overflow-hidden border-b border-r border-black px-[1cqw] text-[1.2cqw] font-black"><span className="shrink-0">작업일:</span>{dataField("moveDate")}</label>
        </div>
        <div className="grid min-h-[4.6cqw] grid-cols-[15cqw_1fr_27cqw]">
          <b className="grid place-items-center border-b border-r border-black text-[1.35cqw] tracking-[.25em]">도착지</b>
          <label className="border-b border-r border-black">{dataField("destination")}</label>
          <label className="flex min-w-0 items-center gap-[1cqw] overflow-hidden border-b border-r border-black px-[1cqw] text-[1.2cqw] font-black"><span className="shrink-0">운송일:</span>{dataField("transportDate")}</label>
        </div>
      </section>

      <section className="mt-[1.2cqw] bg-white border-l border-t border-black">
        <div className="grid grid-cols-4 bg-[#eeeeee]">
          {data.itemGroups.map((group, index) => <label className="h-[3.8cqw] border-b border-r border-black" key={index}>{editable ? <input aria-label={`${index + 1}번째 품목 그룹`} className={`${valueClass} bg-transparent text-center font-black`} onChange={(event) => updateGroup(index, event.target.value)} placeholder={index < 2 ? undefined : "관리자 입력"} value={group} /> : <span className={`${valueClass} justify-center bg-[#eeeeee] font-black`}>{group}</span>}</label>)}
        </div>
        <div className="grid grid-cols-8 bg-[#f5f5f5]">
          {Array.from({ length: 4 }, (_, index) => <div className="contents" key={index}><b className="grid h-[3.4cqw] place-items-center border-b border-r border-black text-[1.2cqw]">품목</b><b className="grid h-[3.4cqw] place-items-center border-b border-r border-black text-[1.2cqw]">수량</b></div>)}
        </div>
        {Array.from({ length: data.itemRowCount }, (_, row) => (
          <div className="grid grid-cols-8 bg-white" key={row}>
            {Array.from({ length: 4 }, (_, column) => {
              const index = row * 4 + column
              const item = data.items[index]
              return <div className="contents" key={column}>{editable ? <input aria-label={`${row + 1}행 ${column + 1}번째 품목`} className={`${valueClass} h-[3.1cqw] border-b border-r border-black bg-white text-center`} onChange={(event) => updateItemAt(index, "name", event.target.value)} value={item?.name || ""} /> : <span className={`${valueClass} h-[3.1cqw] justify-center border-b border-r border-black bg-white`}>{item?.name || "\u00a0"}</span>}{editable ? <input aria-label={`${row + 1}행 ${column + 1}번째 수량`} className={`${valueClass} h-[3.1cqw] border-b border-r border-black bg-white text-center`} onChange={(event) => updateItemAt(index, "quantity", event.target.value)} value={item?.quantity || ""} /> : <span className={`${valueClass} h-[3.1cqw] justify-center border-b border-r border-black bg-white`}>{item?.quantity || "\u00a0"}</span>}</div>
            })}
          </div>
        ))}
      </section>
      {editable && (
        <div className="mt-[1cqw] flex items-center justify-center gap-[1.2cqw]">
          <button aria-label="품목 행 삭제" className="grid h-[4cqw] w-[4cqw] place-items-center rounded-full border border-[#aeb5af] bg-white text-[2.3cqw] font-black" disabled={data.itemRowCount <= 1} onClick={() => changeItemRowCount(-1)} type="button">−</button>
          <span className="text-[1.1cqw] font-bold text-[#737b75]">{data.itemRowCount}행</span>
          <button aria-label="품목 행 추가" className="grid h-[4cqw] w-[4cqw] place-items-center rounded-full border border-[#aeb5af] bg-white text-[2.3cqw] font-black" disabled={data.itemRowCount >= 14} onClick={() => changeItemRowCount(1)} type="button">+</button>
        </div>
      )}

      <section className="mt-[1.1cqw] grid grid-cols-[1fr_1.1fr] gap-[.8cqw]">
        <div className="grid grid-cols-[5.5cqw_1fr] border-l border-t border-black">
          <strong className="grid place-items-center border-b border-r border-black px-[1cqw] text-center text-[1.4cqw] leading-[1.8]">옵<br />션<br />비<br />용</strong>
          <div>{optionRows.map(([label, choices], index) => <div className="grid min-h-[2.75cqw] grid-cols-[10cqw_1fr_2.5cqw_10cqw] border-b border-r border-black text-[1.05cqw]" key={label}><b className="flex items-center px-[.8cqw]">· {label}</b><span className="flex items-center gap-[1.1cqw]">{choices.map((choice) => <button className={`flex items-center gap-[.35cqw] ${data.optionSelections[index] === choice ? "font-black text-black" : "text-[#69716b]"}`} disabled={!editable} key={choice} onClick={() => updateOptionSelection(index, choice)} type="button"><span className="text-[1.25cqw]">{data.optionSelections[index] === choice ? "■" : "□"}</span>{choice}</button>)}</span><span className="flex items-center justify-center">₩</span>{editable ? <input aria-label={`${label} 옵션 비용`} className="min-w-0 bg-white px-[.5cqw] text-right outline-none focus:bg-white" onChange={(event) => updateOptionCost(index, event.target.value)} value={data.optionCosts[index] || ""} /> : <span className="flex items-center justify-end bg-white px-[.5cqw]">{data.optionCosts[index]}</span>}</div>)}</div>
        </div>
        <div className="border-l border-t border-black">
          <div className="grid min-h-[5.5cqw] grid-cols-[10cqw_1fr] border-b border-r border-black">
            <b className="grid place-items-center text-[1.3cqw]">작업내용</b>
            <div className="flex items-center justify-center gap-[2.2cqw] px-[1cqw] text-[1.2cqw]">
              {["포장", "일반", "보관"].map((method) => (
                <button className={`flex items-center gap-[.6cqw] ${data.workMethod === method ? "font-black text-black" : "text-[#69716b]"}`} disabled={!editable} key={method} onClick={() => onChange?.({ ...data, workMethod: method })} type="button"><span className="text-[1.5cqw]">{data.workMethod === method ? "■" : "□"}</span>{method}</button>
              ))}
            </div>
          </div>
          <div className="grid min-h-[4.7cqw] grid-cols-[10cqw_1fr] border-b border-r border-black">
            <b className="grid place-items-center text-[1.3cqw]">운반방법</b>
            <div className="flex items-center justify-center gap-[1.6cqw] px-[.6cqw] text-[1.05cqw]">
              {([["ladder", "사다리차"], ["elevator", "승강기"], ["stairs", "계단작업"]] as const).map(([key, label]) => (
                <span className="flex items-center gap-[.4cqw]" key={key}><b>{label}</b>{(["전", "후"] as const).map((value) => <button className={data.transportMethod[key] === value ? "font-black text-black underline decoration-[.18cqw] underline-offset-[.3cqw]" : "text-[#8a918c]"} disabled={!editable} key={value} onClick={() => updateTransport(key, value)} type="button">{value}</button>)}</span>
              ))}
            </div>
          </div>
          <label className="grid min-h-[5.3cqw] grid-cols-[10cqw_1fr] border-b border-r border-black"><b className="grid place-items-center text-[1.3cqw]">이사물량</b>{simpleField("volume")}</label>
          <label className="grid min-h-[6.1cqw] grid-cols-[10cqw_1fr] border-b border-r border-black"><b className="grid place-items-center text-[1.3cqw]">비고</b>{simpleField("note")}</label>
        </div>
      </section>

      <section className="mt-[.7cqw] grid grid-cols-2 border-l border-t border-black">
        <div className="border-r border-black">
          <h5 className="grid h-[2.8cqw] place-items-center border-b border-black text-[1.35cqw] font-black">A. 작업 비용</h5>
          {[["이사비용", "movingCost"], ["사다리비용", "extraCost"], ["총 비용", "total"], ["계약금10%", "deposit"], ["잔금", "balance"]].map(([label, key]) => <label className={`grid grid-cols-[23cqw_1fr] border-b border-black ${key === "deposit" || key === "balance" ? "min-h-[5.4cqw]" : "min-h-[2.8cqw]"}`} key={key}><b className="grid place-items-center border-r border-black text-[1.25cqw]">{label}</b>{moneyField(key as "movingCost")}</label>)}
        </div>
        <div className="border-r border-black">
          <h5 className="grid h-[2.8cqw] place-items-center border-b border-black text-[1.35cqw] font-black">B. 별도 비용</h5>
          {[["출발지 사다리(　)층", "departureLadder"], ["도착지 사다리(　)층", "destinationLadder"], ["사다리 소계", "ladderSubtotal"]].map(([label, key]) => <label className="grid min-h-[2.8cqw] grid-cols-[25cqw_1fr] border-b border-black" key={key}><b className="grid place-items-center border-r border-black text-[1.15cqw]">{label}</b>{moneyField(key as "departureLadder")}</label>)}
        </div>
      </section>

      <footer className="mt-[.8cqw] grid grid-cols-[12cqw_1fr_9cqw_1fr] border-l border-t border-black text-[1.2cqw]">
        <b className="grid min-h-[5cqw] place-items-center border-b border-r border-black">견적 담당자</b><span className="flex items-center justify-between border-b border-r border-black px-[1.3cqw] font-black"><span>김선국</span><span>(서명)/H.P　010-9445-8224</span></span><b className="grid place-items-center border-b border-r border-black text-center">고객<br />확인</b><span className="flex items-end justify-end border-b border-r border-black p-[1cqw] font-black">(서명)</span>
      </footer>
    </article>
  )
}

function useDocumentViewport(
  zoom: number,
  setZoom: Dispatch<SetStateAction<number>>,
  clampZoom: (value: number) => number,
) {
  const [pan, setPan] = useState({ x: 0, y: 0 })
  const [dragging, setDragging] = useState(false)
  const panRef = useRef(pan)
  const zoomRef = useRef(zoom)
  const dragStart = useRef<{ x: number; y: number; panX: number; panY: number } | null>(null)
  const pinchStart = useRef<{
    distance: number
    zoom: number
    centerX: number
    centerY: number
    panX: number
    panY: number
  } | null>(null)

  useEffect(() => {
    zoomRef.current = zoom
    if (zoom <= 100) {
      panRef.current = { x: 0, y: 0 }
      setPan({ x: 0, y: 0 })
    }
  }, [zoom])
  useEffect(() => {
    panRef.current = pan
  }, [pan])

  const updatePan = (nextPan: { x: number; y: number }) => {
    panRef.current = nextPan
    setPan(nextPan)
  }
  const startTouch = (event: TouchEvent<HTMLDivElement>) => {
    if (event.touches.length === 2) {
      const [first, second] = [event.touches[0], event.touches[1]]
      pinchStart.current = {
        distance: Math.hypot(first.clientX - second.clientX, first.clientY - second.clientY),
        zoom: zoomRef.current,
        centerX: (first.clientX + second.clientX) / 2,
        centerY: (first.clientY + second.clientY) / 2,
        panX: panRef.current.x,
        panY: panRef.current.y,
      }
      dragStart.current = null
    } else if (event.touches.length === 1) {
      const touch = event.touches[0]
      dragStart.current = { x: touch.clientX, y: touch.clientY, panX: panRef.current.x, panY: panRef.current.y }
    }
    setDragging(true)
  }
  const moveTouch = (event: TouchEvent<HTMLDivElement>) => {
    if (event.touches.length === 2 && pinchStart.current) {
      const [first, second] = [event.touches[0], event.touches[1]]
      const distance = Math.hypot(first.clientX - second.clientX, first.clientY - second.clientY)
      const centerX = (first.clientX + second.clientX) / 2
      const centerY = (first.clientY + second.clientY) / 2
      const nextZoom = clampZoom(Math.round(pinchStart.current.zoom * distance / pinchStart.current.distance))
      zoomRef.current = nextZoom
      setZoom(nextZoom)
      if (nextZoom > 100) {
        updatePan({
          x: pinchStart.current.panX + centerX - pinchStart.current.centerX,
          y: pinchStart.current.panY + centerY - pinchStart.current.centerY,
        })
      }
    } else if (event.touches.length === 1 && dragStart.current && zoomRef.current > 100) {
      const touch = event.touches[0]
      updatePan({
        x: dragStart.current.panX + touch.clientX - dragStart.current.x,
        y: dragStart.current.panY + touch.clientY - dragStart.current.y,
      })
    }
  }
  const endTouch = (event: TouchEvent<HTMLDivElement>) => {
    pinchStart.current = null
    if (event.touches.length === 1) {
      const touch = event.touches[0]
      dragStart.current = { x: touch.clientX, y: touch.clientY, panX: panRef.current.x, panY: panRef.current.y }
    } else {
      dragStart.current = null
      setDragging(false)
    }
  }
  const startPointer = (event: PointerEvent<HTMLDivElement>) => {
    if (event.pointerType !== "mouse") return
    dragStart.current = { x: event.clientX, y: event.clientY, panX: panRef.current.x, panY: panRef.current.y }
    event.currentTarget.setPointerCapture(event.pointerId)
    setDragging(true)
  }
  const movePointer = (event: PointerEvent<HTMLDivElement>) => {
    if (event.pointerType !== "mouse" || !dragStart.current || zoomRef.current <= 100) return
    updatePan({
      x: dragStart.current.panX + event.clientX - dragStart.current.x,
      y: dragStart.current.panY + event.clientY - dragStart.current.y,
    })
  }
  const endPointer = (event: PointerEvent<HTMLDivElement>) => {
    if (event.pointerType !== "mouse") return
    dragStart.current = null
    if (event.currentTarget.hasPointerCapture(event.pointerId)) {
      event.currentTarget.releasePointerCapture(event.pointerId)
    }
    setDragging(false)
  }

  return {
    dragging,
    pan,
    viewportHandlers: {
      onPointerCancel: endPointer,
      onPointerDown: startPointer,
      onPointerMove: movePointer,
      onPointerUp: endPointer,
      onTouchCancel: endTouch,
      onTouchEnd: endTouch,
      onTouchMove: moveTouch,
      onTouchStart: startTouch,
    },
  }
}

function EstimateDocumentViewer({
  actionLabel,
  editable,
  onAction,
  onChange,
  record,
  showDownload = true,
}: {
  actionLabel?: string
  editable: boolean
  onAction?: () => void
  onChange?: (data: EstimateDocumentData) => void
  record: EstimateRecord
  showDownload?: boolean
}) {
  const data = getEstimateDocument(record)
  const [zoom, setZoom] = useState(100)
  const clampZoom = (value: number) => Math.min(180, Math.max(60, value))
  const { dragging, pan, viewportHandlers } = useDocumentViewport(zoom, setZoom, clampZoom)
  const download = () => {
    const anchor = document.createElement("a")
    anchor.href = record.documentUrl || estimateTemplateUrl
    anchor.download = `명품익스프레스_견적서_${record.id}.pdf`
    anchor.click()
  }
  return (
    <div className="overflow-hidden rounded-[18px] bg-[#dfe4df] shadow-[0_10px_30px_rgba(32,48,35,.15)]">
      <div className="grid grid-cols-[1fr_auto_1fr] items-center border-b border-[#dfe4df] bg-white px-3 py-2.5">
        {showDownload ? (
          <button className="flex h-8 w-fit items-center gap-1.5 rounded-lg bg-[#edf3ed] px-3 text-[10px] font-extrabold text-[#346538]" onClick={download} type="button">
            <Icon name="document" size={14} /> 다운
          </button>
        ) : <span />}
        <div className="flex items-center gap-1">
          <button aria-label="축소" className="grid h-8 w-8 place-items-center rounded-lg bg-[#f1f3f1] text-lg font-bold text-[#465048]" onClick={() => setZoom((value) => clampZoom(value - 10))} type="button">−</button>
          <button className="w-12 text-center text-[10px] font-extrabold text-[#59615b]" onClick={() => setZoom(100)} type="button">{zoom}%</button>
          <button aria-label="확대" className="grid h-8 w-8 place-items-center rounded-lg bg-[#f1f3f1] text-lg font-bold text-[#465048]" onClick={() => setZoom((value) => clampZoom(value + 10))} type="button">+</button>
        </div>
        {onAction && <button className={`h-8 justify-self-end rounded-lg px-3 text-[10px] font-extrabold ${editable ? "bg-[#346538] text-white" : "bg-[#edf3ed] text-[#346538]"}`} onClick={onAction} type="button">{actionLabel}</button>}
      </div>
      <div
        className={`relative grid h-[calc(100dvh-260px)] min-h-[430px] place-items-center overflow-hidden bg-[#bfc5c0] ${dragging ? "cursor-grabbing" : "cursor-grab"}`}
        style={{ touchAction: "none" }}
        {...viewportHandlers}
      >
        <div
          className="h-[calc(100%_-_24px)] max-w-[calc(100%_-_24px)] aspect-[1488/2103] bg-white shadow-lg [container-type:inline-size]"
          style={{ transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom / 100})` }}
        >
          <EstimateTemplateSheet data={data} editable={editable} onChange={onChange} />
        </div>
      </div>
    </div>
  )
}

function EstimateManagement({
  onRegister,
  records,
  onChangeRecords,
  onFire,
}: {
  onRegister: () => void
  records: EstimateRecord[]
  onChangeRecords: (records: EstimateRecord[]) => void
  onFire?: (conditionKey: string) => void
}) {
  const [statusFilter, setStatusFilter] = useState("전체")
  const [datePickerOpen, setDatePickerOpen] = useState(false)
  const [dateInput, setDateInput] = useState("")
  const [dateQuery, setDateQuery] = useState("")
  const [currentPage, setCurrentPage] = useState(1)
  const [editingRecord, setEditingRecord] = useState<EstimateRecord | null>(null)
  const [deletingRecord, setDeletingRecord] = useState<EstimateRecord | null>(null)
  const [editTab, setEditTab] = useState<"form" | "video">("form")
  const [documentEditing, setDocumentEditing] = useState(false)
  const [saveConfirmOpen, setSaveConfirmOpen] = useState(false)
  const [approvalConfirmOpen, setApprovalConfirmOpen] = useState(false)
  const counts = {
    "견적 검토": records.filter((record) => record.status === "견적 검토").length,
    "견적 승인": records.filter((record) => record.status === "견적 승인").length,
    "견적 확정": records.filter((record) => record.status === "견적 확정").length,
  }
  const total = records.length
  const progress = [
    { label: "견적 검토", color: "#d96c62" },
    { label: "견적 승인", color: "#d3904b" },
    { label: "견적 확정", color: "#4f8b55" },
  ].map((item) => {
    const count = counts[item.label as keyof typeof counts]
    const percentage = total === 0 ? 0 : Math.round((count / total) * 100)
    return {
      ...item,
      count: `${count}건 (${percentage}%)`,
      width: `${percentage}%`,
    }
  })
  const badgeTone = {
    red: "bg-[#fbefed] text-[#b9574f]",
    green: "bg-[#edf4ed] text-[#346538]",
    blue: "bg-[#edf3f8] text-[#4b759b]",
  }
  const filteredRecords = records
    .filter((record) => statusFilter === "전체" || record.status === statusFilter)
    .filter(
      (record) =>
        !dateQuery ||
        record.date
          .replace(/\D/g, "")
          .startsWith(dateQuery.replace(/\D/g, "")),
    )
    .sort((a, b) => b.date.localeCompare(a.date))
  const recordsPerPage = 4
  const pageCount = Math.max(1, Math.ceil(filteredRecords.length / recordsPerPage))
  const visibleRecords = filteredRecords.slice(
    (currentPage - 1) * recordsPerPage,
    currentPage * recordsPerPage,
  )

  return (
    <div className="space-y-5 px-4 pb-28 pt-6">
      <h2 className="px-1 text-[24px] font-extrabold tracking-[-0.04em] text-[#346538]">
        견적 관리
      </h2>

      <section className="rounded-[20px] bg-white shadow-[0_5px_18px_rgba(36,58,39,.06)]">
        <div className="flex items-center justify-between px-5 pb-4 pt-5">
          <h3 className="text-[16px] font-extrabold text-[#29312b]">견적 기록 목록</h3>
          <button className="rounded-lg bg-[#346538] px-3 py-2 text-[11px] font-bold text-white" onClick={onRegister} type="button">+ 등록</button>
        </div>

        <div className="relative mx-4 mb-4 flex items-center justify-between">
          <label className="relative">
            <span className="sr-only">분류 필터</span>
            <select
              className="h-9 appearance-none rounded-lg border border-[#dfe4df] bg-[#fafbfa] pl-3 pr-8 text-[11px] font-semibold text-[#505852] outline-none focus:border-[#346538]"
              onChange={(event) => {
                setStatusFilter(event.target.value)
                setCurrentPage(1)
              }}
              value={statusFilter}
            >
              {["전체", "견적 검토", "견적 승인", "견적 확정"].map((option) => (
                <option key={option}>{option}</option>
              ))}
            </select>
            <Icon
              className="pointer-events-none absolute right-2 top-2.5 text-[#778079]"
              name="chevron"
              size={14}
            />
          </label>
          <button
            aria-expanded={datePickerOpen}
            aria-label="날짜 검색"
            className={`grid h-9 w-9 place-items-center rounded-lg border transition ${
              datePickerOpen
                ? "border-[#346538] bg-[#edf3ed] text-[#346538]"
                : "border-[#dfe4df] bg-[#fafbfa] text-[#6f7871]"
            }`}
            onClick={() => setDatePickerOpen((open) => !open)}
            type="button"
          >
            <Icon name="calendar" size={17} />
          </button>
          {datePickerOpen && (
            <div className="absolute bottom-11 right-0 z-10 rounded-xl border border-[#e1e5e1] bg-white p-3 shadow-[0_10px_28px_rgba(36,58,39,.15)]">
              <label className="block text-[9px] font-bold text-[#828a84]">
                날짜 직접 입력
              </label>
              <div className="mt-1.5 flex items-center gap-2">
                <input
                  aria-label="검색 날짜 직접 입력"
                  className="h-9 w-28 rounded-lg border border-[#dfe4df] bg-[#f8f9f8] px-3 text-[11px] font-semibold text-[#434b45] outline-none placeholder:text-[#adb3ae] focus:border-[#346538]"
                  inputMode="numeric"
                  maxLength={8}
                  onChange={(event) => {
                    const digits = event.target.value.replace(/\D/g, "").slice(0, 6)
                    const isDeleting = (
                      event.nativeEvent as InputEvent
                    ).inputType?.startsWith("delete")
                    let formatted = digits

                    if (digits.length >= 5) {
                      formatted = `${digits.slice(0, 2)}.${digits.slice(2, 4)}.${digits.slice(4)}`
                    } else if (digits.length >= 3) {
                      formatted = `${digits.slice(0, 2)}.${digits.slice(2)}${
                        digits.length === 4 && !isDeleting ? "." : ""
                      }`
                    } else if (digits.length === 2 && !isDeleting) {
                      formatted = `${digits}.`
                    }

                    setDateInput(formatted)
                    setDateQuery(formatted)
                    setCurrentPage(1)
                  }}
                  placeholder="YY.MM.DD"
                  type="text"
                  value={dateInput}
                />
                <button
                  aria-label="입력한 날짜 조회"
                  className="grid h-9 w-9 place-items-center rounded-lg bg-[#346538] text-white transition hover:bg-[#2b582f]"
                  onClick={() => {
                    setDateQuery(dateInput)
                    setCurrentPage(1)
                  }}
                  type="button"
                >
                  <Icon name="search" size={16} />
                </button>
              </div>
            </div>
          )}
        </div>

        <div className="grid grid-cols-[25px_72px_1fr_58px_52px] items-center gap-1 bg-[#f7f8f7] px-3 py-2.5 text-center text-[9px] font-bold text-[#8a918c]">
          <span>번호</span>
          <span>분류</span>
          <span>이름</span>
          <span>날짜</span>
          <span>삭제</span>
        </div>
        <div className="px-3">
          {visibleRecords.map((record, index) => (
            <div
              className="grid cursor-pointer grid-cols-[25px_72px_1fr_58px_52px] items-center gap-1 border-b border-[#edf0ed] py-3.5 text-[11px] transition last:border-none hover:bg-[#f7f9f7]"
              key={record.id}
              onClick={() => {
                setEditTab("form")
                setDocumentEditing(false)
                setEditingRecord(record)
              }}
            >
              <span className="text-center text-[10px] font-semibold text-[#8a918c]">
                {(currentPage - 1) * recordsPerPage + index + 1}
              </span>
              <span
                className={`justify-self-center rounded-full px-2 py-1 text-[9px] font-bold ${badgeTone[record.tone as keyof typeof badgeTone]}`}
              >
                {record.status}
              </span>
              <span className="truncate px-1 font-semibold text-[#464e48]">
                {record.name}
              </span>
              <span className="text-center text-[10px] font-medium text-[#7f8781]">
                {record.date}
              </span>
              <div className="flex items-center justify-center">
                <button
                  aria-label={`${record.name} 삭제`}
                  className="grid h-7 w-7 place-items-center rounded-lg text-[#c7635a] hover:bg-[#fbefed]"
                  onClick={(event) => {
                    event.stopPropagation()
                    setDeletingRecord(record)
                  }}
                  type="button"
                >
                  <Icon name="trash" size={15} />
                </button>
              </div>
            </div>
          ))}
          {visibleRecords.length === 0 && (
            <p className="py-8 text-center text-[11px] text-[#929994]">
              검색 조건에 맞는 견적 기록이 없습니다.
            </p>
          )}
        </div>
        {filteredRecords.length > recordsPerPage && (
          <div className="flex items-center justify-center gap-1 border-t border-[#edf0ed] px-4 py-4">
            {Array.from({ length: pageCount }, (_, index) => index + 1).map((page) => (
              <button
                aria-label={`${page}페이지로 이동`}
                className={`grid h-8 w-8 place-items-center rounded-lg text-[11px] font-bold transition ${
                  currentPage === page
                    ? "bg-[#346538] text-white"
                    : "bg-[#f3f5f3] text-[#707871] hover:bg-[#e7ece7]"
                }`}
                key={page}
                onClick={() => setCurrentPage(page)}
                type="button"
              >
                {page}
              </button>
            ))}
          </div>
        )}
      </section>
      <section className="rounded-[20px] bg-white p-5 shadow-[0_5px_18px_rgba(36,58,39,.06)]">
        <h3 className="text-[16px] font-extrabold text-[#29312b]">분류별 현황</h3>
        <div className="mt-5 space-y-5">
          {progress.map((item) => (
            <div key={item.label}>
              <div className="mb-2 flex items-center justify-between text-[11px]">
                <span className="font-semibold text-[#5e665f]">{item.label}</span>
                <span className="font-bold text-[#414943]">{item.count}</span>
              </div>
              <div className="h-2 overflow-hidden rounded-full bg-[#edf0ed]">
                <div className="h-full rounded-full" style={{ backgroundColor: item.color, width: item.width }} />
              </div>
            </div>
          ))}
        </div>
      </section>
      {editingRecord && (
        <div className="absolute inset-x-0 bottom-[82px] top-[68px] z-40 overflow-y-auto bg-[#f5f6f8] p-4">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <p className="text-[9px] font-extrabold tracking-[0.12em] text-[#7a927d]">ESTIMATE DOCUMENT</p>
              <div className="mt-1 flex items-center gap-2">
                <h3 className="text-[19px] font-extrabold text-[#346538]">견적 수정</h3>
                <span className={`rounded-full px-2.5 py-1 text-[10px] font-extrabold ${editingRecord.approvedDate ? "bg-[#edf3ed] text-[#346538]" : "bg-[#fff4e8] text-[#9b7127]"}`}>
                  {editingRecord.approvedDate ? `승인일 ${editingRecord.approvedDate}` : "승인 전"}
                </span>
              </div>
            </div>
            <button aria-label="수정 닫기" className="grid h-9 w-9 place-items-center rounded-full bg-white text-[#59615b]" onClick={() => setEditingRecord(null)} type="button"><Icon name="x" size={17} /></button>
          </div>
          <div className="mb-4 grid grid-cols-2 rounded-xl bg-white p-1 shadow-[0_4px_14px_rgba(36,58,39,.07)]">
            <button aria-pressed={editTab === "form"} className={`flex h-10 items-center justify-center gap-2 rounded-lg text-[11px] font-extrabold ${editTab === "form" ? "bg-[#346538] text-white" : "text-[#747c76]"}`} onClick={() => setEditTab("form")} type="button"><Icon name="document" size={15} />견적서</button>
            <button aria-pressed={editTab === "video"} className={`flex h-10 items-center justify-center gap-2 rounded-lg text-[11px] font-extrabold ${editTab === "video" ? "bg-[#346538] text-white" : "text-[#747c76]"}`} onClick={() => setEditTab("video")} type="button"><Icon name="camera" size={15} />고객 영상</button>
          </div>
          {editTab === "video" ? (
            <CustomerVideoPanel onEdit={() => setEditTab("form")} record={editingRecord} />
          ) : (
            <>
              <EstimateDocumentViewer
                actionLabel={documentEditing ? "저장" : "수정"}
                editable={documentEditing}
                onAction={() => documentEditing ? setSaveConfirmOpen(true) : setDocumentEditing(true)}
                onChange={(documentData) => setEditingRecord((current) => current ? { ...current, name: documentData.customer, phone: documentData.phone, date: documentData.estimateDate, documentData } : current)}
                record={editingRecord}
              />
              {editingRecord.status !== "견적 확정" && !documentEditing && (
                <button
                  className="mt-4 h-12 w-full rounded-xl bg-[#346538] text-[12px] font-extrabold text-white shadow-[0_6px_18px_rgba(52,101,56,.2)]"
                  onClick={() => setApprovalConfirmOpen(true)}
                  type="button"
                >
                  견적 승인
                </button>
              )}
            </>
          )}
        </div>
      )}

      {saveConfirmOpen && editingRecord && (
        <div className="absolute inset-x-0 bottom-[82px] top-[68px] z-50 grid place-items-center bg-[#1f2d21]/45 p-6 backdrop-blur-[2px]">
          <div className="relative w-full rounded-[20px] bg-white p-6 text-center shadow-2xl">
            <button aria-label="확인 창 닫기" className="absolute right-5 top-5 grid h-7 w-7 place-items-center text-[#59625b]" onClick={() => setSaveConfirmOpen(false)} type="button"><Icon name="x" size={18} /></button>
            <h3 className="text-[17px] font-extrabold">정말 수정 하시겠습니까?</h3>
            <p className="mt-2 text-[10px] text-[#8b928d]">저장된 견적서는 상세 보기에도 바로 반영됩니다.</p>
            <div className="mt-6 grid grid-cols-2 gap-2">
              <button className="h-11 rounded-xl border border-[#d9ded9] text-[11px] font-bold" onClick={() => setSaveConfirmOpen(false)} type="button">취소</button>
              <button className="h-11 rounded-xl bg-[#346538] text-[11px] font-bold text-white" onClick={() => { onChangeRecords(records.map((record) => record.id === editingRecord.id ? editingRecord : record)); setSaveConfirmOpen(false); setDocumentEditing(false) }} type="button">저장</button>
            </div>
          </div>
        </div>
      )}

      {approvalConfirmOpen && editingRecord && (
        <div className="absolute inset-x-0 bottom-[82px] top-[68px] z-50 grid place-items-center bg-[#1f2d21]/45 p-6 backdrop-blur-[2px]">
          <div className="w-full rounded-[20px] bg-white p-6 text-center shadow-2xl">
            <h3 className="text-[17px] font-extrabold">정말로 견적을 승인하겠습니까?</h3>
            <p className="mt-2 text-[10px] text-[#8b928d]">승인하면 견적 분류가 견적 승인으로 변경됩니다.</p>
            <div className="mt-6 grid grid-cols-2 gap-2">
              <button className="h-11 rounded-xl border border-[#d9ded9] text-[11px] font-bold" onClick={() => setApprovalConfirmOpen(false)} type="button">취소</button>
              <button className="h-11 rounded-xl bg-[#346538] text-[11px] font-bold text-white" onClick={() => { const approved = { ...editingRecord, status: "견적 승인", tone: "blue" as const, approvedDate: getTodayShortDate() }; onChangeRecords(records.map((record) => record.id === approved.id ? approved : record)); onFire?.("견적 관리 · 견적 승인"); setApprovalConfirmOpen(false); setEditingRecord(null) }} type="button">승인</button>
            </div>
          </div>
        </div>
      )}

      {deletingRecord && (
        <div className="absolute inset-x-0 bottom-[82px] top-[68px] z-50 grid place-items-center bg-[#1f2d21]/45 p-6 backdrop-blur-[2px]">
          <div className="w-full rounded-[20px] bg-white p-6 text-center shadow-2xl">
            <p className="text-[17px] font-extrabold text-[#29312b]">
              정말 삭제하시겠습니까?
            </p>
            <p className="mt-2 text-[10px] text-[#8b928d]">
              삭제된 데이터는 복구할 수 없습니다.
            </p>
            <div className="mt-6 grid grid-cols-2 gap-2">
              <button
                className="h-11 rounded-xl border border-[#d9ded9] bg-white text-[11px] font-bold text-[#69716b]"
                onClick={() => setDeletingRecord(null)}
                type="button"
              >
                취소
              </button>
              <button
                className="h-11 rounded-xl bg-[#c75f56] text-[11px] font-bold text-white"
                onClick={() => {
                  onChangeRecords(
                    records.filter((record) => record.id !== deletingRecord.id),
                  )
                  onFire?.("견적 관리 · 행 삭제 시")
                  setDeletingRecord(null)
                }}
                type="button"
              >
                삭제
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function PdfCanvasPreview({ url }: { url: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [failed, setFailed] = useState(false)

  useEffect(() => {
    let cancelled = false
    const loadingTask = getDocument(url)

    const renderPage = async () => {
      try {
        const pdf = await loadingTask.promise
        const page = await pdf.getPage(1)
        const viewport = page.getViewport({ scale: 1.6 })
        const canvas = canvasRef.current
        if (!canvas || cancelled) return
        const context = canvas.getContext("2d")
        if (!context) return

        canvas.width = viewport.width
        canvas.height = viewport.height
        await page.render({ canvas, canvasContext: context, viewport }).promise
      } catch {
        if (!cancelled) setFailed(true)
      }
    }

    void renderPage()
    return () => {
      cancelled = true
      void loadingTask.destroy()
    }
  }, [url])

  if (failed) {
    return (
      <div className="grid min-h-[520px] place-items-center bg-white p-6 text-center">
        <div>
          <Icon className="mx-auto text-[#7a847c]" name="document" size={32} />
          <p className="mt-3 text-[11px] font-bold text-[#4b544d]">
            PDF 미리보기를 불러오지 못했습니다.
          </p>
          <a
            className="mt-3 inline-block text-[10px] font-bold text-[#346538] underline"
            href={url}
            rel="noreferrer"
            target="_blank"
          >
            새 창에서 PDF 열기
          </a>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-[520px] bg-white">
      <canvas
        aria-label="사용자가 첨부한 원본 견적서 미리보기"
        className="h-auto w-full"
        ref={canvasRef}
      />
    </div>
  )
}

function CustomerVideoPanel({
  record,
  onEdit,
}: {
  record: EstimateRecord
  onEdit?: () => void
}) {
  if (!record.videoUrl) {
    return (
      <div className="grid min-h-[360px] place-items-center rounded-[20px] bg-white p-8 text-center shadow-[0_5px_18px_rgba(36,58,39,.06)]">
        <div>
          <span className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-[#edf3ed] text-[#346538]">
            <Icon name="camera" size={25} />
          </span>
          <p className="mt-4 text-[14px] font-extrabold text-[#343d36]">
            업로드된 고객 영상이 없습니다
          </p>
          <p className="mt-2 text-[10px] leading-5 text-[#858d87]">
            고객이 영상을 등록하면 이 화면에서
            <br />
            바로 확인할 수 있습니다.
          </p>
          {onEdit && (
            <button
              className="mt-5 rounded-xl border border-[#cfd8d0] bg-[#f8faf8] px-4 py-2.5 text-[10px] font-bold text-[#346538]"
              onClick={onEdit}
              type="button"
            >
              견적 정보로 돌아가기
            </button>
          )}
        </div>
      </div>
    )
  }

  return (
    <section className="overflow-hidden rounded-[20px] bg-white shadow-[0_5px_18px_rgba(36,58,39,.08)]">
      <div className="bg-[#1d251f]">
        <video
          aria-label={`${record.name} 고객이 업로드한 이사 현장 영상`}
          className="aspect-[9/14] max-h-[520px] w-full bg-black object-contain"
          controls
          playsInline
          preload="metadata"
          src={record.videoUrl}
        >
          고객 영상을 재생할 수 없는 브라우저입니다.
        </video>
      </div>
      <div className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="truncate text-[12px] font-extrabold text-[#343d36]">
              {record.videoFileName || `${record.name}_이사현장.mp4`}
            </p>
            <p className="mt-1 text-[9px] font-medium text-[#8a928c]">
              {record.videoUploadedAt || "고객 업로드 영상"}
            </p>
          </div>
          <span className="shrink-0 rounded-full bg-[#edf3ed] px-2.5 py-1 text-[9px] font-extrabold text-[#346538]">
            고객 첨부
          </span>
        </div>
        <div className="mt-3 rounded-xl bg-[#f5f7f5] p-3">
          <p className="text-[10px] leading-5 text-[#626b64]">
            영상을 재생하며 이삿짐 양, 대형 가구, 진입로와 작업 환경을 확인하세요.
          </p>
        </div>
        {onEdit && (
          <button
            className="mt-4 flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-[#346538] text-[11px] font-bold text-white"
            onClick={onEdit}
            type="button"
          >
            <Icon name="edit" size={15} />
            이 영상을 참고해 견적 수정
          </button>
        )}
      </div>
    </section>
  )
}

function CostInput({
  label,
  value,
  suffix,
  onChange,
}: {
  label: string
  value: string
  suffix: string
  onChange: (value: string) => void
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-[9px] font-bold text-[#727a74]">{label}</span>
      <span className="relative block">
        <input
          className="h-10 w-full rounded-lg border border-[#dfe4df] bg-white px-3 pr-9 text-right text-[11px] font-bold text-[#3d453f] outline-none placeholder:text-[#b0b6b1] focus:border-[#346538]"
          inputMode="numeric"
          onChange={(event) => onChange(event.target.value)}
          placeholder="0"
          value={value}
        />
        <span className="absolute right-3 top-3 text-[9px] font-semibold text-[#858c87]">
          {suffix}
        </span>
      </span>
    </label>
  )
}

function EstimateRegistrationSteps({
  current,
  pdfMode = false,
}: {
  current: 1 | 2 | 3 | 4
  pdfMode?: boolean
}) {
  const steps = pdfMode
    ? ([["첨부", 1], ["미리보기", 3], ["견적 등록", 4]] as const)
    : ([["첨부", 1], ["수정", 2], ["미리보기", 3], ["견적 등록", 4]] as const)
  const currentIndex = steps.findIndex(([, step]) => step === current)
  return (
    <div className="mb-5 px-2 pt-1">
      <div className="flex items-center">
        {steps.map(([label, step], index) => {
          const active = index === currentIndex
          const completed = index < currentIndex
          return (
            <div className="contents" key={label}>
              <div className="flex min-w-0 flex-col items-center gap-1.5">
                <span className={`grid h-7 w-7 place-items-center rounded-full text-[10px] font-extrabold ${active ? "bg-[#346538] text-white" : completed ? "bg-[#dce9dd] text-[#346538]" : "bg-[#eef0ee] text-[#929994]"}`}>{completed ? <Icon name="check" size={13} /> : index + 1}</span>
                <span className={`whitespace-nowrap text-[8px] font-bold ${active ? "text-[#346538]" : "text-[#8a918c]"}`}>{label}</span>
              </div>
              {index < steps.length - 1 && <span className={`mx-2 mb-5 h-px flex-1 ${completed ? "bg-[#8eaa91]" : "bg-[#dfe4df]"}`} />}
            </div>
          )
        })}
      </div>
    </div>
  )
}

function EstimateRegistration({
  onComplete,
}: {
  onComplete: (estimate: {
    name: string
    date: string
    status: string
    phone?: string
    documentUrl?: string
    documentData?: EstimateDocumentData
  }) => void
}) {
  const [loading, setLoading] = useState(false)
  const [uploaded, setUploaded] = useState(false)
  const [chooserOpen, setChooserOpen] = useState(false)
  const [previewUrl, setPreviewUrl] = useState("")
  const [selectedFileName, setSelectedFileName] = useState("")
  const [showPreview, setShowPreview] = useState(false)
  const [registrationStep, setRegistrationStep] = useState<1 | 2 | 3 | 4>(1)
  const [registrationDraft, setRegistrationDraft] = useState<EstimateDocumentData | null>(null)
  const [uploadedKind, setUploadedKind] = useState<"photo" | "pdf" | null>(null)
  const [uploadedDocumentUrl, setUploadedDocumentUrl] = useState("")
  const [showRegistrationForm, setShowRegistrationForm] = useState(false)
  const [registrationMeta, setRegistrationMeta] = useState({
    name: "",
    date: "",
    status: "견적 검토",
  })
  const [detectedFields, setDetectedFields] = useState<
    Array<{ id: string; label: string; value: string }>
  >([])
  const [openSections, setOpenSections] = useState(["items", "options", "cost"])
  const [form, setForm] = useState({
    companyName: "",
    estimateDate: "",
    workDate: "",
    transportDate: "",
    customer: "",
    customerTel: "",
    origin: "",
    destination: "",
    packingType: "",
    workMethod: "",
    volume: "",
    note: "",
    piano: "",
    stoneBed: "",
    assemblyCabinet: "",
    wallTv: "",
    homeTheater: "",
    manualWork: "",
    massageChair: "",
    aircon: "",
    movingCost: "",
    movingLadderCost: "",
    departureLadderFloor: "",
    departureLadderCost: "",
    destinationLadderFloor: "",
    destinationLadderCost: "",
    ladderSubtotal: "",
    total: "",
    deposit: "",
    balance: "",
    managerPhone: "",
  })
  const [items, setItems] = useState<
    Array<{ id: number; name: string; count: number }>
  >([])

  const analyzeDocument = () => {
    const sampleCustomers = ["김민준", "이서연", "박도윤", "최지우", "정하린"]
    const recognizedCustomer =
      sampleCustomers[Math.floor(Math.random() * sampleCustomers.length)]
    setLoading(true)
    window.setTimeout(() => {
      setForm({
        companyName: "",
        estimateDate: "2026.09.04",
        workDate: "2026.09.04",
        transportDate: "",
        customer: recognizedCustomer,
        customerTel: `010-${String(Math.floor(1000 + Math.random() * 9000))}-${String(
          Math.floor(1000 + Math.random() * 9000),
        )}`,
        origin: "",
        destination: "",
        packingType: "",
        workMethod: "",
        volume: "3.5",
        note: "",
        piano: "0",
        stoneBed: "0",
        assemblyCabinet: "0",
        wallTv: "0",
        homeTheater: "0",
        manualWork: "0",
        massageChair: "0",
        aircon: "0",
        movingCost: "0",
        movingLadderCost: "0",
        departureLadderFloor: "0",
        departureLadderCost: "0",
        destinationLadderFloor: "0",
        destinationLadderCost: "0",
        ladderSubtotal: "0",
        total: "1,320,000",
        deposit: "132,000",
        balance: "1,188,000",
        managerPhone: "010-9445-8224",
      })
      setItems([
        { id: 1, name: "모니터", count: 6 },
        { id: 2, name: "컴퓨터", count: 3 },
        { id: 3, name: "공기청정기", count: 1 },
        { id: 4, name: "소형 냉장고", count: 1 },
        { id: 5, name: "전자레인지", count: 1 },
        { id: 6, name: "프린터/복합기", count: 1 },
        { id: 7, name: "TV", count: 1 },
        { id: 8, name: "의자", count: 6 },
        { id: 9, name: "테이블", count: 2 },
        { id: 10, name: "원형 테이블", count: 1 },
        { id: 11, name: "파티션", count: 3 },
        { id: 12, name: "대형 캐비넷", count: 2 },
        { id: 13, name: "책상", count: 2 },
        { id: 14, name: "데스크 수납함", count: 3 },
        { id: 15, name: "보조 서랍장", count: 3 },
      ])
      setUploaded(true)
      setRegistrationStep(2)
      setLoading(false)
    }, 900)
  }
  const analyzePdf = async (file: File) => {
    setLoading(true)
    const objectUrl = URL.createObjectURL(file)
    setUploadedDocumentUrl(objectUrl)

    try {
      const pdf = await getDocument({ data: await file.arrayBuffer() }).promise
      const textParts: string[] = []
      for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber += 1) {
        const page = await pdf.getPage(pageNumber)
        const content = await page.getTextContent()
        content.items.forEach((item) => {
          if ("str" in item && item.str.trim()) textParts.push(item.str.trim())
        })
      }
      const fullText = textParts.join(" ")
      const fieldLabels = [
        "업체명",
        "담당자",
        "포장일",
        "출발지",
        "운송일",
        "도착지",
        "작업 내용",
        "이사 물량",
        "비고",
        "작업 인원",
        "차량",
        "금액",
        "부가세",
        "총 비용",
      ]
      const fields = fieldLabels
        .filter((label) => fullText.replace(/\s/g, "").includes(label.replace(/\s/g, "")))
        .map((label, index) => ({
          id: `field-${index}`,
          label,
          value: label === "담당자" && fullText.includes("김선국") ? "김선국" : "",
        }))

      const itemNames = [
        "모니터",
        "컴퓨터",
        "공기청정기",
        "소형 냉장고",
        "전자레인지",
        "프린터/복합기",
        "TV",
        "의자",
        "테이블",
        "원형 테이블",
        "파티션",
        "대형 캐비넷",
        "책상",
        "데스크 수납함",
        "보조 서랍장",
      ]
      const recognizedItems = itemNames.flatMap((name, index) => {
        const textIndex = textParts.findIndex(
          (part) => part.replace(/\s/g, "") === name.replace(/\s/g, ""),
        )
        if (textIndex < 0) return []
        const countText = textParts
          .slice(textIndex + 1, textIndex + 4)
          .find((part) => /^\d+$/.test(part))
        return [{ id: index + 1, name, count: Number(countText || 0) }]
      })

      setDetectedFields(fields)
      setItems(recognizedItems)
      const detectedName =
        fields.find((field) => field.label === "담당자")?.value || ""
      const detectedDate = fullText.match(/20(\d{2})\D+(\d{1,2})\D+(\d{1,2})/)
      setRegistrationMeta((current) => ({
        ...current,
        name: detectedName,
        date: detectedDate
          ? `${detectedDate[1]}.${detectedDate[2].padStart(2, "0")}.${detectedDate[3].padStart(2, "0")}`
          : "",
      }))
      setUploaded(true)
    } catch {
      setDetectedFields([
        { id: "field-0", label: "인식된 내용", value: "" },
      ])
      setItems([])
      setUploaded(true)
    } finally {
      setLoading(false)
      setRegistrationStep(3)
    }
  }
  const handleFile = (
    event: ChangeEvent<HTMLInputElement>,
    kind: "photo" | "pdf",
  ) => {
    const file = event.target.files?.[0]
    if (!file) return
    setChooserOpen(false)
    setUploadedKind(kind)
    setSelectedFileName(file.name)

    if (kind === "photo") {
      setPreviewUrl(URL.createObjectURL(file))
    } else {
      setPreviewUrl("")
      void analyzePdf(file)
    }
  }
  const updateForm = (key: keyof typeof form, value: string) =>
    setForm((current) => ({ ...current, [key]: value }))
  const toggleSection = (section: string) =>
    setOpenSections((current) =>
      current.includes(section)
        ? current.filter((item) => item !== section)
        : [...current, section],
    )
  const goBackToUpload = () => {
    setUploaded(false)
    setUploadedDocumentUrl("")
    setDetectedFields([])
    setItems([])
    setSelectedFileName("")
    setPreviewUrl("")
    setShowPreview(false)
    setRegistrationStep(1)
    setRegistrationDraft(null)
    setUploadedKind(null)
  }
  const inputClass =
    "h-11 w-full rounded-xl border border-[#dfe4df] bg-white px-3 text-[12px] font-semibold text-[#3d453f] outline-none placeholder:text-[#b0b6b1] focus:border-[#346538]"

  const detectedManager = detectedFields.find((field) => field.label === "담당자")?.value || ""
  const recognizedName = form.customer || registrationMeta.name || detectedManager || "담당자 미인식"
  const recognizedDateRaw = form.estimateDate || form.workDate || registrationMeta.date
  const recognizedDate = recognizedDateRaw
    ? recognizedDateRaw.replace(/-/g, ".").replace(/^20/, "")
    : "견적일 미인식"
  const registrationDocumentData: EstimateDocumentData = {
    ...getEstimateDocument({ id: 0, status: registrationMeta.status, name: recognizedName, date: recognizedDate, tone: "red" }),
    companyName: form.companyName || "명품익스프레스",
    customer: recognizedName,
    phone: form.customerTel || "010-0000-0000",
    estimateDate: recognizedDate,
    moveDate: form.workDate ? form.workDate.replace(/-/g, ".") : recognizedDate,
    transportDate: form.transportDate ? form.transportDate.replace(/-/g, ".") : recognizedDate,
    origin: form.origin || "출발지 미인식",
    destination: form.destination || "도착지 미인식",
    volume: `${form.volume || "0"}톤`,
    note: form.note || "이미지에서 인식된 견적 정보입니다.",
    movingCost: form.movingCost || "0",
    extraCost: form.movingLadderCost || "0",
    total: form.total || "0",
    deposit: form.deposit || "0",
    balance: form.balance || "0",
    departureLadder: form.departureLadderCost || "0",
    destinationLadder: form.destinationLadderCost || "0",
    ladderSubtotal: form.ladderSubtotal || "0",
    optionCosts: [form.piano, form.stoneBed, form.assemblyCabinet, form.wallTv, form.homeTheater, form.manualWork, form.massageChair, form.aircon],
    items: items.map((item) => ({ id: item.id, name: item.name, quantity: `${item.count}` })),
    itemRowCount: Math.max(8, Math.ceil(items.length / 4)),
  }
  const activeRegistrationDocument = registrationDraft || registrationDocumentData
  const finalRegistrationName = uploadedKind === "pdf" ? registrationMeta.name : activeRegistrationDocument.customer
  const finalRegistrationDate = uploadedKind === "pdf" ? registrationMeta.date : activeRegistrationDocument.estimateDate
  const finalRegistrationDocument = uploadedKind === "pdf"
    ? { ...activeRegistrationDocument, customer: finalRegistrationName, estimateDate: finalRegistrationDate }
    : activeRegistrationDocument
  const registrationRecord: EstimateRecord = {
    id: 0,
    status: registrationMeta.status,
    name: activeRegistrationDocument.customer,
    date: activeRegistrationDocument.estimateDate,
    tone: "red",
    documentUrl: uploadedDocumentUrl || estimateTemplateUrl,
    documentData: activeRegistrationDocument,
  }

  if (registrationStep === 2) {
    return (
      <div className="px-4 pb-28 pt-5">
        <EstimateRegistrationSteps current={2} pdfMode={uploadedKind === "pdf"} />
        <div className="mb-4 flex items-center justify-between">
          <div><p className="text-[9px] font-extrabold tracking-[.12em] text-[#7a927d]">STEP 2</p><h2 className="mt-1 text-[20px] font-extrabold text-[#346538]">견적서 수정</h2></div>
          <button className="h-9 rounded-xl bg-[#346538] px-4 text-[11px] font-extrabold text-white" onClick={() => { setRegistrationDraft(activeRegistrationDocument); setRegistrationStep(3) }} type="button">다음</button>
        </div>
        <EstimateDocumentViewer
          editable
          onChange={setRegistrationDraft}
          record={registrationRecord}
          showDownload={false}
        />
      </div>
    )
  }

  if (registrationStep === 3) {
    return (
      <div className="px-4 pb-28 pt-5">
        <EstimateRegistrationSteps current={3} pdfMode={uploadedKind === "pdf"} />
        <div className="mb-4 flex items-center justify-between">
          <button className="flex items-center gap-1 text-[10px] font-bold text-[#59625b]" onClick={() => uploadedKind === "pdf" ? goBackToUpload() : setRegistrationStep(2)} type="button"><Icon className="rotate-180" name="arrowRight" size={14} />{uploadedKind === "pdf" ? "첨부로" : "수정으로"}</button>
          <h2 className="text-[16px] font-extrabold text-[#29312b]">견적서 미리보기</h2>
          <button className="h-9 rounded-xl bg-[#346538] px-4 text-[11px] font-extrabold text-white" onClick={() => setRegistrationStep(4)} type="button">다음</button>
        </div>
        <EstimateDocumentViewer editable={false} record={registrationRecord} />
      </div>
    )
  }

  if (registrationStep === 4) {
    return (
      <div className="px-4 pb-28 pt-5">
        <EstimateRegistrationSteps current={4} pdfMode={uploadedKind === "pdf"} />
        <section className="rounded-[20px] bg-white p-5 shadow-[0_5px_18px_rgba(36,58,39,.06)]">
          <p className="text-[9px] font-extrabold tracking-[.12em] text-[#7a927d]">{uploadedKind === "pdf" ? "STEP 3" : "STEP 4"}</p>
          <h2 className="mt-1 text-[20px] font-extrabold text-[#346538]">견적 등록</h2>
          {uploadedKind === "pdf" ? (
            <div className="mt-5 space-y-3">
              <label className="block"><span className="mb-1.5 block text-[10px] font-bold text-[#687069]">이름</span><input className="h-11 w-full rounded-xl border border-[#dfe4df] bg-white px-3 text-[12px] font-semibold outline-none focus:border-[#346538]" onChange={(event) => setRegistrationMeta((current) => ({ ...current, name: event.target.value }))} placeholder="고객 이름을 입력하세요" value={registrationMeta.name} /></label>
              <label className="block"><span className="mb-1.5 block text-[10px] font-bold text-[#687069]">날짜</span><input className="h-11 w-full rounded-xl border border-[#dfe4df] bg-white px-3 text-[12px] font-semibold outline-none focus:border-[#346538]" inputMode="numeric" maxLength={8} onChange={(event) => setRegistrationMeta((current) => ({ ...current, date: formatShortDateInput(event.target.value, (event.nativeEvent as InputEvent).inputType?.startsWith("delete")) }))} placeholder="YY.MM.DD" value={registrationMeta.date} /></label>
            </div>
          ) : (
            <p className="mt-5 rounded-xl bg-[#f7f8f7] px-4 py-3 text-[11px] text-[#59615b]">견적서에서 인식한 담당자와 견적일이 등록 정보로 사용됩니다.</p>
          )}
          <label className="mt-5 block">
            <span className="mb-2 block text-[10px] font-extrabold text-[#59615b]">분류</span>
            <select className="h-11 w-full rounded-xl border border-[#dfe4df] bg-white px-3 text-[12px] font-semibold" onChange={(event) => setRegistrationMeta((current) => ({ ...current, status: event.target.value }))} value={registrationMeta.status}>
              <option>견적 검토</option><option>견적 승인</option><option>견적 확정</option>
            </select>
          </label>
        </section>
        <div className="mt-4 grid grid-cols-[1fr_2fr] gap-2">
          <button className="h-12 rounded-xl border border-[#d9ded9] bg-white text-[11px] font-bold" onClick={() => setRegistrationStep(3)} type="button">이전</button>
          <button className="h-12 rounded-xl bg-[#346538] text-[12px] font-extrabold text-white disabled:opacity-40" disabled={!finalRegistrationName.trim() || !finalRegistrationDate.trim()} onClick={() => onComplete({ name: finalRegistrationName, date: finalRegistrationDate, status: registrationMeta.status, phone: finalRegistrationDocument.phone, documentUrl: uploadedDocumentUrl || estimateTemplateUrl, documentData: finalRegistrationDocument })} type="button">견적 관리에 등록</button>
        </div>
      </div>
    )
  }

  if (showPreview) {
    return (
      <div className="px-4 pb-28 pt-5">
        <div className="flex items-center justify-between">
          <button className="flex h-9 items-center gap-1 rounded-lg bg-[#edf3ed] px-3 text-[10px] font-bold text-[#346538]" onClick={goBackToUpload} type="button"><Icon className="rotate-180" name="arrowRight" size={14} />이전</button>
          <h2 className="text-[14px] font-extrabold text-[#29312b]">견적서 미리보기</h2>
          <button aria-label="미리보기 닫기" className="grid h-9 w-9 place-items-center rounded-full bg-white" onClick={goBackToUpload} type="button"><Icon name="x" size={16} /></button>
        </div>
        <div className="mt-4 max-h-[calc(100dvh-300px)] overflow-auto rounded-xl bg-[#dfe3df] p-3">
          <div className="mx-auto w-[620px] shadow-[0_5px_20px_rgba(30,43,33,.16)] [container-type:inline-size]">
            <EstimateTemplateSheet data={registrationDocumentData} editable={false} />
          </div>
        </div>
        <label className="mt-4 block rounded-2xl bg-white p-4 shadow-[0_4px_16px_rgba(36,58,39,.06)]">
          <span className="mb-2 block text-[10px] font-extrabold text-[#59615b]">분류</span>
          <select className="h-11 w-full rounded-xl border border-[#dfe4df] bg-white px-3 text-[12px] font-semibold" onChange={(event) => setRegistrationMeta((current) => ({ ...current, status: event.target.value }))} value={registrationMeta.status}>
            <option>견적 검토</option><option>견적 승인</option><option>견적 확정</option>
          </select>
          <p className="mt-2 text-[9px] text-[#8a918c]">담당자 {recognizedName} · 견적일 {recognizedDate}</p>
        </label>
        <button
          className="mt-4 h-12 w-full rounded-xl bg-[#346538] text-[12px] font-extrabold text-white"
          onClick={() => onComplete({ name: recognizedName, date: recognizedDate, status: registrationMeta.status, phone: registrationDocumentData.phone, documentUrl: uploadedDocumentUrl || estimateTemplateUrl, documentData: registrationDocumentData })}
          type="button"
        >
          견적 관리에 등록
        </button>
      </div>
    )
  }

  if (uploaded && uploadedDocumentUrl) {
    return (
      <div className="px-4 pb-28 pt-6">
        <h2 className="px-1 text-[24px] font-extrabold tracking-[-0.04em] text-[#346538]">
          견적서 등록
        </h2>
        <section className="mt-5 rounded-[22px] bg-white p-5 shadow-[0_5px_18px_rgba(36,58,39,.06)]">
          <div className="mb-5 flex items-start justify-between">
            <div>
              <span className="text-[10px] font-extrabold uppercase tracking-[0.12em] text-[#79917c]">
                Step 2
              </span>
              <h3 className="mt-1 text-[17px] font-extrabold text-[#29312b]">
                견적 관리 등록 정보
              </h3>
              <p className="mt-1 text-[10px] leading-4 text-[#8a918c]">
                견적 기록 목록에 표시할 정보를 입력해 주세요.
              </p>
            </div>
            <span className="rounded-md border border-[#8eaa91] px-2 py-1 text-[9px] font-extrabold text-[#346538]">
              PDF 등록
            </span>
          </div>

          <div className="mb-5 flex items-center gap-2 rounded-xl bg-[#f5f7f5] px-3 py-3">
            <Icon className="shrink-0 text-[#346538]" name="document" size={18} />
            <span className="min-w-0 flex-1 truncate text-[10px] font-semibold text-[#59615b]">
              {selectedFileName}
            </span>
            <span className="text-[9px] font-bold text-[#346538]">분석 완료</span>
          </div>

          <div className="space-y-4">
            <label className="block">
              <span className="mb-1.5 block text-[10px] font-bold text-[#687069]">
                이름
              </span>
              <input
                className={inputClass}
                onChange={(event) =>
                  setRegistrationMeta((current) => ({
                    ...current,
                    name: event.target.value,
                  }))
                }
                placeholder="고객 이름을 입력하세요"
                value={registrationMeta.name}
              />
            </label>
            <label className="block">
              <span className="mb-1.5 block text-[10px] font-bold text-[#687069]">
                날짜
              </span>
              <input
                className={inputClass}
                inputMode="numeric"
                onChange={(event) =>
                  setRegistrationMeta((current) => ({
                    ...current,
                    date: event.target.value,
                  }))
                }
                placeholder="YY.MM.DD"
                value={registrationMeta.date}
              />
            </label>
            <label className="block">
              <span className="mb-1.5 block text-[10px] font-bold text-[#687069]">
                분류
              </span>
              <select
                className={`${inputClass} appearance-none`}
                onChange={(event) =>
                  setRegistrationMeta((current) => ({
                    ...current,
                    status: event.target.value,
                  }))
                }
                value={registrationMeta.status}
              >
                <option>견적 검토</option>
                <option>견적 승인</option>
                <option>견적 확정</option>
              </select>
            </label>
          </div>
        </section>
        <div className="mt-5 grid grid-cols-[1fr_2fr] gap-2">
          <button
            className="h-13 rounded-[14px] border border-[#d8ded9] bg-white text-[12px] font-bold text-[#69716b]"
            onClick={goBackToUpload}
            type="button"
          >
            이전
          </button>
          <button
            className="h-13 rounded-[14px] bg-[#346538] text-[14px] font-bold text-white shadow-[0_6px_18px_rgba(52,101,56,.22)] disabled:cursor-not-allowed disabled:opacity-40"
            disabled={!registrationMeta.name.trim() || !registrationMeta.date.trim()}
            onClick={() => setShowPreview(true)}
            type="button"
          >
            다음
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="px-4 pb-28 pt-6">
      <EstimateRegistrationSteps current={1} pdfMode={uploadedKind === "pdf"} />
      <h2 className="px-1 text-[24px] font-extrabold tracking-[-0.04em] text-[#346538]">
        견적서 등록
      </h2>

      {!uploaded ? (
        <section className="relative mt-5 overflow-hidden rounded-[22px] border border-[#e0e6e1] bg-white p-6 shadow-[0_5px_18px_rgba(36,58,39,.06)]">
          <span className="text-[10px] font-extrabold uppercase tracking-[0.12em] text-[#79917c]">
            Step 1
          </span>
          <button
            className="mt-5 block w-full text-center"
            onClick={() => setChooserOpen(true)}
            type="button"
          >
            <span className="mx-auto flex w-fit items-center gap-3">
              <span className="grid h-14 w-14 place-items-center rounded-2xl bg-[#edf3ed] text-[#346538]">
                <Icon name="camera" size={27} />
              </span>
              <span className="grid h-14 w-14 place-items-center rounded-2xl bg-[#edf3ed] text-[#346538]">
                <Icon name="document" size={26} />
              </span>
            </span>
            <strong className="mx-auto mt-5 block max-w-[290px] text-[16px] leading-6 text-[#303832]">
              과거 수기 견적서를 촬영하거나 PDF 파일을 첨부하세요.
            </strong>
            <span className="mt-2 block text-[10px] text-[#8f9691]">
              AI가 텍스트를 자동 인식하여 아래 필드에 입력합니다.
            </span>
          </button>

          {selectedFileName && (
            <div className="mt-5 flex items-center gap-2 rounded-xl bg-[#f6f8f6] px-3 py-2.5 text-left">
              <Icon className="text-[#346538]" name="document" size={17} />
              <span className="min-w-0 flex-1 truncate text-[10px] font-semibold text-[#59615b]">
                {selectedFileName}
              </span>
            </div>
          )}

          {previewUrl && !loading && (
            <div className="mt-5 rounded-2xl border border-[#e1e6e1] bg-[#f8f9f8] p-3">
              <p className="mb-2 text-left text-[10px] font-extrabold text-[#4c554e]">
                촬영 이미지 미리보기
              </p>
              <img
                alt="촬영한 수기 견적서 미리보기"
                className="h-44 w-full rounded-xl object-cover"
                src={previewUrl}
              />
              <div className="mt-3 flex justify-end gap-2">
                <button
                  className="rounded-lg border border-[#d8ded9] bg-white px-3 py-2 text-[10px] font-bold text-[#707871]"
                  onClick={() => {
                    setPreviewUrl("")
                    setSelectedFileName("")
                  }}
                  type="button"
                >
                  다시 촬영
                </button>
                <button
                  className="rounded-lg bg-[#346538] px-4 py-2 text-[10px] font-bold text-white"
                  onClick={analyzeDocument}
                  type="button"
                >
                  확인
                </button>
              </div>
            </div>
          )}

          {(previewUrl || selectedFileName) && (
            <div className="absolute bottom-3 right-3 h-14 w-12 rotate-3 overflow-hidden rounded-lg border-2 border-white bg-[#e9e3d7] shadow-[0_4px_12px_rgba(34,43,36,.2)]">
              {previewUrl ? (
                <img
                  alt=""
                  className="h-full w-full object-cover"
                  src={previewUrl}
                />
              ) : (
                <span className="grid h-full w-full place-items-center text-[#6f776f]">
                  <Icon name="document" size={22} />
                </span>
              )}
            </div>
          )}

          {chooserOpen && (
            <div className="absolute inset-0 z-10 flex items-end bg-[#1e2b20]/35 p-4 backdrop-blur-[2px]">
              <div className="w-full rounded-[18px] bg-white p-4 shadow-xl">
                <div className="mb-4 flex items-center justify-between">
                  <p className="text-[13px] font-extrabold text-[#303832]">첨부 방식 선택</p>
                  <button
                    aria-label="첨부 방식 닫기"
                    className="grid h-8 w-8 place-items-center rounded-full bg-[#f1f4f1] text-[#677068]"
                    onClick={() => setChooserOpen(false)}
                    type="button"
                  >
                    <Icon name="x" size={16} />
                  </button>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <label className="flex cursor-pointer flex-col items-center gap-2 rounded-xl bg-[#edf3ed] p-4 text-[#346538]">
                    <input
                      accept="image/*"
                      capture="environment"
                      className="sr-only"
                      onChange={(event) => handleFile(event, "photo")}
                      type="file"
                    />
                    <Icon name="camera" size={25} />
                    <span className="text-[10px] font-bold">사진 촬영</span>
                  </label>
                  <label className="flex cursor-pointer flex-col items-center gap-2 rounded-xl bg-[#edf3ed] p-4 text-[#346538]">
                    <input
                      accept=".pdf,application/pdf"
                      className="sr-only"
                      onChange={(event) => handleFile(event, "pdf")}
                      type="file"
                    />
                    <Icon name="document" size={24} />
                    <span className="text-[10px] font-bold">PDF 첨부</span>
                  </label>
                </div>
              </div>
            </div>
          )}

          {loading && (
            <div className="absolute inset-0 z-20 grid place-items-center rounded-[22px] bg-white/92 backdrop-blur-sm">
              <div className="text-center">
                <span className="mx-auto block h-9 w-9 animate-spin rounded-full border-2 border-[#dce7dd] border-t-[#346538]" />
                <p className="mt-3 text-[11px] font-bold text-[#346538]">
                  AI가 견적서를 분석하고 있습니다
                </p>
                <p className="mt-1 text-[9px] text-[#929994]">완료되면 Step 2로 이동합니다.</p>
              </div>
            </div>
          )}
        </section>
      ) : (
        <>
      <section className="mt-5 rounded-[22px] bg-white p-5 shadow-[0_5px_18px_rgba(36,58,39,.06)]">
        <div className="mb-5 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-extrabold uppercase tracking-[0.12em] text-[#79917c]">
              Step 2
            </span>
            <h3 className="mt-1 text-[17px] font-extrabold text-[#29312b]">견적 정보 입력</h3>
          </div>
          {uploaded && (
            <span className="rounded-md border border-[#8eaa91] px-2 py-1 text-[9px] font-extrabold text-[#346538]">
              AI 인식 완료
            </span>
          )}
        </div>

        <div className="rounded-xl border border-[#dfe4df]">
          <div className="border-b border-[#e7ebe7] bg-[#f7f9f7] px-4 py-3 text-[11px] font-extrabold text-[#346538]">
            기본 정보
          </div>
          <div className="space-y-4 p-4">
            {detectedFields.length > 0 ? (
              detectedFields.map((field) => (
                <label className="block" key={field.id}>
                  <span className="mb-1.5 flex items-center gap-1.5 text-[10px] font-bold text-[#69716b]">
                    <Icon name="document" size={14} />
                    {field.label}
                  </span>
                  <span className="relative block">
                    <input
                      className={`${inputClass} pr-11`}
                      onChange={(event) =>
                        setDetectedFields((current) =>
                          current.map((currentField) =>
                            currentField.id === field.id
                              ? { ...currentField, value: event.target.value }
                              : currentField,
                          ),
                        )
                      }
                      placeholder={`${field.label} 입력`}
                      value={field.value}
                    />
                    <span className="absolute right-3 top-3 rounded border border-[#8eaa91] px-1.5 py-0.5 text-[8px] font-extrabold text-[#346538]">
                      AI
                    </span>
                  </span>
                </label>
              ))
            ) : (
              <>
              {[
              ["companyName", "업체명", "document", "업체명을 입력하세요"],
              ["customer", "담당자", "user", "담당자명을 입력하세요"],
              ["customerTel", "연락처", "user", "전화번호를 입력하세요"],
              ["estimateDate", "견적일", "calendar", "YYYY.MM.DD"],
              ["workDate", "작업일", "calendar", "YYYY.MM.DD"],
              ["transportDate", "운송일", "calendar", "YYYY.MM.DD"],
              ["origin", "출발지", "pin", "주소 검색"],
              ["destination", "도착지", "pin", "주소 검색"],
            ].map(([key, label, icon, placeholder]) => (
              <label className="block" key={key}>
                <span className="mb-1.5 flex items-center gap-1.5 text-[10px] font-bold text-[#69716b]">
                  <Icon name={icon as IconName} size={14} />
                  {label}
                </span>
                <span className="relative block">
                  <input
                    className={`${inputClass} ${uploaded ? "pr-11" : ""}`}
                    onChange={(event) =>
                      updateForm(key as keyof typeof form, event.target.value)
                    }
                    placeholder={placeholder}
                    value={form[key as keyof typeof form]}
                  />
                  {uploaded && (
                    <span className="absolute right-3 top-3 rounded border border-[#8eaa91] px-1.5 py-0.5 text-[8px] font-extrabold text-[#346538]">
                      AI
                    </span>
                  )}
                </span>
              </label>
            ))}
            <label className="block">
              <span className="mb-1.5 flex items-center gap-1.5 text-[10px] font-bold text-[#69716b]">
                <Icon name="truck" size={14} />
                이사물량
              </span>
              <span className="relative block">
                <input
                  className={`${inputClass} pr-14`}
                  inputMode="decimal"
                  onChange={(event) => updateForm("volume", event.target.value)}
                  placeholder="0.0"
                  value={form.volume}
                />
                <span className="absolute right-3 top-3 text-[11px] font-bold text-[#7c847e]">
                  톤
                </span>
              </span>
            </label>
            {[
              ["packingType", "포장 구분", "포장 / 일반 / 보관"],
              [
                "workMethod",
                "작업 내용",
                "사다리차 / 승강기 / 계단 작업 내용을 입력하세요",
              ],
              ["note", "비고", "특이사항을 입력하세요"],
            ].map(([key, label, placeholder]) => (
              <label className="block" key={key}>
                <span className="mb-1.5 block text-[10px] font-bold text-[#69716b]">
                  {label}
                </span>
                <input
                  className={`${inputClass} pr-11`}
                  onChange={(event) =>
                    updateForm(key as keyof typeof form, event.target.value)
                  }
                  placeholder={placeholder}
                  value={form[key as keyof typeof form]}
                />
              </label>
            ))}
              </>
            )}
          </div>
        </div>

        {(detectedFields.length > 0
          ? items.length > 0
            ? [{ id: "items", title: "AI 인식 품목" }]
            : []
          : [
          { id: "items", title: "전자기기 / 가구 수량" },
          { id: "options", title: "작업 및 옵션 비용" },
          { id: "cost", title: "최종 비용 확인" },
        ]).map((section) => {
          const isOpen = openSections.includes(section.id)
          return (
            <div className="mt-3 overflow-hidden rounded-xl border border-[#dfe4df]" key={section.id}>
              <button
                className="flex w-full items-center justify-between bg-[#f7f9f7] px-4 py-3.5 text-left text-[11px] font-extrabold text-[#3f4841]"
                onClick={() => toggleSection(section.id)}
                type="button"
              >
                {section.title}
                <Icon
                  className={`text-[#346538] transition-transform ${isOpen ? "rotate-180" : ""}`}
                  name="chevron"
                  size={16}
                />
              </button>
              {isOpen && section.id === "items" && (
                <div className="grid grid-cols-2 gap-2 p-3">
                  {items.map((item) => (
                    <div className="relative rounded-xl bg-[#f4f6f4] p-3 text-center" key={item.id}>
                      <button
                        aria-label={`${item.name || "새 품목"} 삭제`}
                        className="absolute right-1.5 top-1.5 grid h-5 w-5 place-items-center rounded-full text-[#9a6b67] hover:bg-[#f5e9e7]"
                        onClick={() =>
                          setItems((current) =>
                            current.filter((currentItem) => currentItem.id !== item.id),
                          )
                        }
                        type="button"
                      >
                        <Icon name="x" size={11} />
                      </button>
                      <input
                        aria-label="품목명"
                        className="w-full bg-transparent pr-5 text-[10px] font-bold text-[#59615b] outline-none placeholder:text-[#a6ada7]"
                        onChange={(event) =>
                          setItems((current) =>
                            current.map((currentItem) =>
                              currentItem.id === item.id
                                ? { ...currentItem, name: event.target.value }
                                : currentItem,
                            ),
                          )
                        }
                        placeholder="품목명 입력"
                        value={item.name}
                      />
                      <div className="mt-2 flex items-center justify-between">
                        <button
                          className="grid h-6 w-6 place-items-center rounded-md bg-white text-[#687069]"
                          onClick={() =>
                            setItems((current) =>
                              current.map((currentItem) =>
                                currentItem.id === item.id
                                  ? {
                                      ...currentItem,
                                      count: Math.max(0, currentItem.count - 1),
                                    }
                                  : currentItem,
                              ),
                            )
                          }
                          type="button"
                        >
                          −
                        </button>
                        <span className="text-[12px] font-extrabold text-[#303832]">
                          {item.count}
                        </span>
                        <button
                          className="grid h-6 w-6 place-items-center rounded-md bg-[#346538] text-white"
                          onClick={() =>
                            setItems((current) =>
                              current.map((currentItem) =>
                                currentItem.id === item.id
                                  ? { ...currentItem, count: currentItem.count + 1 }
                                  : currentItem,
                              ),
                            )
                          }
                          type="button"
                        >
                          +
                        </button>
                      </div>
                    </div>
                  ))}
                  <button
                    className="min-h-[82px] rounded-xl border border-dashed border-[#b9c2ba] text-[10px] font-bold text-[#8c948e]"
                    onClick={() =>
                      setItems((current) => [
                        ...current,
                        { id: Date.now(), name: "", count: 0 },
                      ])
                    }
                    type="button"
                  >
                    + 품목 추가
                  </button>
                </div>
              )}
              {isOpen && section.id === "options" && (
                <div className="space-y-3 p-3">
                  {[
                    ["piano", "피아노"],
                    ["stoneBed", "돌침대 분해/조립"],
                    ["assemblyCabinet", "조립장 분해/조립"],
                    ["wallTv", "벽걸이TV 탈착/설치"],
                    ["homeTheater", "홈씨어터 분리/설치"],
                    ["manualWork", "수작업"],
                    ["massageChair", "안마의자 분리/설치"],
                    ["aircon", "에어컨 탈착/설치"],
                  ].map(([key, label]) => (
                    <CostInput
                      key={key}
                      label={label}
                      onChange={(value) =>
                        updateForm(key as keyof typeof form, value)
                      }
                      suffix="원"
                      value={form[key as keyof typeof form]}
                    />
                  ))}
                  <div className="grid grid-cols-2 gap-2">
                    <CostInput
                      label="출발지 사다리차 층수"
                      onChange={(value) => updateForm("departureLadderFloor", value)}
                      suffix="층"
                      value={form.departureLadderFloor}
                    />
                    <CostInput
                      label="출발지 사다리 비용"
                      onChange={(value) => updateForm("departureLadderCost", value)}
                      suffix="원"
                      value={form.departureLadderCost}
                    />
                    <CostInput
                      label="도착지 사다리차 층수"
                      onChange={(value) =>
                        updateForm("destinationLadderFloor", value)
                      }
                      suffix="층"
                      value={form.destinationLadderFloor}
                    />
                    <CostInput
                      label="도착지 사다리 비용"
                      onChange={(value) =>
                        updateForm("destinationLadderCost", value)
                      }
                      suffix="원"
                      value={form.destinationLadderCost}
                    />
                  </div>
                  <CostInput
                    label="사다리 소계"
                    onChange={(value) => updateForm("ladderSubtotal", value)}
                    suffix="원"
                    value={form.ladderSubtotal}
                  />
                </div>
              )}
              {isOpen && section.id === "cost" && (
                <div className="space-y-3 p-3">
                  <CostInput
                    label="이사비용"
                    onChange={(value) => updateForm("movingCost", value)}
                    suffix="원"
                    value={form.movingCost}
                  />
                  <CostInput
                    label="사다리비용"
                    onChange={(value) => updateForm("movingLadderCost", value)}
                    suffix="원"
                    value={form.movingLadderCost}
                  />
                  <CostInput
                    label="총비용"
                    onChange={(value) => updateForm("total", value)}
                    suffix="원"
                    value={form.total}
                  />
                  <CostInput
                    label="계약금 (10%)"
                    onChange={(value) => updateForm("deposit", value)}
                    suffix="원"
                    value={form.deposit}
                  />
                  <CostInput
                    label="잔금"
                    onChange={(value) => updateForm("balance", value)}
                    suffix="원"
                    value={form.balance}
                  />
                </div>
              )}
            </div>
          )
        })}
      </section>

      <div className="mt-6 grid grid-cols-[1fr_2fr] gap-2">
        <button
          className="h-13 rounded-[14px] border border-[#d8ded9] bg-white text-[12px] font-bold text-[#69716b]"
          onClick={goBackToUpload}
          type="button"
        >
          이전
        </button>
        <button
          className="h-13 rounded-[14px] bg-[#346538] text-[14px] font-bold text-white shadow-[0_6px_18px_rgba(52,101,56,.22)] transition hover:bg-[#2b582f]"
          onClick={() => setShowPreview(true)}
          type="button"
        >
          다음
        </button>
      </div>
        </>
      )}
    </div>
  )
}

function App() {
  const [drawerOpen, setDrawerOpen] = useState(false)
  const [globalSearchOpen, setGlobalSearchOpen] = useState(false)
  const [globalSearchQuery, setGlobalSearchQuery] = useState("")
  const [notificationOpen, setNotificationOpen] = useState(false)
  const [runtimeNotifications, setRuntimeNotifications] = useState<NotificationItem[]>(initialNotificationItems)
  const [hasUnreadNotifications, setHasUnreadNotifications] = useState(true)
  const [notificationNow, setNotificationNow] = useState(Date.now())
  const [newMemberCount, setNewMemberCount] = useState(9)
  const [reservationRecords, setReservationRecords] =
    useState<ReservationRecord[]>(initialReservations)
  const [selectedReservationId, setSelectedReservationId] = useState<number | null>(
    null,
  )
  const [managedDateStatuses, setManagedDateStatuses] = useState<
    Record<string, ManagedDateStatus>
  >({
    "26.09.20": "closed",
  })
  const [estimateRecords, setEstimateRecords] = useState<EstimateRecord[]>([
    {
      id: 1,
      status: "견적 검토",
      name: "홍길동",
      date: "26.03.25",
      tone: "red",
      videoUrl:
        "https://assets.mixkit.co/videos/15149/15149-360.mp4",
      videoFileName: "거실_주방_이삿짐.mp4",
      videoUploadedAt: "26.03.25 오후 2:18 업로드",
    },
    {
      id: 2,
      status: "견적 승인",
      name: "김명품",
      date: "25.11.08",
      approvedDate: "25.11.10",
      tone: "blue",
      companyName: "한빛테크",
      videoUrl:
        "https://assets.mixkit.co/videos/2302/2302-360.mp4",
      videoFileName: "대형가구_이동동선.mp4",
      videoUploadedAt: "25.11.08 오전 10:42 업로드",
    },
    { id: 3, status: "견적 확정", name: "이서준", date: "25.04.17", approvedDate: "25.04.19", tone: "green" },
    { id: 4, status: "견적 검토", name: "박서준", date: "24.12.02", tone: "red" },
    { id: 5, status: "견적 승인", name: "최유진", date: "24.06.21", approvedDate: "24.06.24", tone: "blue", companyName: "세림물류" },
    { id: 6, status: "견적 확정", name: "정도현", date: "23.09.14", approvedDate: "23.09.16", tone: "green" },
    { id: 7, status: "견적 검토", name: "한지민", date: "23.02.28", tone: "red" },
    { id: 8, status: "견적 승인", name: "윤서아", date: "22.10.05", approvedDate: "22.10.07", tone: "blue", companyName: "더블유컴퍼니" },
    { id: 9, status: "견적 확정", name: "강민준", date: "22.01.19", approvedDate: "22.01.21", tone: "green" },
    { id: 10, status: "견적 검토", name: "송하윤", date: "21.07.30", tone: "red" },
    { id: 11, status: "견적 승인", name: "임지호", date: "21.03.12", approvedDate: "21.03.15", tone: "blue", companyName: "미래오피스" },
  ])
  const [page, setPage] = useState<
    | "home"
    | "estimateManagement"
    | "estimateBoard"
    | "estimate"
    | "reviewManagement"
    | "memberManagement"
    | "reservationManagement"
    | "scheduleCalendar"
    | "scheduleManagement"
    | "chatManagement"
    | "chatSettings"
    | "chatEntrySettings"
    | "chatAnswerSettings"
    | "notificationManagement"
    | "notificationHistory"
    | "notificationMessagingSettings"
    | "chat"
    | "chatDetail"
  >("home")
  const [selectedChatId, setSelectedChatId] = useState("luxury")
  const [chatListFilter, setChatListFilter] = useState<"all" | "waiting" | "unread">("all")
  const [chatDetailBackTo, setChatDetailBackTo] = useState<"chat" | "chatManagement" | "notificationHistory">("chat")
  const [selectedChatAutomatedMessage, setSelectedChatAutomatedMessage] =
    useState<string | undefined>()
  const [messagingSettings, setMessagingSettings] = useState<MessagingSettings>(
    {
      enabled: true,
      quietHoursEnabled: true,
      quietStart: "22:00",
      quietEnd: "08:00",
      smsFallbackEnabled: true,
    },
  )
  const [messagingRoutines, setMessagingRoutines] = useState<
    MessagingRoutine[]
  >([
    {
      id: 1,
      title: "예약 승인 시 자동 안내",
      enabled: true,
      conditions: ["예약 관리 · 예약 확정"],
      actions: [
        {
          id: 101,
          recipient: "고객",
          message:
            "안녕하세요 @회원 님, 요청하신 이사 예약이 확정되었습니다.",
        },
      ],
    },
    {
      id: 2,
      title: "견적서 등록 완료 알림",
      enabled: true,
      conditions: ["견적서 등록 · 견적서를 등록했을 시"],
      actions: [
        {
          id: 201,
          recipient: "고객",
          message:
            "@회원 님의 신규 견적서가 등록되었습니다. 내용을 확인해 주세요.",
        },
      ],
    },
    {
      id: 3,
      title: "신규 회원 가입 관리자 알림",
      enabled: false,
      conditions: ["회원 관리 · 신규 회원이 가입되었을 시"],
      actions: [
        {
          id: 301,
          recipient: "관리자 본인",
          message: "새로운 회원이 가입했습니다. 회원 정보를 확인해 주세요.",
        },
      ],
    },
  ])
  const [chatSettings, setChatSettings] = useState<ChatSettings>({
    enabled: true,
    operatingHoursEnabled: true,
    startTime: "09:00",
    endTime: "18:00",
    fallbackMessage:
      "현재 상담원 연결이 지연되고 있습니다. 조금만 기다려주세요.",
  })
  const [chatGreeting, setChatGreeting] = useState(
    "안녕하세요! 명품익스프레스 AI 상담 챗봇입니다. 이사와 관련해 궁금한 내용을 편하게 물어보세요.",
  )
  const [answerTopics, setAnswerTopics] = useState<AnswerTopic[]>([
    {
      id: 1,
      title: "이사 견적",
      introduction: "이사 비용과 방문 견적 과정을 안내합니다.",
      lorebooks: [
        {
          id: 101,
          keywords: "#견적#비용#가격",
          content:
            "출발지와 도착지, 이사 날짜, 짐의 양을 알려주시면 예상 견적을 안내해 드립니다.",
        },
      ],
    },
    {
      id: 2,
      title: "예약 방법",
      introduction: "상담부터 예약 확정까지의 절차를 안내합니다.",
      lorebooks: [
        {
          id: 201,
          keywords: "#예약#신청#계약",
          content: "견적 확인 후 예약금을 결제하면 이사 일정이 최종 확정됩니다.",
        },
      ],
    },
    {
      id: 3,
      title: "포장 이사",
      introduction: "포장 서비스 범위와 준비 사항을 확인합니다.",
      lorebooks: [
        {
          id: 301,
          keywords: "#포장#박스#정리",
          content:
            "포장 이사는 전문 인력이 포장부터 운반, 기본 정리까지 진행합니다.",
        },
      ],
    },
    {
      id: 4,
      title: "사다리차 이용",
      introduction: "사다리차 필요 여부와 추가 비용을 안내합니다.",
      lorebooks: [
        {
          id: 401,
          keywords: "#사다리차#엘리베이터#고층",
          content:
            "현장 층수와 작업 환경에 따라 사다리차 필요 여부 및 비용이 달라집니다.",
        },
      ],
    },
  ])
  const [quickMenus, setQuickMenus] = useState<QuickMenuItem[]>([
    {
      id: "topic-1",
      title: "이사 견적",
      description: "이사 비용과 방문 견적 과정을 안내합니다.",
    },
    {
      id: "topic-2",
      title: "예약 방법",
      description: "상담부터 예약 확정까지의 절차를 안내합니다.",
    },
  ])
  const [routineToast, setRoutineToast] = useState<RoutineToast | null>(null)
  const routineToastTimer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const toastPointerStart = useRef<number | null>(null)

  const conditionToTarget = (conditionKey: string): NotificationItem["target"] => {
    if (conditionKey.startsWith("예약 관리")) return "reservationManagement"
    if (conditionKey.startsWith("견적 관리")) return "estimateManagement"
    if (conditionKey.startsWith("견적서 등록")) return "estimateManagement"
    if (conditionKey.startsWith("회원 관리")) return "memberManagement"
    if (conditionKey.startsWith("일정 관리")) return "scheduleCalendar"
    if (conditionKey.startsWith("리뷰 관리")) return "reservationManagement"
    return "reservationManagement"
  }

  const conditionToIcon = (conditionKey: string): IconName => {
    if (conditionKey.startsWith("예약 관리")) return "calendar"
    if (conditionKey.startsWith("견적 관리") || conditionKey.startsWith("견적서 등록")) return "document"
    if (conditionKey.startsWith("회원 관리")) return "user"
    if (conditionKey.startsWith("일정 관리")) return "calendar"
    if (conditionKey.startsWith("리뷰 관리")) return "star"
    return "bell"
  }

  const dismissToast = () => {
    if (routineToastTimer.current) clearTimeout(routineToastTimer.current)
    setRoutineToast(null)
  }

  const fireRoutines = (conditionKey: string) => {
    if (!messagingSettings.enabled) return
    const matched = messagingRoutines.filter(
      (r) => r.enabled && r.conditions.some((c) => {
        if (c === conditionKey) return true
        if (c.startsWith("일정 관리 · 특정 날짜 선택했을 시") && conditionKey === "일정 관리 · 특정 날짜 선택했을 시") return true
        if (c.startsWith("일정 관리 · 특정 요일 선택했을 시") && conditionKey === "일정 관리 · 특정 요일 선택했을 시") return true
        return false
      }),
    )
    if (!matched.length) return

    const now = Date.now()
    matched.forEach((routine) => {
      const messageText = routine.actions.map((a) => a.message).join(" / ")
      const target = conditionToTarget(conditionKey)
      const icon = conditionToIcon(conditionKey)
      const newItem: NotificationItem = {
        id: now + Math.random(),
        category: routine.title,
        message: messageText,
        createdAt: now,
        icon,
        important: true,
        target,
      }
      setRuntimeNotifications((current) => [newItem, ...current])
      setHasUnreadNotifications(true)
    })

    const first = matched[0]
    const messageText = first.actions.map((a) => a.message).join(" / ")
    const target = conditionToTarget(conditionKey)
    if (routineToastTimer.current) clearTimeout(routineToastTimer.current)
    setRoutineToast({ title: first.title, message: messageText, target, swipeX: 0, dismissing: false })
    routineToastTimer.current = setTimeout(() => setRoutineToast(null), 10000)
  }
  useEffect(() => {
    const updateCurrentTime = () => setNotificationNow(Date.now())
    const timer = window.setInterval(updateCurrentTime, 60_000)
    window.addEventListener("focus", updateCurrentTime)
    return () => {
      window.clearInterval(timer)
      window.removeEventListener("focus", updateCurrentTime)
    }
  }, [])
  const recentReservationRecords = [...reservationRecords]
    .sort((a, b) => b.appliedDate.localeCompare(a.appliedDate))
    .slice(0, 3)
  const completedReservationCount = reservationRecords.filter(
    (record) => getReservationDisplayStatus(record.status) === "예약 완료",
  ).length
  const estimateReviewCount = estimateRecords.filter(
    (record) => record.status === "견적 검토",
  ).length
  const globalSearchItems: Array<{
    label: string
    description: string
    icon: IconName
    page: typeof page
  }> = [
    { label: "견적 관리", description: "견적 기록 및 상태 관리", icon: "document", page: "estimateManagement" },
    { label: "견적서 등록", description: "사진 또는 PDF 견적서 등록", icon: "document", page: "estimate" },
    { label: "예약 관리", description: "예약 내역 및 상태 관리", icon: "calendar", page: "reservationManagement" },
    { label: "예약 일정", description: "월간 이사 일정 확인", icon: "calendar", page: "scheduleCalendar" },
    { label: "일정 관리", description: "휴무일 및 예약 불가일 관리", icon: "calendar", page: "scheduleManagement" },
    { label: "리뷰 관리", description: "고객 리뷰와 답변 관리", icon: "star", page: "reviewManagement" },
    { label: "회원 관리", description: "고객 및 관리자 관리", icon: "people", page: "memberManagement" },
    { label: "홈", description: "관리자 대시보드", icon: "home", page: "home" },
  ]
  const normalizedSearch = globalSearchQuery.trim().replace(/\s/g, "")
  const isInitialSearch =
    normalizedSearch.length > 0 &&
    [...normalizedSearch].every((character) => koreanInitials.includes(character))
  const globalSearchResults = globalSearchItems.filter((item) => {
    if (!normalizedSearch) return true
    const label = item.label.replace(/\s/g, "")
    return isInitialSearch
      ? getKoreanInitials(label).startsWith(normalizedSearch)
      : label.toLowerCase().includes(normalizedSearch.toLowerCase())
  })
  const groupedNotifications = (["최근 7일", "최근 30일"] as const)
    .map((group) => ({
      group,
      items: [...runtimeNotifications]
        .sort((a, b) => b.createdAt - a.createdAt)
        .filter(
          (item) =>
            getNotificationGroup(item.createdAt, notificationNow) === group,
        ),
    }))
    .filter(({ items }) => items.length > 0)
  const adminNotificationHistory: NotificationHistoryRecord[] = runtimeNotifications.map(
    (item) => {
      const member = reservationCustomers.find(
        ([name, id]) => item.message.includes(name) || item.message.includes(id),
      )
      return {
        id: -item.id,
        name: member?.[0] || "관리자",
        message: getNotificationMessage(item, notificationNow),
        time: getRelativeNotificationTime(item.createdAt, notificationNow),
        recipient: "관리자",
        category: item.category,
      }
    },
  )

  return (
    <main className="min-h-screen bg-[#e8ebe8] sm:grid sm:place-items-center sm:p-6">
      <div className="relative mx-auto h-[100dvh] w-full max-w-[430px] overflow-hidden bg-[#f5f6f8] shadow-[0_18px_60px_rgba(39,61,43,.18)] sm:h-[min(874px,calc(100vh-48px))] sm:rounded-[32px]">
        <div className="flex h-full flex-col">
          <header className="z-20 flex h-[68px] shrink-0 items-center justify-between border-b border-[#e9ece9] bg-white px-5">
            <div className="flex items-center gap-2.5">
              <div className="grid h-8 w-8 place-items-center rounded-lg bg-[#346538] text-white">
                <Icon name="truck" size={20} />
              </div>
              <div>
                <p className="text-[9px] font-bold leading-none tracking-[0.14em] text-[#809083]">
                  ADMIN
                </p>
                <h1 className="mt-1 text-[16px] font-extrabold leading-none tracking-[-0.04em] text-[#27372a]">
                  명품익스프레스
                </h1>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <button
                aria-label="메뉴 검색"
                className="grid h-10 w-10 place-items-center rounded-full text-[#465048] transition hover:bg-[#f2f5f2]"
                onClick={() => setGlobalSearchOpen(true)}
                type="button"
              >
                <Icon name="search" size={21} />
              </button>
              <button
                aria-label="최근 알림"
                className="relative grid h-10 w-10 place-items-center rounded-full text-[#465048] transition hover:bg-[#f2f5f2]"
                onClick={() => {
                  setNotificationOpen(true)
                  setHasUnreadNotifications(false)
                }}
                type="button"
              >
                <Icon name="bell" size={21} />
                {hasUnreadNotifications && (
                  <span className="absolute right-2 top-2 h-2 w-2 rounded-full border-2 border-white bg-[#d9824b]" />
                )}
              </button>
            </div>
          </header>

          <div
            className={`min-h-0 flex-1 ${
              page === "chat" ||
              page === "chatDetail" ||
              page === "chatManagement" ||
              page === "chatSettings" ||
              page === "chatEntrySettings" ||
              page === "chatAnswerSettings" ||
              page === "notificationManagement" ||
              page === "notificationHistory" ||
              page === "notificationMessagingSettings" ||
              page === "estimateBoard"
                ? "overflow-hidden pb-[82px]"
                : "overflow-y-auto"
            }`}
          >
            {page === "estimateBoard" ? (
              <EstimateBoard
                onChangeReservations={(id, status) =>
                  setReservationRecords((current) =>
                    current.map((record) =>
                      record.id === id ? { ...record, status } : record,
                    ),
                  )
                }
                onOpenReservations={() => setPage("reservationManagement")}
                reservations={reservationRecords}
              />
            ) : page === "estimate" ? (
              <EstimateRegistration
                onComplete={(estimate) => {
                  setEstimateRecords((current) => [
                    {
                      ...estimate,
                      id: Date.now(),
                      tone:
                        estimate.status === "견적 확정"
                          ? "green"
                          : estimate.status === "견적 승인"
                            ? "blue"
                            : "red",
                      approvedDate:
                        estimate.status === "견적 검토"
                          ? undefined
                          : getTodayShortDate(),
                      documentUrl: estimate.documentUrl || estimateTemplateUrl,
                    },
                    ...current,
                  ])
                  fireRoutines("견적서 등록 · 견적서를 등록했을 시")
                  setPage("estimateManagement")
                }}
              />
            ) : page === "estimateManagement" ? (
              <EstimateManagement
                onFire={fireRoutines}
                onRegister={() => setPage("estimate")}
                onChangeRecords={setEstimateRecords}
                records={estimateRecords}
              />
            ) : page === "reviewManagement" ? (
              <ReviewManagement onFire={fireRoutines} />
            ) : page === "memberManagement" ? (
              <MemberManagement onFire={fireRoutines} onNewMemberCountChange={setNewMemberCount} />
            ) : page === "reservationManagement" ? (
              <ReservationManagement
                estimates={estimateRecords}
                onFire={fireRoutines}
                onChangeRecords={setReservationRecords}
                onSelectedReservationOpened={() => setSelectedReservationId(null)}
                records={reservationRecords}
                selectedReservationId={selectedReservationId}
              />
            ) : page === "scheduleCalendar" ? (
              <ScheduleCalendar
                estimates={estimateRecords}
                managedDateStatuses={managedDateStatuses}
                onOpenReservation={(record) => {
                  setSelectedReservationId(record.id)
                  setPage("reservationManagement")
                }}
                records={reservationRecords}
              />
            ) : page === "scheduleManagement" ? (
              <ScheduleManagement
                onFire={fireRoutines}
                onSave={setManagedDateStatuses}
                records={reservationRecords}
                statuses={managedDateStatuses}
              />
            ) : page === "chatManagement" ? (
              <ChatManagementHome
                onOpenAnswerSettings={() => setPage("chatAnswerSettings")}
                onOpenEntrySettings={() => setPage("chatEntrySettings")}
                onOpenList={() => { setChatListFilter("all"); setChatDetailBackTo("chatManagement"); setPage("chat") }}
                onOpenSettings={() => setPage("chatSettings")}
                onOpenUnreadList={() => { setChatListFilter("unread"); setChatDetailBackTo("chatManagement"); setPage("chat") }}
                onOpenWaitingList={() => { setChatListFilter("waiting"); setChatDetailBackTo("chatManagement"); setPage("chat") }}
              />
            ) : page === "notificationManagement" ? (
              <NotificationManagementHome
                onOpenHistory={() => setPage("notificationHistory")}
                onOpenMessaging={() =>
                  setPage("notificationMessagingSettings")
                }
              />
            ) : page === "notificationMessagingSettings" ? (
              <MessagingOperationsSettings
                onChange={setMessagingSettings}
                onClose={() => setPage("notificationManagement")}
                settings={messagingSettings}
              />
            ) : page === "notificationHistory" ? (
              <NotificationHistory
                adminNotifications={adminNotificationHistory}
                onClose={() => setPage("notificationManagement")}
              />
            ) : page === "chatSettings" ? (
              <ChatOperationsSettings
                onChange={setChatSettings}
                onClose={() => setPage("chatManagement")}
                settings={chatSettings}
              />
            ) : page === "chatEntrySettings" ? (
              <ChatEntrySettings
                answerTopics={answerTopics}
                greeting={chatGreeting}
                onChangeGreeting={setChatGreeting}
                onChangeQuickMenus={setQuickMenus}
                onClose={() => setPage("chatManagement")}
                quickMenus={quickMenus}
              />
            ) : page === "chatAnswerSettings" ? (
              <ChatAnswerSettings
                onChangeTopics={setAnswerTopics}
                onClose={() => setPage("chatManagement")}
                topics={answerTopics}
              />
            ) : page === "chat" ? (
              <ChatList
                initialFilter={chatListFilter}
                onBack={chatDetailBackTo === "chatManagement" ? () => { setChatDetailBackTo("chat"); setPage("chatManagement") } : undefined}
                onSelectChat={(id) => {
                  setSelectedChatId(id)
                  setSelectedChatAutomatedMessage(undefined)
                  setPage("chatDetail")
                }}
              />
            ) : page === "chatDetail" ? (
              <ChatDetail
                automatedMessage={selectedChatAutomatedMessage}
                backTo={chatDetailBackTo}
                chatId={selectedChatId}
                onBack={() => {
                  setSelectedChatAutomatedMessage(undefined)
                  if (selectedChatAutomatedMessage) {
                    setPage("notificationHistory")
                  } else {
                    setPage(chatDetailBackTo)
                    if (chatDetailBackTo !== "chatManagement") setChatDetailBackTo("chat")
                  }
                }}
              />
            ) : (
              <div className="space-y-5 px-4 pb-28 pt-5">
              <section className="grid grid-cols-2 gap-3">
                {stats.map((stat) => (
                  <button
                    className="rounded-[18px] border border-white bg-white p-4 text-left shadow-[0_5px_18px_rgba(36,58,39,.07)] transition enabled:hover:-translate-y-0.5 enabled:hover:shadow-[0_8px_22px_rgba(36,58,39,.11)] disabled:cursor-default"
                    disabled={
                      stat.label !== "리뷰 등록 현황" &&
                      stat.label !== "견적 검토" &&
                      stat.label !== "전체 예약 신청" &&
                      stat.label !== "예약 완료"
                    }
                    key={stat.label}
                    onClick={() =>
                      setPage(
                        stat.label === "견적 검토"
                          ? "estimateManagement"
                          : stat.label === "리뷰 등록 현황"
                            ? "reviewManagement"
                            : "reservationManagement",
                      )
                    }
                    type="button"
                  >
                    <div className="mb-5 flex items-center justify-between">
                      <span className="text-[12px] font-semibold text-[#6d746f]">
                        {stat.label}
                      </span>
                      <span className="grid h-8 w-8 place-items-center rounded-xl bg-[#edf3ed] text-[#346538]">
                        <Icon name={stat.icon} size={17} />
                      </span>
                    </div>
                    <p className="flex items-baseline gap-1">
                      <strong className="text-[27px] font-extrabold tracking-[-0.04em] text-[#222a24]">
                        {stat.label === "견적 검토"
                          ? estimateReviewCount
                          : stat.label === "전체 예약 신청"
                            ? reservationRecords.length
                            : stat.label === "예약 완료"
                              ? completedReservationCount
                              : stat.value}
                      </strong>
                      <span className="text-[12px] font-medium text-[#919792]">
                        {stat.unit}
                      </span>
                    </p>
                  </button>
                ))}
              </section>

              <section
                className="cursor-pointer rounded-[20px] bg-white p-5 shadow-[0_5px_18px_rgba(36,58,39,.06)]"
                onClick={() => setPage("reservationManagement")}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-[16px] font-bold text-[#222a24]">
                      주간 예약 현황
                    </h3>
                    <p className="mt-1 text-[11px] text-[#959b96]">
                      이번 주 접수된 예약은 총 10건입니다
                    </p>
                  </div>
                  <span className="rounded-lg bg-[#edf3ed] px-2.5 py-1.5 text-[10px] font-bold text-[#346538]">
                    이번 주
                  </span>
                </div>
                <div className="mt-5">
                  <svg
                    aria-label="주간 예약 건수 선 그래프"
                    className="h-[130px] w-full"
                    viewBox="0 0 340 130"
                  >
                    {[18, 53, 88].map((y) => (
                      <line
                        key={y}
                        stroke="#edf0ed"
                        strokeDasharray="3 5"
                        x1="8"
                        x2="332"
                        y1={y}
                        y2={y}
                      />
                    ))}
                    <path
                      d="M10 91 C32 86 40 68 63 70 S91 39 116 48 S145 72 169 65 S198 32 222 37 S249 68 276 57 S307 21 330 27"
                      fill="none"
                      stroke="#346538"
                      strokeLinecap="round"
                      strokeWidth="3"
                    />
                    <path
                      d="M10 91 C32 86 40 68 63 70 S91 39 116 48 S145 72 169 65 S198 32 222 37 S249 68 276 57 S307 21 330 27 L330 106 L10 106Z"
                      fill="url(#chartFill)"
                    />
                    <defs>
                      <linearGradient
                        id="chartFill"
                        x1="0"
                        x2="0"
                        y1="0"
                        y2="1"
                      >
                        <stop
                          offset="0%"
                          stopColor="#346538"
                          stopOpacity=".18"
                        />
                        <stop
                          offset="100%"
                          stopColor="#346538"
                          stopOpacity="0"
                        />
                      </linearGradient>
                    </defs>
                    {[
                      ["10", "91"],
                      ["63", "70"],
                      ["116", "48"],
                      ["169", "65"],
                      ["222", "37"],
                      ["276", "57"],
                      ["330", "27"],
                    ].map(([cx, cy]) => (
                      <circle
                        cx={cx}
                        cy={cy}
                        fill="white"
                        key={cx}
                        r="4"
                        stroke="#346538"
                        strokeWidth="2.5"
                      />
                    ))}
                  </svg>
                  <div className="-mt-3 grid grid-cols-7 text-center text-[10px] font-medium text-[#969c97]">
                    {["월", "화", "수", "목", "금", "토", "일"].map((day) => (
                      <span key={day}>{day}</span>
                    ))}
                  </div>
                </div>
              </section>

              <section
                className="cursor-pointer rounded-[20px] bg-white p-5 shadow-[0_5px_18px_rgba(36,58,39,.06)]"
                onClick={() => setPage("reservationManagement")}
              >
                <div className="mb-1 flex items-center justify-between">
                  <h3 className="text-[16px] font-bold text-[#222a24]">
                    최근 예약 내역
                  </h3>
                  <button
                    className="text-[11px] font-bold text-[#346538]"
                    type="button"
                  >
                    전체보기
                  </button>
                </div>
                <div>
                  {recentReservationRecords.map((item) => (
                    <article
                      className="border-b border-[#eef0ee] py-4 last:border-none last:pb-0"
                      key={item.name}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex min-w-0 items-start gap-3">
                          <div className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-[#edf3ed] text-[12px] font-bold text-[#346538]">
                            {item.name[0]}
                          </div>
                          <div className="min-w-0">
                            <p className="text-[13px] font-bold text-[#2e3530]">
                              {item.name}
                              <span className="ml-2 font-normal text-[#a0a5a1]">
                                {item.movingDate}
                              </span>
                            </p>
                            <p className="mt-1 truncate text-[11px] text-[#7d847f]">
                              {item.origin} → {item.destination}
                            </p>
                          </div>
                        </div>
                        <span className="shrink-0 rounded-full bg-[#f1f5f1] px-2.5 py-1 text-[10px] font-semibold text-[#346538]">
                          {getReservationDisplayStatus(item.status)}
                        </span>
                      </div>
                    </article>
                  ))}
                </div>
              </section>

              </div>
            )}
          </div>
          <nav className="absolute inset-x-0 bottom-0 z-30 grid h-[82px] grid-cols-5 border-t border-[#e7ebe7] bg-white/95 px-2 pb-[max(8px,env(safe-area-inset-bottom))] pt-2 backdrop-blur-md">
            {[
              ["예약일정", "calendar"],
              ["견적", "document"],
              ["홈", "home"],
              ["챗봇", "chat"],
              ["전체", "menu"],
            ].map(([label, icon]) => {
              const isActive =
                (label === "홈" && page === "home") ||
                (label === "예약일정" && page === "scheduleCalendar") ||
                (label === "견적" && page === "estimateManagement") ||
                (label === "챗봇" &&
                  (page === "chat" ||
                    page === "chatDetail"))
              return (
                <button
                  aria-label={label}
                  className={`flex flex-col items-center justify-start gap-1 text-[10px] font-semibold ${
                    isActive ? "text-[#346538]" : "text-[#899089]"
                  }`}
                  key={label}
                  onClick={
                    label === "전체"
                      ? () => setDrawerOpen(true)
                      : label === "홈"
                        ? () => setPage("home")
                        : label === "예약일정"
                          ? () => setPage("scheduleCalendar")
                        : label === "견적"
                          ? () => setPage("estimateManagement")
                        : label === "챗봇"
                          ? () => {
                              setSelectedChatAutomatedMessage(undefined)
                              setChatDetailBackTo("chat")
                              setPage("chat")
                            }
                        : undefined
                  }
                  type="button"
                >
                  <span
                    className={`grid h-9 w-11 place-items-center rounded-2xl ${
                      isActive ? "bg-[#eaf1ea]" : ""
                    }`}
                  >
                    <Icon name={icon as IconName} size={20} />
                  </span>
                  {label}
                </button>
              )
            })}
          </nav>
        </div>
        {notificationOpen && (
          <div
            aria-modal="true"
            className="absolute inset-0 z-[90] grid place-items-center bg-[#1f2d21]/50 p-4 backdrop-blur-[2px]"
            role="dialog"
          >
            <div className="flex max-h-[calc(100%-32px)] w-full flex-col overflow-hidden rounded-[24px] bg-white shadow-[0_24px_70px_rgba(21,37,24,.3)]">
              <header className="relative flex h-14 shrink-0 items-center justify-center border-b border-[#e9ece9] px-4">
                <h2 className="text-[17px] font-extrabold text-[#29322b]">
                  알림
                </h2>
                <button
                  aria-label="알림 닫기"
                  className="absolute right-3 grid h-9 w-9 place-items-center rounded-full text-[#59625b] hover:bg-[#f2f5f2]"
                  onClick={() => setNotificationOpen(false)}
                  type="button"
                >
                  <Icon name="x" size={19} />
                </button>
              </header>
              <div className="flex-1 overflow-y-auto bg-[#f7f8f7] p-4">
                {groupedNotifications.map(({ group, items }) => (
                  <section className="mb-6 last:mb-0" key={group}>
                    <div className="mb-3 flex items-center gap-3">
                      <h3 className="shrink-0 text-[12px] font-extrabold text-[#59625b]">
                        {group}
                      </h3>
                      <span className="h-px flex-1 bg-[#dfe4df]" />
                    </div>
                    <div className="space-y-2.5">
                      {items.map((item) => (
                          <button
                            className={`relative flex w-full items-start gap-3 overflow-hidden rounded-2xl border bg-white p-3.5 text-left shadow-[0_3px_12px_rgba(36,58,39,.04)] transition active:scale-[.99] ${
                              item.important
                                ? "border-[#efcfca]"
                                : "border-[#edf0ed]"
                            }`}
                            key={item.id}
                            onClick={() => {
                              if (item.chatId) {
                                setSelectedChatId(item.chatId)
                                setSelectedChatAutomatedMessage(undefined)
                                setPage("chatDetail")
                              } else {
                                setPage(item.target)
                              }
                              setNotificationOpen(false)
                            }}
                            type="button"
                          >
                            {item.important && (
                              <span className="absolute inset-y-0 left-0 w-1 bg-[#cf5b51]" />
                            )}
                            <span
                              className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl ${
                                item.important
                                  ? "bg-[#fff0ee] text-[#b64b42]"
                                  : "bg-[#edf3ed] text-[#346538]"
                              }`}
                            >
                              <Icon name={item.icon} size={18} />
                            </span>
                            <span className="min-w-0 flex-1">
                              <span className="flex items-start justify-between gap-2">
                                <strong
                                  className={`text-[12px] ${
                                    item.important
                                      ? "text-[#a8443c]"
                                      : "text-[#343c36]"
                                  }`}
                                >
                                  [{item.category}]
                                </strong>
                                <span className="shrink-0 text-[9px] font-medium text-[#9aa09b]">
                                  {getRelativeNotificationTime(
                                    item.createdAt,
                                    notificationNow,
                                  )}
                                </span>
                              </span>
                              <span className="mt-1.5 block text-[11px] leading-[1.55] text-[#646c66]">
                                {getNotificationMessage(item, notificationNow)}
                              </span>
                            </span>
                          </button>
                        ))}
                    </div>
                  </section>
                ))}
                {!groupedNotifications.length && (
                  <div className="py-20 text-center">
                    <span className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-white text-[#9aa19b]">
                      <Icon name="bell" size={21} />
                    </span>
                    <p className="mt-3 text-xs font-semibold text-[#737b75]">
                      최근 30일 알림이 없습니다.
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
        {globalSearchOpen && (
          <div className="absolute inset-0 z-[80] bg-[#f5f6f8]">
            <div className="flex h-[68px] items-center gap-2 border-b border-[#e2e6e2] bg-white px-4">
              <label className="relative flex-1">
                <Icon
                  className="absolute left-3 top-3 text-[#7d857f]"
                  name="search"
                  size={18}
                />
                <input
                  autoFocus
                  className="h-11 w-full rounded-[14px] bg-[#f2f3f5] pl-10 pr-4 text-[12px] font-medium text-[#353d37] outline-none placeholder:text-[#9ca29d] focus:ring-1 focus:ring-[#89a18b]"
                  onChange={(event) => setGlobalSearchQuery(event.target.value)}
                  placeholder="검색어를 입력하세요"
                  value={globalSearchQuery}
                />
              </label>
              <button
                aria-label="통합 검색 닫기"
                className="grid h-10 w-10 shrink-0 place-items-center rounded-full text-[#59625b] hover:bg-[#f2f5f2]"
                onClick={() => {
                  setGlobalSearchOpen(false)
                  setGlobalSearchQuery("")
                }}
                type="button"
              >
                <Icon name="x" size={20} />
              </button>
            </div>
            <div className="h-[calc(100%-68px)] overflow-y-auto px-4 pb-8 pt-5">
              <div className="mb-3 flex items-center justify-between px-1">
                <h2 className="text-[14px] font-extrabold text-[#29312b]">
                  전체 메뉴 조회
                </h2>
                {globalSearchQuery && (
                  <span className="text-[9px] font-semibold text-[#8b928d]">
                    {globalSearchResults.length}개 결과
                  </span>
                )}
              </div>
              <div className="overflow-hidden rounded-[18px] bg-white shadow-[0_5px_18px_rgba(36,58,39,.06)]">
                {globalSearchResults.map((item) => (
                  <button
                    className="flex w-full items-center gap-3 border-b border-[#edf0ed] px-4 py-4 text-left last:border-none hover:bg-[#f7f9f7]"
                    key={item.label}
                    onClick={() => {
                      setPage(item.page)
                      setGlobalSearchOpen(false)
                      setGlobalSearchQuery("")
                    }}
                    type="button"
                  >
                    <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#edf3ed] text-[#346538]">
                      <Icon name={item.icon} size={19} />
                    </span>
                    <span className="min-w-0 flex-1">
                      <strong className="block text-[12px] text-[#353d37]">
                        {item.label}
                      </strong>
                      <small className="mt-1 block text-[9px] text-[#8c938e]">
                        {item.description}
                      </small>
                    </span>
                    <Icon
                      className="-rotate-90 text-[#a0a6a1]"
                      name="chevron"
                      size={16}
                    />
                  </button>
                ))}
                {!globalSearchResults.length && (
                  <div className="py-16 text-center">
                    <Icon
                      className="mx-auto text-[#a3aaa4]"
                      name="search"
                      size={27}
                    />
                    <p className="mt-3 text-[11px] font-bold text-[#747c76]">
                      일치하는 메뉴가 없습니다.
                    </p>
                  </div>
                )}
              </div>
              {!globalSearchQuery && (
                <p className="mt-4 px-1 text-[9px] leading-4 text-[#969d98]">
                  메뉴 이름을 직접 입력하거나 초성으로 검색할 수 있습니다.
                </p>
              )}
            </div>
          </div>
        )}
        <Drawer
          onClose={() => setDrawerOpen(false)}
          onLogout={() => {
            setDrawerOpen(false)
            setPage("home")
          }}
          onOpenEstimateManagement={() => {
            setPage("estimateManagement")
            setDrawerOpen(false)
          }}
          onOpenEstimate={() => {
            setPage("estimate")
            setDrawerOpen(false)
          }}
          onOpenReviewManagement={() => {
            setPage("reviewManagement")
            setDrawerOpen(false)
          }}
          onOpenMemberManagement={() => {
            setPage("memberManagement")
            setDrawerOpen(false)
          }}
          onOpenReservationManagement={() => {
            setPage("reservationManagement")
            setDrawerOpen(false)
          }}
          onOpenScheduleManagement={() => {
            setPage("scheduleManagement")
            setDrawerOpen(false)
          }}
          onOpenChatManagement={() => {
            setPage("chatManagement")
            setDrawerOpen(false)
          }}
          onOpenNotificationManagement={() => {
            setPage("notificationManagement")
            setDrawerOpen(false)
          }}
          open={drawerOpen}
        />
        {routineToast && (
          <div className="absolute inset-x-0 top-0 z-[300] flex justify-center px-3 pt-3">
            <button
              className="w-full max-w-[410px] cursor-pointer rounded-[20px] bg-white px-4 py-3.5 text-left shadow-[0_8px_32px_rgba(36,58,39,.22)] transition-transform"
              onClick={() => {
                dismissToast()
                setPage(routineToast.target)
              }}
              onPointerDown={(e) => { toastPointerStart.current = e.clientX }}
              onPointerMove={(e) => {
                if (toastPointerStart.current === null) return
                const dx = Math.max(0, e.clientX - toastPointerStart.current)
                setRoutineToast((t) => t ? { ...t, swipeX: dx } : t)
              }}
              onPointerUp={(e) => {
                if (toastPointerStart.current === null) return
                const dx = e.clientX - toastPointerStart.current
                toastPointerStart.current = null
                if (dx > 80) { dismissToast() } else { setRoutineToast((t) => t ? { ...t, swipeX: 0 } : t) }
              }}
              onPointerCancel={() => { toastPointerStart.current = null; setRoutineToast((t) => t ? { ...t, swipeX: 0 } : t) }}
              style={{
                animation: "slideDown 0.35s cubic-bezier(0.22,1,0.36,1)",
                transform: routineToast.swipeX > 0 ? `translateX(${routineToast.swipeX}px)` : undefined,
                opacity: routineToast.swipeX > 0 ? Math.max(0, 1 - routineToast.swipeX / 160) : undefined,
              }}
              type="button"
            >
              <div className="flex items-center gap-3">
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-[#346538] text-white">
                  <Icon name="bell" size={18} />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-baseline justify-between gap-2">
                    <p className="truncate text-[13px] font-extrabold text-[#1e2a1f]">{routineToast.title}</p>
                    <span className="shrink-0 text-[10px] text-[#9aa09b]">
                      {new Date().toLocaleTimeString("ko-KR", { hour: "numeric", minute: "2-digit", hour12: true })}
                    </span>
                  </div>
                  <p className="mt-0.5 line-clamp-2 text-[11px] leading-[1.5] text-[#5a625c]">{routineToast.message}</p>
                </div>
              </div>
            </button>
          </div>
        )}
      </div>
    </main>
  )
}

export default App
