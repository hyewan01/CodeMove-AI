import { useRef, useState, type TouchEvent } from "react"
import { Icon } from "./Icon"

type Tab = "requests" | "progress" | "confirmed"

export type EstimateBoardReservation = {
  id: number
  name: string
  status:
    | "승인 대기"
    | "반려"
    | "예약 확정"
    | "견적 협의"
    | "견적 확정"
    | "이사 완료"
  appliedDate: string
  phone: string
  service: string
  movingDate: string
  consultationTime: string
  origin: string
  destination: string
  ladder: string
  elevator: string
  volume: string
  items: string
  memo: string
}

type ProgressEstimate = {
  id: number
  name: string
  amount: number
  status: "waiting" | "rejected"
  updatedAt: string
  reason?: string
}

type ConfirmedEstimate = {
  id: number
  name: string
  amount: number
  confirmedAt: string
  payment: string
}

const initialProgress: ProgressEstimate[] = [
  {
    id: 11,
    name: "김명품",
    amount: 1_200_000,
    status: "waiting",
    updatedAt: "어제 오후 2:00 발송",
  },
  {
    id: 12,
    name: "강민주",
    amount: 1_350_000,
    status: "rejected",
    updatedAt: "방금 전 반려됨",
    reason: "예산(100만 원) 초과 및 사다리차 비용 부담",
  },
  {
    id: 13,
    name: "윤아름",
    amount: 870_000,
    status: "waiting",
    updatedAt: "오늘 오전 9:20 발송",
  },
]

const initialConfirmed: ConfirmedEstimate[] = [
  {
    id: 21,
    name: "이서준",
    amount: 1_450_000,
    confirmedAt: "오늘 오전 11:40",
    payment: "계약금 10% 입금 완료",
  },
  {
    id: 22,
    name: "박철수",
    amount: 980_000,
    confirmedAt: "어제 오후 4:15",
    payment: "계약금 10% 입금 완료",
  },
]

const transferredEstimateIds = new Set<number>()

const tabOrder: Tab[] = ["requests", "progress", "confirmed"]

const tabLabels: Record<Tab, string> = {
  requests: "이사 요청 조회",
  progress: "견적 승인/반려",
  confirmed: "견적서 확인",
}

const reservationStatusOptions = [
  "반려",
  "승인 대기",
  "이사 완료",
  "예약 확정",
  "견적 협의",
  "견적 확정",
]

function formatCurrency(amount: number) {
  return `${amount.toLocaleString("ko-KR")}원`
}

export default function EstimateBoard({
  onChangeReservations,
  onOpenReservations,
  reservations = [],
}: {
  onChangeReservations: (
    id: number,
    status: EstimateBoardReservation["status"],
  ) => void
  onOpenReservations: () => void
  reservations?: EstimateBoardReservation[]
}) {
  const [activeTab, setActiveTab] = useState<Tab>("requests")
  const [progress, setProgress] = useState(initialProgress)
  const [confirmed, setConfirmed] = useState(() =>
    initialConfirmed.filter(
      (estimate) => !transferredEstimateIds.has(estimate.id),
    ),
  )
  const [quoteRequest, setQuoteRequest] =
    useState<EstimateBoardReservation | null>(null)
  const [requote, setRequote] = useState<ProgressEstimate | null>(null)
  const [amount, setAmount] = useState("")
  const [memo, setMemo] = useState("")
  const [reservationStatus, setReservationStatus] = useState("승인 대기")
  const [rejectionReason, setRejectionReason] = useState("")
  const [customerMessage, setCustomerMessage] = useState("")
  const [adminMemo, setAdminMemo] = useState("")
  const [viewer, setViewer] = useState<
    ProgressEstimate | ConfirmedEstimate | null
  >(null)
  const [bookingTarget, setBookingTarget] =
    useState<ConfirmedEstimate | null>(null)
  const touchStartX = useRef(0)
  const requests = reservations
    .filter((record) => record.status === "승인 대기")
    .sort((a, b) => b.appliedDate.localeCompare(a.appliedDate))

  const changeTabBySwipe = (endX: number) => {
    const distance = touchStartX.current - endX
    if (Math.abs(distance) < 45) return
    const currentIndex = tabOrder.indexOf(activeTab)
    const nextIndex =
      distance > 0
        ? Math.min(tabOrder.length - 1, currentIndex + 1)
        : Math.max(0, currentIndex - 1)
    setActiveTab(tabOrder[nextIndex])
  }

  const openQuoteForm = (request: EstimateBoardReservation) => {
    setQuoteRequest(request)
    setRequote(null)
    setReservationStatus(request.status)
    setRejectionReason("")
    setCustomerMessage("")
    setAdminMemo("")
  }

  const openRequoteForm = (estimate: ProgressEstimate) => {
    setQuoteRequest(null)
    setRequote(estimate)
    setAmount(String(estimate.amount))
    setMemo(estimate.reason ?? "")
  }

  const closeQuoteForm = () => {
    setQuoteRequest(null)
    setRequote(null)
  }

  const submitQuote = () => {
    if (quoteRequest) {
      onChangeReservations(
        quoteRequest.id,
        reservationStatus as EstimateBoardReservation["status"],
      )
    } else if (requote) {
      const numericAmount = Number(amount)
      if (!numericAmount) return
      setProgress((current) =>
        current.map((estimate) =>
          estimate.id === requote.id
            ? {
                ...estimate,
                amount: numericAmount,
                status: "waiting",
                updatedAt: "방금 전 재발송",
                reason: undefined,
              }
            : estimate,
        ),
      )
    }
    closeQuoteForm()
  }

  return (
    <div className="relative flex h-full min-h-0 flex-col overflow-hidden bg-[#f5f6f8]">
      <div className="shrink-0 bg-white px-4 pt-5">
        <h1 className="text-xl font-extrabold tracking-[-0.04em] text-[#346538]">
          견적
        </h1>
        <div className="mt-4 grid grid-cols-3">
          {tabOrder.map((tab) => (
            <button
              className={`relative min-w-0 px-1 pb-3 text-[11px] transition ${
                activeTab === tab
                  ? "font-extrabold text-[#346538]"
                  : "font-semibold text-[#9aa19b]"
              }`}
              key={tab}
              onClick={() => setActiveTab(tab)}
              type="button"
            >
              {tabLabels[tab]}
              {activeTab === tab && (
                <span className="absolute inset-x-2 bottom-0 h-1 rounded-full bg-[#346538]" />
              )}
            </button>
          ))}
        </div>
      </div>

      <div
        className="flex-1 overflow-y-auto p-4"
        onTouchEnd={(event: TouchEvent<HTMLDivElement>) =>
          changeTabBySwipe(event.changedTouches[0].clientX)
        }
        onTouchStart={(event: TouchEvent<HTMLDivElement>) => {
          touchStartX.current = event.touches[0].clientX
        }}
      >
        {activeTab === "requests" && (
          <div className="space-y-3">
            <div className="flex items-center justify-between px-1">
              <p className="text-xs font-bold text-[#59625b]">
                신규 접수 대기
              </p>
              <span className="rounded-full bg-[#fff0ee] px-2.5 py-1 text-[10px] font-extrabold text-[#ba5047]">
                {requests.length}건
              </span>
            </div>
            {requests.map((request) => (
              <article
                className="rounded-[20px] bg-white p-4 shadow-[0_5px_18px_rgba(36,58,39,.07)]"
                key={request.id}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="flex items-center gap-1.5 rounded-full bg-[#fff0ee] px-2.5 py-1 text-[10px] font-extrabold text-[#b64b42]">
                    <Icon name="alert" size={12} />
                    신규 요청
                  </span>
                  <span className="text-[10px] font-medium text-[#9aa09b]">
                    {request.appliedDate} 접수
                  </span>
                </div>
                <div className="mt-4">
                  <h2 className="text-[15px] font-extrabold text-[#303832]">
                    {request.name} 고객님
                    <span className="ml-2 text-[11px] font-semibold text-[#7f8881]">
                      ({request.service})
                    </span>
                  </h2>
                  <dl className="mt-3 space-y-2 text-xs">
                    <div className="flex gap-3">
                      <dt className="w-20 shrink-0 font-semibold text-[#8a918c]">
                        희망 이사일
                      </dt>
                      <dd className="font-bold text-[#4a524c]">
                        {request.movingDate}
                      </dd>
                    </div>
                    <div className="flex gap-3">
                      <dt className="w-20 shrink-0 font-semibold text-[#8a918c]">
                        이동 경로
                      </dt>
                      <dd className="min-w-0 font-medium leading-5 text-[#4a524c]">
                        {request.origin}
                        <Icon
                          className="mx-1 inline text-[#8fa091]"
                          name="arrowRight"
                          size={12}
                        />
                        {request.destination}
                      </dd>
                    </div>
                  </dl>
                </div>
                <button
                  className="mt-4 h-11 w-full rounded-xl bg-[#346538] text-xs font-extrabold text-white"
                  onClick={() => openQuoteForm(request)}
                  type="button"
                >
                  승인 상태 변경
                </button>
              </article>
            ))}
            {!requests.length && (
              <EmptyState message="새롭게 접수된 이사 요청이 없습니다." />
            )}
          </div>
        )}

        {activeTab === "progress" && (
          <div className="space-y-3">
            <div className="flex items-center justify-between px-1">
              <p className="text-xs font-bold text-[#59625b]">진행 및 조율 중</p>
              <span className="text-[10px] font-semibold text-[#8d958f]">
                최신 발송순
              </span>
            </div>
            {progress.map((estimate) => (
              <article
                className="rounded-[20px] bg-white p-4 shadow-[0_5px_18px_rgba(36,58,39,.07)]"
                key={estimate.id}
              >
                <div className="flex items-center justify-between gap-2">
                  <span
                    className={`flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-extrabold ${
                      estimate.status === "waiting"
                        ? "bg-[#fff5df] text-[#9b7127]"
                        : "bg-[#f0f1f0] text-[#6f7771]"
                    }`}
                  >
                    <Icon
                      name={estimate.status === "waiting" ? "clock" : "x"}
                      size={12}
                    />
                    {estimate.status === "waiting"
                      ? "고객 확인 중"
                      : "고객 반려"}
                  </span>
                  <span className="text-[10px] text-[#9aa09b]">
                    {estimate.updatedAt}
                  </span>
                </div>
                <div className="mt-4">
                  <h2 className="text-sm font-extrabold text-[#303832]">
                    {estimate.name} 고객님
                  </h2>
                  <p className="mt-2 text-xs text-[#777f79]">
                    제시 금액
                    <strong className="ml-2 text-base text-[#346538]">
                      {formatCurrency(estimate.amount)}
                    </strong>
                  </p>
                  {estimate.reason && (
                    <div className="mt-3 rounded-xl bg-[#f7f8f7] p-3">
                      <span className="text-[10px] font-bold text-[#9a554f]">
                        반려 사유
                      </span>
                      <p className="mt-1 text-xs leading-5 text-[#666e68]">
                        {estimate.reason}
                      </p>
                    </div>
                  )}
                </div>
                <button
                  className={`mt-4 h-11 w-full rounded-xl text-xs font-extrabold ${
                    estimate.status === "rejected"
                      ? "bg-[#346538] text-white"
                      : "border border-[#d8ddd8] bg-white text-[#59625b]"
                  }`}
                  onClick={() =>
                    estimate.status === "rejected"
                      ? openRequoteForm(estimate)
                      : setViewer(estimate)
                  }
                  type="button"
                >
                  {estimate.status === "rejected"
                    ? "재견적 작성하기"
                    : "견적서 다시 보기"}
                </button>
              </article>
            ))}
          </div>
        )}

        {activeTab === "confirmed" && (
          <div className="space-y-3">
            <div className="flex items-center justify-between px-1">
              <p className="text-xs font-bold text-[#59625b]">최종 확정 견적</p>
              <span className="rounded-full bg-[#edf3ed] px-2.5 py-1 text-[10px] font-extrabold text-[#346538]">
                {confirmed.length}건
              </span>
            </div>
            {confirmed.map((estimate) => (
              <article
                className="rounded-[20px] bg-white p-4 shadow-[0_5px_18px_rgba(36,58,39,.07)]"
                key={estimate.id}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="flex items-center gap-1.5 rounded-full bg-[#edf4ed] px-2.5 py-1 text-[10px] font-extrabold text-[#346538]">
                    <Icon name="check" size={12} />
                    견적 확정
                  </span>
                  <span className="text-[10px] text-[#9aa09b]">
                    {estimate.confirmedAt}
                  </span>
                </div>
                <p className="mt-5 text-xs font-semibold text-[#7d857f]">
                  {estimate.name} 고객님
                </p>
                <strong className="mt-1 block text-[24px] font-extrabold tracking-[-0.04em] text-[#29322b]">
                  {formatCurrency(estimate.amount)}
                </strong>
                <div className="mt-3 flex items-center gap-2 rounded-xl bg-[#f3f6f3] px-3 py-2.5 text-xs font-semibold text-[#4f6252]">
                  <Icon name="check" size={14} />
                  {estimate.payment}
                </div>
                <div className="mt-4 grid grid-cols-2 gap-2">
                  <button
                    className="h-11 rounded-xl bg-[#eef0ee] text-xs font-extrabold text-[#59625b]"
                    onClick={() => setViewer(estimate)}
                    type="button"
                  >
                    견적서 뷰어
                  </button>
                  <button
                    className="h-11 rounded-xl bg-[#346538] text-xs font-extrabold text-white"
                    onClick={() => setBookingTarget(estimate)}
                    type="button"
                  >
                    예약 확정 처리
                  </button>
                </div>
              </article>
            ))}
            {!confirmed.length && (
              <EmptyState message="예약 처리 전인 확정 견적이 없습니다." />
            )}
          </div>
        )}
      </div>

      {(quoteRequest || requote) && (
        <div className="absolute inset-0 z-40 flex flex-col bg-[#f5f6f8]">
          <header className="relative flex h-14 shrink-0 items-center justify-center border-b border-[#e5e9e5] bg-white">
            <h2 className="text-base font-extrabold text-[#303832]">
              {requote ? "재견적 작성" : "승인 상태 변경"}
            </h2>
            <button
              aria-label="견적 작성 닫기"
              className="absolute right-3 grid h-10 w-10 place-items-center rounded-full"
              onClick={closeQuoteForm}
              type="button"
            >
              <Icon name="x" size={20} />
            </button>
          </header>
          <div className="flex-1 overflow-y-auto p-4">
            <section className="rounded-[18px] bg-white p-4">
              <p className="text-[10px] font-bold tracking-[0.1em] text-[#89918b]">
                CUSTOMER
              </p>
              <h3 className="mt-2 text-base font-extrabold text-[#303832]">
                {(quoteRequest ?? requote)?.name} 고객님
              </h3>
              {quoteRequest && (
                <div className="mt-4 space-y-3">
                  {[
                    [
                      "고객 정보",
                      [
                        `이름: ${quoteRequest.name}`,
                        `연락처: ${quoteRequest.phone}`,
                      ],
                    ],
                    [
                      "이사 정보",
                      [
                        `서비스 유형: ${quoteRequest.service}`,
                        `출발지: ${quoteRequest.origin}`,
                        `도착지: ${quoteRequest.destination}`,
                      ],
                    ],
                    [
                      "이사 희망 일정",
                      [
                        `희망 이사일: ${quoteRequest.movingDate}`,
                        `희망 이사 시간대: ${quoteRequest.consultationTime}`,
                      ],
                    ],
                    [
                      "작업 환경",
                      [
                        `사다리차: ${quoteRequest.ladder}`,
                        `엘리베이터: ${quoteRequest.elevator}`,
                        `예상 짐 양: ${quoteRequest.volume}`,
                      ],
                    ],
                  ].map(([title, lines]) => (
                    <section
                      className="rounded-xl bg-[#f7f8f7] p-3"
                      key={String(title)}
                    >
                      <h4 className="text-[11px] font-extrabold text-[#346538]">
                        {title as string}
                      </h4>
                      <div className="mt-2 space-y-1">
                        {(lines as string[]).map((line) => (
                          <p
                            className="text-[10px] leading-4 text-[#59615b]"
                            key={line}
                          >
                            {line}
                          </p>
                        ))}
                      </div>
                    </section>
                  ))}
                  <section className="rounded-xl bg-[#f2f4f2] p-3">
                    <h4 className="text-[11px] font-extrabold text-[#346538]">
                      상세 물품 정보
                    </h4>
                    <p className="mt-2 text-[10px] leading-5">
                      {quoteRequest.items}
                    </p>
                    <p className="mt-2 border-t border-[#dde2dd] pt-2 text-[10px] leading-5 text-[#6d756f]">
                      {quoteRequest.memo}
                    </p>
                  </section>
                </div>
              )}
            </section>
            <section className="mt-4 rounded-[18px] bg-white p-4">
              {quoteRequest ? (
                <>
                  <label className="block">
                    <span className="text-xs font-extrabold text-[#4e5750]">
                      예약 상태
                    </span>
                    <select
                      className="mt-2 h-12 w-full rounded-xl border border-[#dfe4df] bg-[#f7f8f7] px-3 text-sm font-bold text-[#303832] outline-none focus:border-[#89a18b]"
                      onChange={(event) =>
                        setReservationStatus(event.target.value)
                      }
                      value={reservationStatus}
                    >
                      {reservationStatusOptions.map((status) => (
                        <option key={status}>{status}</option>
                      ))}
                    </select>
                  </label>
                  {reservationStatus === "반려" && (
                    <label className="mt-4 block">
                      <span className="text-xs font-extrabold text-[#4e5750]">
                        반려 사유 <span className="text-[#c55047]">*</span>
                      </span>
                      <textarea
                        className="mt-2 h-24 w-full resize-none rounded-xl border border-[#e0b5b1] bg-[#fffafa] p-3 text-sm leading-5 outline-none focus:border-[#c86c63]"
                        onChange={(event) =>
                          setRejectionReason(event.target.value)
                        }
                        placeholder="반려 사유를 입력하세요."
                        value={rejectionReason}
                      />
                    </label>
                  )}
                  <textarea
                    className="mt-4 h-24 w-full resize-none rounded-xl border border-[#dfe4df] bg-[#f7f8f7] p-3 text-sm leading-5 outline-none focus:border-[#89a18b]"
                    onChange={(event) => setCustomerMessage(event.target.value)}
                    placeholder="고객에게 전송할 안내 메시지를 입력하세요 (선택사항)"
                    value={customerMessage}
                  />
                  <textarea
                    className="mt-3 h-24 w-full resize-none rounded-xl border border-[#dfe4df] bg-[#f7f8f7] p-3 text-sm leading-5 outline-none focus:border-[#89a18b]"
                    onChange={(event) => setAdminMemo(event.target.value)}
                    placeholder="관리자 메모"
                    value={adminMemo}
                  />
                  <p className="mt-2 text-[9px] leading-4 text-[#909792]">
                    저장 시 반려 사유와 안내 메시지가 고객에게 전송됩니다.
                  </p>
                </>
              ) : (
                <>
                  <label className="block">
                    <span className="text-xs font-extrabold text-[#4e5750]">
                      총 견적 금액 <span className="text-[#c55047]">*</span>
                    </span>
                    <div className="mt-2 flex items-center rounded-xl border border-[#dfe4df] bg-[#f7f8f7] px-3 focus-within:border-[#89a18b]">
                      <input
                        className="h-12 min-w-0 flex-1 bg-transparent text-right text-lg font-extrabold text-[#303832] outline-none"
                        inputMode="numeric"
                        onChange={(event) =>
                          setAmount(event.target.value.replace(/\D/g, ""))
                        }
                        placeholder="0"
                        value={amount}
                      />
                      <span className="ml-2 text-sm font-bold text-[#69716b]">
                        원
                      </span>
                    </div>
                  </label>
                  <label className="mt-4 block">
                    <span className="text-xs font-extrabold text-[#4e5750]">
                      견적 안내 메모
                    </span>
                    <textarea
                      className="mt-2 h-28 w-full resize-none rounded-xl border border-[#dfe4df] bg-[#f7f8f7] p-3 text-sm leading-5 outline-none focus:border-[#89a18b]"
                      onChange={(event) => setMemo(event.target.value)}
                      placeholder="고객에게 전달할 견적 안내 내용을 입력하세요."
                      value={memo}
                    />
                  </label>
                </>
              )}
            </section>
          </div>
          <div className="shrink-0 border-t border-[#e5e9e5] bg-white p-3">
            <button
              className="h-12 w-full rounded-xl bg-[#346538] text-sm font-extrabold text-white disabled:bg-[#bbc5bc]"
              disabled={
                quoteRequest
                  ? reservationStatus === "반려" && !rejectionReason.trim()
                  : !Number(amount)
              }
              onClick={submitQuote}
              type="button"
            >
              {requote ? "재견적 발송하기" : "저장"}
            </button>
          </div>
        </div>
      )}

      {viewer && (
        <div className="absolute inset-0 z-40 grid place-items-center bg-[#1f2d21]/45 p-5 backdrop-blur-[2px]">
          <div className="w-full rounded-[22px] bg-white p-5 shadow-[0_20px_50px_rgba(25,42,28,.24)]">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-extrabold text-[#303832]">
                견적서
              </h2>
              <button
                aria-label="견적서 닫기"
                className="grid h-9 w-9 place-items-center rounded-full bg-[#f3f5f3]"
                onClick={() => setViewer(null)}
                type="button"
              >
                <Icon name="x" size={17} />
              </button>
            </div>
            <div className="mt-5 rounded-2xl border border-[#e3e7e3] p-4">
              <p className="text-[10px] font-bold tracking-[0.1em] text-[#8b938d]">
                LUXURY EXPRESS
              </p>
              <p className="mt-4 text-sm font-extrabold text-[#303832]">
                {viewer.name} 고객님
              </p>
              <div className="my-4 h-px bg-[#e7eae7]" />
              <span className="text-xs text-[#7c847e]">최종 견적 금액</span>
              <strong className="mt-1 block text-2xl font-extrabold text-[#346538]">
                {formatCurrency(viewer.amount)}
              </strong>
              {"payment" in viewer && (
                <p className="mt-4 rounded-xl bg-[#edf3ed] p-3 text-xs font-semibold text-[#466049]">
                  {viewer.payment}
                </p>
              )}
            </div>
            <button
              className="mt-4 h-11 w-full rounded-xl bg-[#346538] text-sm font-bold text-white"
              onClick={() => setViewer(null)}
              type="button"
            >
              확인
            </button>
          </div>
        </div>
      )}

      {bookingTarget && (
        <div className="absolute inset-0 z-40 grid place-items-center bg-[#1f2d21]/45 p-6 backdrop-blur-[2px]">
          <div className="w-full rounded-[22px] bg-white p-5 text-center shadow-[0_20px_50px_rgba(25,42,28,.24)]">
            <span className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-[#edf3ed] text-[#346538]">
              <Icon name="calendar" size={21} />
            </span>
            <h2 className="mt-4 text-base font-extrabold text-[#303832]">
              예약으로 확정하시겠습니까?
            </h2>
            <p className="mt-2 text-xs leading-5 text-[#8a918c]">
              {bookingTarget.name} 고객님의 견적이 예약 관리로 이관됩니다.
            </p>
            <div className="mt-5 grid grid-cols-2 gap-2">
              <button
                className="h-11 rounded-xl bg-[#f0f2f0] text-sm font-bold text-[#646c66]"
                onClick={() => setBookingTarget(null)}
                type="button"
              >
                취소
              </button>
              <button
                className="h-11 rounded-xl bg-[#346538] text-sm font-bold text-white"
                onClick={() => {
                  transferredEstimateIds.add(bookingTarget.id)
                  setConfirmed((current) =>
                    current.filter(
                      (estimate) => estimate.id !== bookingTarget.id,
                    ),
                  )
                  setBookingTarget(null)
                  onOpenReservations()
                }}
                type="button"
              >
                예약 확정
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function EmptyState({ message }: { message: string }) {
  return (
    <div className="py-20 text-center">
      <span className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-white text-[#9aa19b]">
        <Icon name="document" size={21} />
      </span>
      <p className="mt-3 text-xs font-semibold text-[#747c76]">{message}</p>
    </div>
  )
}
